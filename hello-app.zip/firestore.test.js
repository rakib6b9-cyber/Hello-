const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const CHARLIE_UID = "charlie_789";
const PAIR_ID = `${ALICE_UID}_${BOB_UID}`;

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("public_profiles").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("chats").where("memberUids", "array-contains", ALICE_UID).get());
  await assertFails(unauthDb.collection("stories").where("allowedUids", "array-contains", ALICE_UID).get());
  await assertFails(unauthDb.collection("calls").where("participantUids", "array-contains", ALICE_UID).get());
});

test("Public profiles and private PII isolation work as designed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 2000);

  await assertSucceeds(
    aliceDb.collection("public_profiles").doc(ALICE_UID).set({
      userId: ALICE_UID,
      username: "alice_hello",
      displayName: "Alice",
      onlineStatus: "ONLINE",
      e2eePublicKey: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEtestkey",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("private").doc("account").set({
      userId: ALICE_UID,
      email: "alice@example.com",
      phoneNumber: "+15551234567",
      countryCode: "+1",
      showOnlineStatus: true,
      showReadReceipts: true,
      storyPrivacy: "ALL_FRIENDS",
      language: "EN",
      themeMode: "DARK",
      notificationsEnabled: true,
      blockedUids: [],
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob can get Alice's public profile, cannot list all public profiles, cannot read Alice's private PII
  await assertSucceeds(bobDb.collection("public_profiles").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("public_profiles").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("private").doc("account").get());

  // Ghost field & future timestamp fail
  await assertFails(
    aliceDb.collection("public_profiles").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    bobDb.collection("public_profiles").doc(BOB_UID).set({
      userId: BOB_UID,
      username: "bob_hello",
      displayName: "Bob",
      onlineStatus: "ONLINE",
      createdAt: new Date(Date.now() + 60000),
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Lookup indices (usernames, phone_hashes, invite_codes) allow exact get but block list scraping", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 2000);

  await assertSucceeds(
    aliceDb.collection("usernames").doc("alice_hello").set({
      userId: ALICE_UID,
      username: "alice_hello",
      createdAt: now,
    })
  );

  await assertSucceeds(bobDb.collection("usernames").doc("alice_hello").get());
  await assertFails(bobDb.collection("usernames").get());
  await assertFails(bobDb.collection("phone_hashes").get());
  await assertFails(bobDb.collection("invite_codes").get());
});

test("Friend requests enforce sender/recipient transitions and terminal state locking", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const now = new Date(Date.now() - 2000);

  await assertSucceeds(
    aliceDb.collection("friend_requests").doc("req_1").set({
      fromUid: ALICE_UID,
      toUid: BOB_UID,
      participantUids: [ALICE_UID, BOB_UID],
      fromName: "Alice",
      fromUsername: "alice_hello",
      status: "PENDING",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Sender cannot self-accept
  await assertFails(
    aliceDb.collection("friend_requests").doc("req_1").update({
      status: "ACCEPTED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Charlie cannot read or update
  await assertFails(charlieDb.collection("friend_requests").doc("req_1").get());

  // Bob can accept
  await assertSucceeds(
    bobDb.collection("friend_requests").doc("req_1").update({
      status: "ACCEPTED",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Terminal state locked after ACCEPTED
  await assertFails(
    bobDb.collection("friend_requests").doc("req_1").update({
      status: "REJECTED",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Chats and E2EE messages enforce member isolation and filtered queries", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const now = new Date(Date.now() - 2000);

  await assertSucceeds(
    aliceDb.collection("chats").doc(PAIR_ID).set({
      chatType: "DIRECT",
      title: "",
      memberUids: [ALICE_UID, BOB_UID],
      adminUids: [ALICE_UID, BOB_UID],
      createdBy: ALICE_UID,
      unreadCounts: { [ALICE_UID]: 0, [BOB_UID]: 1 },
      typingUids: [],
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("chats").doc(PAIR_ID).collection("messages").doc("msg_1").set({
      chatId: PAIR_ID,
      senderId: ALICE_UID,
      senderName: "Alice",
      memberUids: [ALICE_UID, BOB_UID],
      messageType: "TEXT",
      ciphertext: "base64ciphertext==",
      iv: "base64iv==",
      encrypted: true,
      forwarded: false,
      edited: false,
      deleted: false,
      readByUids: [ALICE_UID],
      deliveredToUids: [ALICE_UID],
      createdAt: now,
      updatedAt: now,
    })
  );

  // Filtered member queries succeed
  await assertSucceeds(
    bobDb.collection("chats").where("memberUids", "array-contains", BOB_UID).get()
  );
  await assertSucceeds(
    bobDb.collection("chats").doc(PAIR_ID).collection("messages").where("memberUids", "array-contains", BOB_UID).get()
  );

  // Unfiltered query & non-member read fail
  await assertFails(bobDb.collection("chats").get());
  await assertFails(charlieDb.collection("chats").doc(PAIR_ID).collection("messages").doc("msg_1").get());

  // Bob can mark message read, but cannot edit Alice's ciphertext
  await assertSucceeds(
    bobDb.collection("chats").doc(PAIR_ID).collection("messages").doc("msg_1").update({
      readByUids: [ALICE_UID, BOB_UID],
      deliveredToUids: [ALICE_UID, BOB_UID],
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    bobDb.collection("chats").doc(PAIR_ID).collection("messages").doc("msg_1").update({
      ciphertext: "tampered",
      edited: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Stories, My Person spaces, and WebRTC calls enforce strict participant rules", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext(CHARLIE_UID).firestore();
  const now = new Date(Date.now() - 2000);
  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000);

  await assertSucceeds(
    aliceDb.collection("stories").doc("story_1").set({
      authorId: ALICE_UID,
      authorName: "Alice",
      storyType: "TEXT",
      textContent: "Stay Connected, Stay Close!",
      backgroundColorHex: "#7C4DFF",
      privacy: "ALL_FRIENDS",
      allowedUids: [ALICE_UID, BOB_UID],
      viewedByUids: [ALICE_UID],
      expiresAt: expires,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    bobDb.collection("stories").where("allowedUids", "array-contains", BOB_UID).get()
  );
  await assertFails(charlieDb.collection("stories").doc("story_1").get());

  // My Person Space
  await assertSucceeds(
    aliceDb.collection("my_person_spaces").doc(PAIR_ID).set({
      memberUids: [ALICE_UID, BOB_UID],
      createdBy: ALICE_UID,
      anniversaryEpochMs: 1700000000000,
      partnerBirthdayEpochMs: 1735000000000,
      moodByUid: { [ALICE_UID]: "Grateful" },
      hugCount: 1,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(charlieDb.collection("my_person_spaces").doc(PAIR_ID).get());

  // WebRTC Call & ICE Candidate
  await assertSucceeds(
    aliceDb.collection("calls").doc("call_1").set({
      callerId: ALICE_UID,
      callerName: "Alice",
      calleeIds: [BOB_UID],
      participantUids: [ALICE_UID, BOB_UID],
      callType: "VIDEO",
      status: "RINGING",
      offerSdp: "v=0\r\no=- 123 2 IN IP4 127.0.0.1\r\n",
      durationSec: 0,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(
    bobDb.collection("calls").doc("call_1").collection("candidates").doc("cand_1").set({
      senderId: BOB_UID,
      targetId: ALICE_UID,
      participantUids: [ALICE_UID, BOB_UID],
      sdpMid: "0",
      sdpMLineIndex: 0,
      candidate: "candidate:1 1 UDP 2122252543 192.168.1.2 50000 typ host",
      createdAt: now,
    })
  );
  await assertFails(charlieDb.collection("calls").doc("call_1").get());
});
