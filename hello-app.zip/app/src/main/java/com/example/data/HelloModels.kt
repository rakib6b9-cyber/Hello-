package com.example.data

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class AppLanguage(val code: String, val label: String) {
    EN("EN", "English"),
    BN("BN", "বাংলা (Bengali)");

    companion object {
        fun fromRaw(raw: String?): AppLanguage =
            entries.firstOrNull { it.name == raw || it.code == raw } ?: EN
    }
}

enum class ThemeMode(val label: String) {
    DARK("Dark Charcoal"),
    LIGHT("Light Mode"),
    SYSTEM("System Default");

    companion object {
        fun fromRaw(raw: String?): ThemeMode =
            entries.firstOrNull { it.name == raw } ?: DARK
    }
}

enum class StoryPrivacy(val label: String) {
    ALL_FRIENDS("All Friends"),
    MY_PERSON("My Person Only"),
    CLOSE_CIRCLE("Close Circle");

    companion object {
        fun fromRaw(raw: String?): StoryPrivacy =
            entries.firstOrNull { it.name == raw } ?: ALL_FRIENDS
    }
}

enum class MessageType {
    TEXT, IMAGE, VIDEO, DOCUMENT, VOICE, CALL_EVENT;

    companion object {
        fun fromRaw(raw: String?): MessageType =
            entries.firstOrNull { it.name == raw } ?: TEXT
    }
}

enum class CallType {
    AUDIO, VIDEO, GROUP_AUDIO, GROUP_VIDEO;

    companion object {
        fun fromRaw(raw: String?): CallType =
            entries.firstOrNull { it.name == raw } ?: AUDIO
    }
}

enum class CallStatus {
    RINGING, CONNECTED, ENDED, MISSED, DECLINED;

    companion object {
        fun fromRaw(raw: String?): CallStatus =
            entries.firstOrNull { it.name == raw } ?: ENDED
    }
}

@Keep
@IgnoreExtraProperties
data class PublicProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val username: String = "",
    val displayName: String = "",
    val photoUrl: String = "",
    val bio: String = "",
    val statusText: String = "",
    val onlineStatus: String = "ONLINE",
    @ServerTimestamp val lastSeen: Timestamp? = null,
    val phoneHash: String = "",
    val inviteCode: String = "",
    val e2eePublicKey: String = "",
    val myPersonId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PrivateAccount(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val countryCode: String = "+1",
    val fcmToken: String = "",
    val showOnlineStatus: Boolean = true,
    val showReadReceipts: Boolean = true,
    val storyPrivacy: String = "ALL_FRIENDS",
    val language: String = "EN",
    val themeMode: String = "DARK",
    val notificationsEnabled: Boolean = true,
    val blockedUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FriendRequest(
    @DocumentId val id: String = "",
    val fromUid: String = "",
    val toUid: String = "",
    val participantUids: List<String> = emptyList(),
    val fromName: String = "",
    val fromUsername: String = "",
    val fromPhotoUrl: String = "",
    val toName: String = "",
    val toUsername: String = "",
    val toPhotoUrl: String = "",
    val status: String = "PENDING",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Friendship(
    @DocumentId val id: String = "",
    val memberUids: List<String> = emptyList(),
    val favoriteBy: List<String> = emptyList(),
    val myPersonPair: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class FriendWithProfile(
    val friendship: Friendship,
    val profile: PublicProfile
)

@Keep
@IgnoreExtraProperties
data class Chat(
    @DocumentId val id: String = "",
    val chatType: String = "DIRECT",
    val title: String = "",
    val photoUrl: String = "",
    val memberUids: List<String> = emptyList(),
    val adminUids: List<String> = emptyList(),
    val createdBy: String = "",
    val lastMessagePreview: String = "",
    val lastMessageType: String = "TEXT",
    val lastMessageSenderId: String = "",
    @ServerTimestamp val lastMessageAt: Timestamp? = null,
    val wrappedGroupKeys: Map<String, String> = emptyMap(),
    val unreadCounts: Map<String, Long> = emptyMap(),
    val typingUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val chatId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val memberUids: List<String> = emptyList(),
    val messageType: String = "TEXT",
    val ciphertext: String = "",
    val iv: String = "",
    val plainFallback: String = "",
    val encrypted: Boolean = true,
    val mediaUrl: String = "",
    val mediaName: String = "",
    val mediaDurationSec: Long = 0L,
    val replyToId: String = "",
    val replyToPreview: String = "",
    val forwarded: Boolean = false,
    val edited: Boolean = false,
    val deleted: Boolean = false,
    val readByUids: List<String> = emptyList(),
    val deliveredToUids: List<String> = emptyList(),
    val reactions: Map<String, String> = emptyMap(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Story(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorUsername: String = "",
    val authorPhotoUrl: String = "",
    val storyType: String = "TEXT",
    val textContent: String = "",
    val mediaUrl: String = "",
    val backgroundColorHex: String = "#7C4DFF",
    val privacy: String = "ALL_FRIENDS",
    val allowedUids: List<String> = emptyList(),
    val viewedByUids: List<String> = emptyList(),
    val expiresAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class MyPersonSpace(
    @DocumentId val id: String = "",
    val memberUids: List<String> = emptyList(),
    val createdBy: String = "",
    val anniversaryEpochMs: Long = 0L,
    val partnerBirthdayEpochMs: Long = 0L,
    val moodByUid: Map<String, String> = emptyMap(),
    val hugCount: Long = 0L,
    val lastHugBy: String = "",
    @ServerTimestamp val lastHugAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class MyPersonMemory(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val memberUids: List<String> = emptyList(),
    val title: String = "",
    val description: String = "",
    val mediaUrl: String = "",
    val memoryDateLabel: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class MyPersonNote(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val memberUids: List<String> = emptyList(),
    val content: String = "",
    val pinned: Boolean = false,
    val colorTag: String = "VIOLET",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CallSession(
    @DocumentId val id: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callerPhotoUrl: String = "",
    val calleeIds: List<String> = emptyList(),
    val participantUids: List<String> = emptyList(),
    val callType: String = "AUDIO",
    val status: String = "RINGING",
    val offerSdp: String = "",
    val answerSdp: String = "",
    val durationSec: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class IceCandidateSignal(
    @DocumentId val id: String = "",
    val senderId: String = "",
    val targetId: String = "",
    val participantUids: List<String> = emptyList(),
    val sdpMid: String = "",
    val sdpMLineIndex: Long = 0L,
    val candidate: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
