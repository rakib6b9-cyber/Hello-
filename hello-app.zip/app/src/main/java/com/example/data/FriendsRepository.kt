package com.example.data

import android.content.Context
import com.example.R
import com.example.crypto.E2eeCryptoManager
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FriendsRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("User must be signed in.")

    fun observeFriendships(userId: String): Flow<List<Friendship>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "friendships"
        emitAll(
            db.collection(path)
                .whereArrayContains("memberUids", uid)
                .snapshots()
                .map { snap -> snap.toObjects(Friendship::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeFriendRequests(userId: String): Flow<List<FriendRequest>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "friend_requests"
        emitAll(
            db.collection(path)
                .whereArrayContains("participantUids", uid)
                .snapshots()
                .map { snap -> snap.toObjects(FriendRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun findUserByUsername(rawUsername: String): Result<PublicProfile?> {
        val normalized = ProfileRepository.normalizeUsername(rawUsername)
        if (normalized.isBlank()) return Result.success(null)
        val path = "usernames/$normalized"
        return try {
            requireUserId()
            val indexDoc = db.collection("usernames").document(normalized).get().await()
            val targetUid = indexDoc.getString("userId") ?: return Result.success(null)
            val profileSnap = db.collection("public_profiles").document(targetUid).get().await()
            val profile = profileSnap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun findUserByPhone(countryCode: String, localPhone: String): Result<PublicProfile?> {
        val e164 = ProfileRepository.buildE164(countryCode, localPhone)
        if (e164.isBlank()) return Result.success(null)
        val hash = E2eeCryptoManager.hashPhoneE164(e164)
        val path = "phone_hashes/$hash"
        return try {
            requireUserId()
            val indexDoc = db.collection("phone_hashes").document(hash).get().await()
            val targetUid = indexDoc.getString("userId") ?: return Result.success(null)
            val profileSnap = db.collection("public_profiles").document(targetUid).get().await()
            val profile = profileSnap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun findUserByInviteCode(rawInput: String): Result<PublicProfile?> {
        val code = rawInput
            .substringAfter("code=", rawInput)
            .substringBefore("&")
            .trim()
            .uppercase()
        if (code.isBlank()) return Result.success(null)
        val path = "invite_codes/$code"
        return try {
            requireUserId()
            val indexDoc = db.collection("invite_codes").document(code).get().await()
            val targetUid = indexDoc.getString("userId") ?: return Result.success(null)
            val profileSnap = db.collection("public_profiles").document(targetUid).get().await()
            val profile = profileSnap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun discoverUsersByPhoneHashes(hashes: List<String>): Result<List<PublicProfile>> {
        return try {
            val uid = requireUserId()
            val found = mutableListOf<PublicProfile>()
            for (hash in hashes.distinct().take(40)) {
                val indexSnap = db.collection("phone_hashes").document(hash).get().await()
                val targetUid = indexSnap.getString("userId")
                if (!targetUid.isNullOrBlank() && targetUid != uid) {
                    val profileSnap = db.collection("public_profiles").document(targetUid).get().await()
                    profileSnap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?.let { found.add(it) }
                }
            }
            Result.success(found)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "phone_hashes")
            Result.failure(e)
        }
    }

    suspend fun sendFriendRequest(myProfile: PublicProfile, targetProfile: PublicProfile): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        if (targetProfile.userId == uid) {
            return Result.failure(IllegalArgumentException("You cannot send a friend request to yourself."))
        }
        val reqId = "req_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "friend_requests/$reqId"
        return try {
            val pairId = sortedPairId(uid, targetProfile.userId)
            val existingFriendship = db.collection("friendships").document(pairId).get().await()
            if (existingFriendship.exists()) {
                return Result.failure(IllegalStateException("You are already connected with @${targetProfile.username}."))
            }
            val payload = mapOf(
                "fromUid" to uid,
                "toUid" to targetProfile.userId,
                "participantUids" to listOf(uid, targetProfile.userId),
                "fromName" to myProfile.displayName.take(80),
                "fromUsername" to myProfile.username.take(30),
                "fromPhotoUrl" to myProfile.photoUrl.take(1000),
                "toName" to targetProfile.displayName.take(80),
                "toUsername" to targetProfile.username.take(30),
                "toPhotoUrl" to targetProfile.photoUrl.take(1000),
                "status" to "PENDING",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("friend_requests").document(reqId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun respondToFriendRequest(request: FriendRequest, accept: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val reqPath = "friend_requests/${request.id}"
        return try {
            val newStatus = if (accept) "ACCEPTED" else "REJECTED"
            val batch = db.batch()
            batch.update(
                db.collection("friend_requests").document(request.id),
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (accept) {
                val pairId = sortedPairId(request.fromUid, request.toUid)
                val members = listOf(request.fromUid, request.toUid).sorted()
                batch.set(
                    db.collection("friendships").document(pairId),
                    mapOf(
                        "memberUids" to members,
                        "favoriteBy" to emptyList<String>(),
                        "myPersonPair" to false,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, reqPath)
            Result.failure(e)
        }
    }

    suspend fun cancelFriendRequest(requestId: String): Result<Unit> {
        val path = "friend_requests/$requestId"
        return try {
            requireUserId()
            db.collection("friend_requests").document(requestId).update(
                mapOf(
                    "status" to "CANCELLED",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleFavorite(friendship: Friendship): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "friendships/${friendship.id}"
        return try {
            val updatedFavs = if (uid in friendship.favoriteBy) {
                friendship.favoriteBy - uid
            } else {
                (friendship.favoriteBy + uid).distinct().take(2)
            }
            db.collection("friendships").document(friendship.id).update(
                mapOf(
                    "favoriteBy" to updatedFavs,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun blockUser(targetUid: String, currentBlocked: List<String>): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid/private/account"
        return try {
            val updated = (currentBlocked + targetUid).distinct().take(200)
            db.collection("users").document(uid).collection("private").document("account")
                .update(
                    mapOf(
                        "blockedUids" to updated,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun unblockUser(targetUid: String, currentBlocked: List<String>): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid/private/account"
        return try {
            val updated = currentBlocked.filterNot { it == targetUid }
            db.collection("users").document(uid).collection("private").document("account")
                .update(
                    mapOf(
                        "blockedUids" to updated,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun reportUser(targetUid: String, reason: String, details: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val reportId = "rep_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "reports/$reportId"
        return try {
            val payload = mapOf(
                "reporterId" to uid,
                "reportedUid" to targetUid,
                "reason" to reason.trim().take(100),
                "details" to details.trim().take(500),
                "createdAt" to FieldValue.serverTimestamp()
            )
            db.collection("reports").document(reportId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    companion object {
        fun sortedPairId(uidA: String, uidB: String): String =
            listOf(uidA, uidB).sorted().joinToString("_")
    }
}
