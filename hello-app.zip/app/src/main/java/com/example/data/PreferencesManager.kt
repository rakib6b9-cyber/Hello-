package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.crypto.E2eeCryptoManager
import com.example.crypto.IdentityKeyPairEncoded
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.helloDataStore: DataStore<Preferences> by preferencesDataStore(name = "hello_app_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("app_language")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        fun e2eePublicKey(uid: String) = stringPreferencesKey("e2ee_pub_$uid")
        fun e2eePrivateKey(uid: String) = stringPreferencesKey("e2ee_priv_$uid")
    }

    val themeModeFlow: Flow<ThemeMode> = context.helloDataStore.data.map { prefs ->
        ThemeMode.fromRaw(prefs[Keys.THEME_MODE])
    }

    val languageFlow: Flow<AppLanguage> = context.helloDataStore.data.map { prefs ->
        AppLanguage.fromRaw(prefs[Keys.LANGUAGE])
    }

    val notificationsEnabledFlow: Flow<Boolean> = context.helloDataStore.data.map { prefs ->
        prefs[Keys.NOTIFICATIONS_ENABLED] ?: true
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.helloDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.helloDataStore.edit { it[Keys.LANGUAGE] = language.name }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.helloDataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun getOrCreateE2eeKeyPair(uid: String): IdentityKeyPairEncoded {
        val prefs = context.helloDataStore.data.first()
        val existingPub = prefs[Keys.e2eePublicKey(uid)]
        val existingPriv = prefs[Keys.e2eePrivateKey(uid)]
        if (!existingPub.isNullOrBlank() && !existingPriv.isNullOrBlank()) {
            return IdentityKeyPairEncoded(existingPub, existingPriv)
        }
        val created = E2eeCryptoManager.generateIdentityKeyPair()
        context.helloDataStore.edit {
            it[Keys.e2eePublicKey(uid)] = created.publicKeyBase64
            it[Keys.e2eePrivateKey(uid)] = created.privateKeyBase64
        }
        return created
    }

    suspend fun getE2eePrivateKey(uid: String): String? {
        return context.helloDataStore.data.first()[Keys.e2eePrivateKey(uid)]
    }
}
