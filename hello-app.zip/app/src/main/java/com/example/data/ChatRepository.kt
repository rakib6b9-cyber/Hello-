package com.example.data

import android.content.Context
import android.util.Base64
import com.example.R
import com.example.crypto.E2eeCryptoManager
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ChatRepository(
    private val db: FirebaseFirestore,
    private val prefs: PreferencesManager,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context, prefs: PreferencesManager) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        prefs = prefs
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("User must be signed in.")

    fun observeChats(userId: String): Flow<List<Chat>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "chats"
        emitAll(
            db.collection(path)
                .whereArrayContains("memberUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(Chat::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.lastMessageAt ?: it.updatedAt ?: it.createdAt }
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMessages(chatId: String, userId: String): Flow<List<ChatMessage>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "chats/$chatId/messages"
        emitAll(
            db.collection("chats").document(chatId).collection("messages")
                .whereArrayContains("memberUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt ?: Timestamp.now() }
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun getOrCreateDirectChat(peerUid: String): Result<Chat> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val chatId = FriendsRepository.sortedPairId(uid, peerUid)
        val path = "chats/$chatId"
        return try {
            val docRef = db.collection("chats").document(chatId)
            val snap = docRef.get().await()
            if (snap.exists()) {
                val chat = snap.toObject(Chat::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: error("Failed to parse chat.")
                return Result.success(chat)
            }
            val members = listOf(uid, peerUid).sorted()
            val payload = mapOf(
                "chatType" to "DIRECT",
                "title" to "",
                "photoUrl" to "",
                "memberUids" to members,
                "adminUids" to members,
                "createdBy" to uid,
                "lastMessagePreview" to "",
                "lastMessageType" to "TEXT",
                "lastMessageSenderId" to "",
                "unreadCounts" to mapOf(uid to 0L, peerUid to 0L),
                "typingUids" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            val created = docRef.get().await().toObject(Chat::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: Chat(id = chatId, chatType = "DIRECT", memberUids = members, adminUids = members, createdBy = uid)
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun createGroupChat(
        title: String,
        memberProfiles: List<PublicProfile>
    ): Result<Chat> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val cleanTitle = title.trim().take(100)
        if (cleanTitle.isBlank()) return Result.failure(IllegalArgumentException("Group title is required."))
        val chatId = "grp_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "chats/$chatId"
        return try {
            val memberUids = (memberProfiles.map { it.userId } + uid).distinct().take(50)
            val keyPair = prefs.getOrCreateE2eeKeyPair(uid)
            val groupAesKey = E2eeCryptoManager.generateGroupAesKey()
            val wrappedKeys = mutableMapOf<String, String>()
            // Wrap for creator with creator's own key
            wrappedKeys[uid] = E2eeCryptoManager.wrapGroupKey(groupAesKey, keyPair.privateKeyBase64, keyPair.publicKeyBase64, chatId)
            for (member in memberProfiles) {
                if (member.e2eePublicKey.isNotBlank()) {
                    wrappedKeys[member.userId] = E2eeCryptoManager.wrapGroupKey(
                        groupAesKey,
                        keyPair.privateKeyBase64,
                        member.e2eePublicKey,
                        chatId
                    )
                }
            }
            val unreadMap = memberUids.associateWith { 0L }
            val payload = mapOf(
                "chatType" to "GROUP",
                "title" to cleanTitle,
                "photoUrl" to "",
                "memberUids" to memberUids,
                "adminUids" to listOf(uid),
                "createdBy" to uid,
                "lastMessagePreview" to "Group created",
                "lastMessageType" to "TEXT",
                "lastMessageSenderId" to uid,
                "lastMessageAt" to FieldValue.serverTimestamp(),
                "wrappedGroupKeys" to wrappedKeys,
                "unreadCounts" to unreadMap,
                "typingUids" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("chats").document(chatId).set(payload).await()
            val created = db.collection("chats").document(chatId).get().await()
                .toObject(Chat::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: Chat(id = chatId, chatType = "GROUP", title = cleanTitle, memberUids = memberUids)
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deriveChatAesKey(
        chat: Chat,
        peerProfile: PublicProfile?,
        creatorProfile: PublicProfile?
    ): ByteArray? {
        val uid = auth.currentUser?.uid ?: return null
        val myPriv = prefs.getOrCreateE2eeKeyPair(uid).privateKeyBase64
        return if (chat.chatType == "DIRECT") {
            val peerPub = peerProfile?.e2eePublicKey.orEmpty()
            if (peerPub.isBlank()) null
            else E2eeCryptoManager.deriveDirectChatKey(myPriv, peerPub, chat.id)
        } else {
            val wrapped = chat.wrappedGroupKeys[uid].orEmpty()
            val creatorPub = creatorProfile?.e2eePublicKey.orEmpty()
            if (wrapped.isBlank() || creatorPub.isBlank()) null
            else E2eeCryptoManager.unwrapGroupKey(wrapped, myPriv, creatorPub, chat.id)
        }
    }

    fun decryptMessageText(message: ChatMessage, aesKey: ByteArray?): String {
        if (message.deleted) return "This message was deleted"
        if (!message.encrypted || message.ciphertext.isBlank() || message.iv.isBlank()) {
            return message.plainFallback
        }
        if (aesKey == null) {
            return message.plainFallback.ifBlank { "[Encrypted message]" }
        }
        return E2eeCryptoManager.decryptText(message.ciphertext, message.iv, aesKey)
            ?: message.plainFallback.ifBlank { "[Unable to decrypt]" }
    }

    suspend fun sendMessage(
        chat: Chat,
        senderName: String,
        plaintext: String,
        messageType: MessageType,
        aesKey: ByteArray?,
        mediaUrl: String = "",
        mediaName: String = "",
        mediaDurationSec: Long = 0L,
        replyToId: String = "",
        replyToPreview: String = "",
        forwarded: Boolean = false
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "chats/${chat.id}/messages/$msgId"
        return try {
            val encryptedPayload = if (aesKey != null && plaintext.isNotBlank()) {
                E2eeCryptoManager.encryptText(plaintext, aesKey)
            } else null

            val isEncrypted = encryptedPayload != null
            val payload = mutableMapOf<String, Any?>(
                "chatId" to chat.id,
                "senderId" to uid,
                "senderName" to senderName.take(80),
                "memberUids" to chat.memberUids,
                "messageType" to messageType.name,
                "ciphertext" to (encryptedPayload?.ciphertextBase64 ?: ""),
                "iv" to (encryptedPayload?.ivBase64 ?: ""),
                "plainFallback" to if (isEncrypted) "" else plaintext.take(2000),
                "encrypted" to isEncrypted,
                "mediaUrl" to mediaUrl.take(2000),
                "mediaName" to mediaName.take(256),
                "mediaDurationSec" to mediaDurationSec.coerceIn(0L, 36000L),
                "replyToId" to replyToId.take(128),
                "replyToPreview" to replyToPreview.take(200),
                "forwarded" to forwarded,
                "edited" to false,
                "deleted" to false,
                "readByUids" to listOf(uid),
                "deliveredToUids" to listOf(uid),
                "reactions" to emptyMap<String, String>(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            val preview = when (messageType) {
                MessageType.TEXT -> if (isEncrypted) "Encrypted message" else plaintext.take(80)
                MessageType.IMAGE -> "Photo"
                MessageType.VIDEO -> "Video"
                MessageType.DOCUMENT -> mediaName.ifBlank { "Document" }
                MessageType.VOICE -> "Voice message (${mediaDurationSec}s)"
                MessageType.CALL_EVENT -> plaintext.take(80)
            }

            val updatedUnread = chat.unreadCounts.toMutableMap()
            for (member in chat.memberUids) {
                if (member != uid) {
                    updatedUnread[member] = (updatedUnread[member] ?: 0L) + 1L
                }
            }

            val batch = db.batch()
            batch.set(
                db.collection("chats").document(chat.id).collection("messages").document(msgId),
                payload
            )
            batch.update(
                db.collection("chats").document(chat.id),
                mapOf(
                    "lastMessagePreview" to preview,
                    "lastMessageType" to messageType.name,
                    "lastMessageSenderId" to uid,
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadCounts" to updatedUnread,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun editMessage(chatId: String, message: ChatMessage, newText: String, aesKey: ByteArray?): Result<Unit> {
        val path = "chats/$chatId/messages/${message.id}"
        return try {
            requireUserId()
            val encrypted = if (aesKey != null) E2eeCryptoManager.encryptText(newText, aesKey) else null
            db.collection("chats").document(chatId).collection("messages").document(message.id)
                .update(
                    mapOf(
                        "ciphertext" to (encrypted?.ciphertextBase64 ?: ""),
                        "iv" to (encrypted?.ivBase64 ?: ""),
                        "plainFallback" to if (encrypted == null) newText.take(2000) else "",
                        "edited" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteMessage(chatId: String, messageId: String): Result<Unit> {
        val path = "chats/$chatId/messages/$messageId"
        return try {
            requireUserId()
            db.collection("chats").document(chatId).collection("messages").document(messageId)
                .update(
                    mapOf(
                        "deleted" to true,
                        "ciphertext" to "",
                        "plainFallback" to "",
                        "mediaUrl" to "",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun markChatReadAndDelivered(chat: Chat, messages: List<ChatMessage>, showReadReceipts: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        return try {
            val batch = db.batch()
            var hasUpdates = false
            if ((chat.unreadCounts[uid] ?: 0L) > 0L) {
                val updatedCounts = chat.unreadCounts.toMutableMap()
                updatedCounts[uid] = 0L
                batch.update(
                    db.collection("chats").document(chat.id),
                    mapOf(
                        "unreadCounts" to updatedCounts,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                hasUpdates = true
            }
            for (msg in messages.takeLast(30)) {
                if (msg.senderId != uid && (uid !in msg.deliveredToUids || (showReadReceipts && uid !in msg.readByUids))) {
                    val delivered = (msg.deliveredToUids + uid).distinct().take(50)
                    val readBy = if (showReadReceipts) (msg.readByUids + uid).distinct().take(50) else msg.readByUids
                    batch.update(
                        db.collection("chats").document(chat.id).collection("messages").document(msg.id),
                        mapOf(
                            "deliveredToUids" to delivered,
                            "readByUids" to readBy,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    hasUpdates = true
                }
            }
            if (hasUpdates) batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "chats/${chat.id}")
            Result.failure(e)
        }
    }

    suspend fun toggleMessageReaction(chatId: String, message: ChatMessage, emoji: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "chats/$chatId/messages/${message.id}"
        return try {
            val updated = message.reactions.toMutableMap()
            if (updated[uid] == emoji) updated.remove(uid) else updated[uid] = emoji
            db.collection("chats").document(chatId).collection("messages").document(message.id)
                .update(
                    mapOf(
                        "reactions" to updated,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun setTypingStatus(chat: Chat, isTyping: Boolean): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val path = "chats/${chat.id}"
        return try {
            val current = chat.typingUids
            val next = if (isTyping) (current + uid).distinct().take(20) else current.filterNot { it == uid }
            if (next != current) {
                db.collection("chats").document(chat.id).update(
                    mapOf(
                        "typingUids" to next,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }
}
