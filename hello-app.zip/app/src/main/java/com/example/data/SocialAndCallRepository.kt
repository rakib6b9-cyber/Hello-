package com.example.data

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.UUID

class SocialAndCallRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("User must be signed in.")

    // --- STORIES (24h auto-expiry) ---

    fun observeActiveStories(userId: String): Flow<List<Story>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "stories"
        emitAll(
            db.collection(path)
                .whereArrayContains("allowedUids", uid)
                .snapshots()
                .map { snap ->
                    val nowMs = System.currentTimeMillis()
                    snap.toObjects(Story::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { story ->
                            val expMs = story.expiresAt?.toDate()?.time ?: Long.MAX_VALUE
                            expMs > nowMs
                        }
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun postStory(
        author: PublicProfile,
        storyType: String,
        textContent: String,
        mediaUrl: String,
        backgroundColorHex: String,
        privacy: StoryPrivacy,
        friendUids: List<String>
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val storyId = "st_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "stories/$storyId"
        return try {
            val targetUids = when (privacy) {
                StoryPrivacy.MY_PERSON -> listOfNotNull(uid, author.myPersonId.takeIf { it.isNotBlank() }).distinct()
                StoryPrivacy.CLOSE_CIRCLE -> (listOf(uid) + friendUids.take(15)).distinct()
                StoryPrivacy.ALL_FRIENDS -> (listOf(uid) + friendUids).distinct().take(100)
            }
            val expiresAt = Timestamp(Date(System.currentTimeMillis() + 24L * 60L * 60L * 1000L))
            val payload = mapOf(
                "authorId" to uid,
                "authorName" to author.displayName.take(80),
                "authorUsername" to author.username.take(30),
                "authorPhotoUrl" to author.photoUrl.take(1000),
                "storyType" to storyType,
                "textContent" to textContent.take(1000),
                "mediaUrl" to mediaUrl.take(2000),
                "backgroundColorHex" to backgroundColorHex.take(16),
                "privacy" to privacy.name,
                "allowedUids" to targetUids,
                "viewedByUids" to listOf(uid),
                "expiresAt" to expiresAt,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("stories").document(storyId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun markStoryViewed(story: Story): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        if (uid in story.viewedByUids) return Result.success(Unit)
        val path = "stories/${story.id}"
        return try {
            val updated = (story.viewedByUids + uid).distinct().take(100)
            db.collection("stories").document(story.id).update(
                mapOf(
                    "viewedByUids" to updated,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteStory(storyId: String): Result<Unit> {
        val path = "stories/$storyId"
        return try {
            requireUserId()
            db.collection("stories").document(storyId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- MY PERSON SANCTUARY ---

    fun observeMyPersonSpace(userId: String): Flow<MyPersonSpace?> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "my_person_spaces"
        emitAll(
            db.collection(path)
                .whereArrayContains("memberUids", uid)
                .limit(1)
                .snapshots()
                .map { snap ->
                    snap.toObjects(MyPersonSpace::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .firstOrNull()
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMemories(spaceId: String, userId: String): Flow<List<MyPersonMemory>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "my_person_spaces/$spaceId/memories"
        emitAll(
            db.collection("my_person_spaces").document(spaceId).collection("memories")
                .whereArrayContains("memberUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(MyPersonMemory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeNotes(spaceId: String, userId: String): Flow<List<MyPersonNote>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "my_person_spaces/$spaceId/notes"
        emitAll(
            db.collection("my_person_spaces").document(spaceId).collection("notes")
                .whereArrayContains("memberUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(MyPersonNote::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun selectMyPerson(partnerUid: String): Result<MyPersonSpace> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val spaceId = FriendsRepository.sortedPairId(uid, partnerUid)
        val path = "my_person_spaces/$spaceId"
        return try {
            val members = listOf(uid, partnerUid).sorted()
            val spaceRef = db.collection("my_person_spaces").document(spaceId)
            val snap = spaceRef.get().await()
            val batch = db.batch()
            if (!snap.exists()) {
                val defaultAnniversary = System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000L
                val defaultBirthday = System.currentTimeMillis() + 90L * 24 * 60 * 60 * 1000L
                batch.set(
                    spaceRef,
                    mapOf(
                        "memberUids" to members,
                        "createdBy" to uid,
                        "anniversaryEpochMs" to defaultAnniversary,
                        "partnerBirthdayEpochMs" to defaultBirthday,
                        "moodByUid" to mapOf(uid to "Connected"),
                        "hugCount" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.update(
                db.collection("public_profiles").document(uid),
                mapOf(
                    "myPersonId" to partnerUid,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            val friendshipRef = db.collection("friendships").document(spaceId)
            if (friendshipRef.get().await().exists()) {
                batch.update(
                    friendshipRef,
                    mapOf(
                        "myPersonPair" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            val space = spaceRef.get().await().toObject(MyPersonSpace::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: MyPersonSpace(id = spaceId, memberUids = members, createdBy = uid)
            Result.success(space)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun sendVirtualHug(space: MyPersonSpace): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "my_person_spaces/${space.id}"
        return try {
            db.collection("my_person_spaces").document(space.id).update(
                mapOf(
                    "hugCount" to FieldValue.increment(1),
                    "lastHugBy" to uid,
                    "lastHugAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateMyMood(space: MyPersonSpace, mood: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "my_person_spaces/${space.id}"
        return try {
            val nextMoods = space.moodByUid.toMutableMap().apply { put(uid, mood.take(32)) }
            db.collection("my_person_spaces").document(space.id).update(
                mapOf(
                    "moodByUid" to nextMoods,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateMyPersonDates(
        spaceId: String,
        anniversaryEpochMs: Long,
        partnerBirthdayEpochMs: Long
    ): Result<Unit> {
        val path = "my_person_spaces/$spaceId"
        return try {
            requireUserId()
            db.collection("my_person_spaces").document(spaceId).update(
                mapOf(
                    "anniversaryEpochMs" to anniversaryEpochMs.coerceAtLeast(0L),
                    "partnerBirthdayEpochMs" to partnerBirthdayEpochMs.coerceAtLeast(0L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun addMemory(
        space: MyPersonSpace,
        title: String,
        description: String,
        dateLabel: String,
        mediaUrl: String
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val memId = "mem_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "my_person_spaces/${space.id}/memories/$memId"
        return try {
            db.collection("my_person_spaces").document(space.id).collection("memories").document(memId)
                .set(
                    mapOf(
                        "authorId" to uid,
                        "memberUids" to space.memberUids,
                        "title" to title.trim().take(120),
                        "description" to description.trim().take(1000),
                        "mediaUrl" to mediaUrl.take(2000),
                        "memoryDateLabel" to dateLabel.trim().take(40),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun addSpecialNote(space: MyPersonSpace, content: String, colorTag: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val noteId = "note_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "my_person_spaces/${space.id}/notes/$noteId"
        return try {
            db.collection("my_person_spaces").document(space.id).collection("notes").document(noteId)
                .set(
                    mapOf(
                        "authorId" to uid,
                        "memberUids" to space.memberUids,
                        "content" to content.trim().take(1000),
                        "pinned" to false,
                        "colorTag" to colorTag.take(24),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun togglePinNote(spaceId: String, note: MyPersonNote): Result<Unit> {
        val path = "my_person_spaces/$spaceId/notes/${note.id}"
        return try {
            requireUserId()
            db.collection("my_person_spaces").document(spaceId).collection("notes").document(note.id)
                .update(
                    mapOf(
                        "pinned" to !note.pinned,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- WEBRTC CALL SIGNALING & HISTORY ---

    fun observeCalls(userId: String): Flow<List<CallSession>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "calls"
        emitAll(
            db.collection(path)
                .whereArrayContains("participantUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeCallSession(callId: String): Flow<CallSession?> = flow {
        val uid = requireUserId()
        val ref = db.collection("calls").document(callId)
        emitAll(
            ref.snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.GET, ref.path)
                    }
                    throw error
                }
        )
    }

    fun observeIceCandidates(callId: String, userId: String): Flow<List<IceCandidateSignal>> = flow {
        val uid = requireUserId()
        check(uid == userId)
        val path = "calls/$callId/candidates"
        emitAll(
            db.collection("calls").document(callId).collection("candidates")
                .whereArrayContains("participantUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(IceCandidateSignal::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createCallSession(
        callId: String,
        caller: PublicProfile,
        calleeIds: List<String>,
        callType: CallType,
        offerSdp: String
    ): Result<CallSession> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "calls/$callId"
        return try {
            val participants = (listOf(uid) + calleeIds).distinct().take(13)
            val payload = mapOf(
                "callerId" to uid,
                "callerName" to caller.displayName.take(80),
                "callerPhotoUrl" to caller.photoUrl.take(1000),
                "calleeIds" to calleeIds.distinct().take(12),
                "participantUids" to participants,
                "callType" to callType.name,
                "status" to CallStatus.RINGING.name,
                "offerSdp" to offerSdp.take(32000),
                "answerSdp" to "",
                "durationSec" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("calls").document(callId).set(payload).await()
            val created = db.collection("calls").document(callId).get().await()
                .toObject(CallSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: CallSession(
                    id = callId,
                    callerId = uid,
                    callerName = caller.displayName,
                    calleeIds = calleeIds,
                    participantUids = participants,
                    callType = callType.name,
                    status = CallStatus.RINGING.name,
                    offerSdp = offerSdp
                )
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun answerCall(callId: String, answerSdp: String): Result<Unit> {
        val path = "calls/$callId"
        return try {
            requireUserId()
            db.collection("calls").document(callId).update(
                mapOf(
                    "status" to CallStatus.CONNECTED.name,
                    "answerSdp" to answerSdp.take(32000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateCallStatus(callId: String, status: CallStatus, durationSec: Long = 0L): Result<Unit> {
        val path = "calls/$callId"
        return try {
            requireUserId()
            db.collection("calls").document(callId).update(
                mapOf(
                    "status" to status.name,
                    "durationSec" to durationSec.coerceIn(0L, 86400L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun sendIceCandidate(
        callId: String,
        targetId: String,
        participantUids: List<String>,
        sdpMid: String,
        sdpMLineIndex: Int,
        candidate: String
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val candId = "ice_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "calls/$callId/candidates/$candId"
        return try {
            db.collection("calls").document(callId).collection("candidates").document(candId)
                .set(
                    mapOf(
                        "senderId" to uid,
                        "targetId" to targetId,
                        "participantUids" to participantUids,
                        "sdpMid" to sdpMid.take(64),
                        "sdpMLineIndex" to sdpMLineIndex.coerceIn(0, 32).toLong(),
                        "candidate" to candidate.take(2000),
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }
}
