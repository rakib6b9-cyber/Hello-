package com.example.data

import android.content.Context
import android.net.Uri
import com.example.R
import com.example.crypto.E2eeCryptoManager
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class ProfileRepository(
    private val db: FirebaseFirestore,
    private val prefs: PreferencesManager,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context, prefs: PreferencesManager) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        prefs = prefs
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("User must be signed in.")

    fun observeMyProfile(userId: String): Flow<PublicProfile?> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Refusing cross-user profile observation." }
        val docRef = db.collection("public_profiles").document(uid)
        emitAll(
            docRef.snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    fun observePrivateAccount(userId: String): Flow<PrivateAccount?> = flow {
        val uid = requireUserId()
        check(uid == userId) { "Refusing cross-user private account observation." }
        val docRef = db.collection("users").document(uid).collection("private").document("account")
        emitAll(
            docRef.snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(PrivateAccount::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fsErr = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (fsErr == null && error is CancellationException) throw error
                    if (auth.currentUser?.uid == uid) {
                        handleFirestoreError(fsErr ?: error, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    suspend fun getPublicProfile(targetUid: String): Result<PublicProfile?> {
        val path = "public_profiles/$targetUid"
        return try {
            requireUserId()
            require(targetUid.isNotBlank()) { "Target UID cannot be blank." }
            val snap = db.collection("public_profiles").document(targetUid).get().await()
            val profile = if (snap.exists()) {
                snap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            } else null
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun isUsernameAvailable(rawUsername: String): Result<Boolean> {
        val normalized = normalizeUsername(rawUsername)
        if (!USERNAME_REGEX.matches(normalized)) {
            return Result.failure(IllegalArgumentException("Username must be 3-30 characters using a-z, 0-9, or _."))
        }
        val path = "usernames/$normalized"
        return try {
            val uid = requireUserId()
            val snap = db.collection("usernames").document(normalized).get().await()
            val available = !snap.exists() || snap.getString("userId") == uid
            Result.success(available)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun saveCompleteProfile(
        displayName: String,
        rawUsername: String,
        bio: String,
        photoUrl: String,
        countryCode: String,
        phoneLocalNumber: String,
        language: AppLanguage,
        themeMode: ThemeMode
    ): Result<PublicProfile> {
        val uid = auth.currentUser?.uid
            ?: return Result.failure(IllegalStateException("Must be signed in."))
        val cleanName = displayName.trim().take(80)
        val normalizedUsername = normalizeUsername(rawUsername)
        if (cleanName.isBlank()) {
            return Result.failure(IllegalArgumentException("Display name is required."))
        }
        if (!USERNAME_REGEX.matches(normalizedUsername)) {
            return Result.failure(IllegalArgumentException("Username must be 3-30 chars (lowercase letters, digits, _)."))
        }

        val profilePath = "public_profiles/$uid"
        return try {
            val usernameDoc = db.collection("usernames").document(normalizedUsername).get().await()
            if (usernameDoc.exists() && usernameDoc.getString("userId") != uid) {
                return Result.failure(IllegalStateException("@$normalizedUsername is already taken."))
            }

            val existingSnap = db.collection("public_profiles").document(uid).get().await()
            val existingProfile = existingSnap.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            val keyPair = prefs.getOrCreateE2eeKeyPair(uid)

            val fullPhone = buildE164(countryCode, phoneLocalNumber)
            val phoneHash = if (fullPhone.isNotBlank()) E2eeCryptoManager.hashPhoneE164(fullPhone) else ""
            val inviteCode = existingProfile?.inviteCode?.takeIf { it.isNotBlank() }
                ?: "HELLO-${uid.take(6).uppercase()}-${UUID.randomUUID().toString().take(4).uppercase()}"

            val batch = db.batch()
            val publicRef = db.collection("public_profiles").document(uid)
            if (existingSnap.exists()) {
                val oldUsername = existingProfile?.username.orEmpty()
                if (oldUsername.isNotBlank() && oldUsername != normalizedUsername) {
                    batch.delete(db.collection("usernames").document(oldUsername))
                }
                val updatePayload = mutableMapOf<String, Any?>(
                    "username" to normalizedUsername,
                    "displayName" to cleanName,
                    "bio" to bio.trim().take(250),
                    "photoUrl" to photoUrl.trim().take(1000),
                    "onlineStatus" to "ONLINE",
                    "lastSeen" to FieldValue.serverTimestamp(),
                    "inviteCode" to inviteCode,
                    "e2eePublicKey" to keyPair.publicKeyBase64,
                    "updatedAt" to FieldValue.serverTimestamp()
                ).apply {
                    if (phoneHash.isNotBlank()) put("phoneHash", phoneHash)
                }.filterValues { it != null }
                batch.update(publicRef, updatePayload)
            } else {
                val createPayload = mutableMapOf<String, Any?>(
                    "userId" to uid,
                    "username" to normalizedUsername,
                    "displayName" to cleanName,
                    "bio" to bio.trim().take(250),
                    "photoUrl" to photoUrl.trim().take(1000),
                    "statusText" to "Available",
                    "onlineStatus" to "ONLINE",
                    "lastSeen" to FieldValue.serverTimestamp(),
                    "inviteCode" to inviteCode,
                    "e2eePublicKey" to keyPair.publicKeyBase64,
                    "myPersonId" to "",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).apply {
                    if (phoneHash.isNotBlank()) put("phoneHash", phoneHash)
                }.filterValues { it != null }
                batch.set(publicRef, createPayload)
            }

            // Username index
            batch.set(
                db.collection("usernames").document(normalizedUsername),
                mapOf(
                    "userId" to uid,
                    "username" to normalizedUsername,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )

            // Invite code index
            batch.set(
                db.collection("invite_codes").document(inviteCode),
                mapOf(
                    "userId" to uid,
                    "username" to normalizedUsername,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )

            // Phone hash index
            if (phoneHash.isNotBlank()) {
                batch.set(
                    db.collection("phone_hashes").document(phoneHash),
                    mapOf(
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            // Private account document (PII strictly isolated)
            val privateRef = db.collection("users").document(uid).collection("private").document("account")
            val privateSnap = privateRef.get().await()
            val email = auth.currentUser?.email.orEmpty().take(254)
            if (privateSnap.exists()) {
                batch.update(
                    privateRef,
                    mapOf(
                        "email" to email,
                        "phoneNumber" to fullPhone,
                        "countryCode" to countryCode.take(10),
                        "language" to language.code,
                        "themeMode" to themeMode.name,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.set(
                    privateRef,
                    mapOf(
                        "userId" to uid,
                        "email" to email,
                        "phoneNumber" to fullPhone,
                        "countryCode" to countryCode.take(10),
                        "fcmToken" to "",
                        "showOnlineStatus" to true,
                        "showReadReceipts" to true,
                        "storyPrivacy" to StoryPrivacy.ALL_FRIENDS.name,
                        "language" to language.code,
                        "themeMode" to themeMode.name,
                        "notificationsEnabled" to true,
                        "blockedUids" to emptyList<String>(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            batch.commit().await()
            val saved = publicRef.get().await().toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: PublicProfile(userId = uid, username = normalizedUsername, displayName = cleanName, inviteCode = inviteCode)
            Result.success(saved)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, profilePath)
            Result.failure(e)
        }
    }

    suspend fun updatePresence(onlineStatus: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val path = "public_profiles/$uid"
        return try {
            val snap = db.collection("public_profiles").document(uid).get().await()
            if (!snap.exists()) return Result.success(Unit)
            db.collection("public_profiles").document(uid).update(
                mapOf(
                    "onlineStatus" to onlineStatus,
                    "lastSeen" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updatePrivacyAndPreferences(
        showOnlineStatus: Boolean,
        showReadReceipts: Boolean,
        storyPrivacy: StoryPrivacy,
        language: AppLanguage,
        themeMode: ThemeMode,
        notificationsEnabled: Boolean
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid/private/account"
        return try {
            db.collection("users").document(uid).collection("private").document("account")
                .update(
                    mapOf(
                        "showOnlineStatus" to showOnlineStatus,
                        "showReadReceipts" to showReadReceipts,
                        "storyPrivacy" to storyPrivacy.name,
                        "language" to language.code,
                        "themeMode" to themeMode.name,
                        "notificationsEnabled" to notificationsEnabled,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            if (!showOnlineStatus) {
                db.collection("public_profiles").document(uid).update(
                    mapOf(
                        "onlineStatus" to "OFFLINE",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun syncFcmToken(token: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.success(Unit)
        val path = "users/$uid/private/account"
        return try {
            val ref = db.collection("users").document(uid).collection("private").document("account")
            if (ref.get().await().exists()) {
                ref.update(
                    mapOf(
                        "fcmToken" to token.take(512),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun uploadMedia(localUri: Uri, folder: String, extension: String): Result<String> {
        return try {
            val uid = requireUserId()
            val fileName = "${UUID.randomUUID()}.$extension"
            val ref = FirebaseStorage.getInstance().reference
                .child("hello_media/$uid/$folder/$fileName")
            ref.putFile(localUri).await()
            val url = ref.downloadUrl.await().toString()
            Result.success(url)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException(
                    "Media upload requires Firebase Storage to be activated in the Firebase Console for this project (${e.localizedMessage ?: "Storage error"}).",
                    e
                )
            )
        }
    }

    suspend fun deleteAccountData(username: String, inviteCode: String, phoneHash: String): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "public_profiles/$uid"
        return try {
            val batch = db.batch()
            batch.delete(db.collection("public_profiles").document(uid))
            batch.delete(db.collection("users").document(uid).collection("private").document("account"))
            if (username.isNotBlank()) batch.delete(db.collection("usernames").document(username))
            if (inviteCode.isNotBlank()) batch.delete(db.collection("invite_codes").document(inviteCode))
            if (phoneHash.isNotBlank()) batch.delete(db.collection("phone_hashes").document(phoneHash))
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    companion object {
        val USERNAME_REGEX = Regex("^[a-z0-9_]{3,30}$")

        fun normalizeUsername(raw: String): String =
            raw.trim().removePrefix("@").lowercase()

        fun buildE164(countryCode: String, localPhone: String): String {
            val digits = localPhone.replace(Regex("[^0-9]"), "")
            if (digits.isBlank()) return ""
            val cleanCode = "+" + countryCode.replace(Regex("[^0-9]"), "").ifBlank { "1" }
            return if (localPhone.trim().startsWith("+")) {
                "+" + localPhone.replace(Regex("[^0-9]"), "")
            } else {
                "$cleanCode$digits"
            }
        }
    }
}
