package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.AppLanguage
import com.example.data.AuthRepository
import com.example.data.CallStatus
import com.example.data.ChatRepository
import com.example.data.FriendsRepository
import com.example.data.PreferencesManager
import com.example.data.ProfileRepository
import com.example.data.PublicProfile
import com.example.data.SocialAndCallRepository
import com.example.data.StoryPrivacy
import com.example.data.ThemeMode
import com.example.data.UiState
import com.example.localization.LocalStrings
import com.example.localization.stringsFor
import com.example.notifications.NotificationHelper
import com.example.ui.components.HelloAvatar
import com.example.ui.components.HelloBottomNavBar
import com.example.ui.components.MainTab
import com.example.ui.screens.ActiveCallRequest
import com.example.ui.screens.ActiveCallScreen
import com.example.ui.screens.CallsScreen
import com.example.ui.screens.ChatRoomScreen
import com.example.ui.screens.ChatsScreen
import com.example.ui.screens.FriendsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IncomingCallOverlay
import com.example.ui.screens.MyPersonScreen
import com.example.ui.screens.NewGroupDialog
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.screens.StoriesHubScreen
import com.example.ui.screens.StoryCreatorDialog
import com.example.ui.screens.StoryViewerScreen
import com.example.ui.screens.WelcomeLoginScreen
import com.example.ui.screens.resolveChatTitle
import com.example.ui.theme.HelloAppTheme
import com.example.ui.theme.LocalHelloColors
import com.example.viewmodel.ChatRoomViewModel
import com.example.viewmodel.HelloAppViewModel
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

@Serializable data object HomeRoute
@Serializable data object ChatsRoute
@Serializable data object CallsRoute
@Serializable data object ProfileRoute
@Serializable data class ChatRoomRoute(val chatId: String)
@Serializable data object FriendsRoute
@Serializable data object StoriesHubRoute
@Serializable data class StoryViewerRoute(val authorId: String)
@Serializable data object MyPersonRoute

class MainActivity : ComponentActivity() {

    private var deepLinkInviteCode by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.ensureChannels(this)
        extractInviteCode(intent)

        setContent {
            val context = applicationContext
            val prefs = remember { PreferencesManager(context) }
            val authRepo = remember { AuthRepository() }
            val themeMode by prefs.themeModeFlow.collectAsStateWithLifecycle(initialValue = ThemeMode.DARK)
            val language by prefs.languageFlow.collectAsStateWithLifecycle(initialValue = AppLanguage.EN)
            val currentUser by authRepo.authStateFlow().collectAsStateWithLifecycle(initialValue = authRepo.currentUser)
            val scope = rememberCoroutineScope()

            LaunchedEffect(Unit) {
                authRepo.attemptAutoSignIn(this@MainActivity)
            }

            HelloAppTheme(themeMode = themeMode) {
                CompositionLocalProvider(LocalStrings provides stringsFor(language)) {
                    if (currentUser == null) {
                        WelcomeLoginScreen(
                            authRepo = authRepo,
                            currentLanguage = language,
                            onLanguageChange = { lang ->
                                scope.launch { prefs.setLanguage(lang) }
                            },
                            onAuthSuccess = { }
                        )
                    } else {
                        val user = currentUser!!
                        key(user.uid) {
                            AuthenticatedHelloApp(
                                currentUser = user,
                                prefs = prefs,
                                authRepo = authRepo,
                                currentLanguage = language,
                                currentTheme = themeMode,
                                pendingInviteCode = deepLinkInviteCode,
                                onConsumeInviteCode = { deepLinkInviteCode = null }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractInviteCode(intent)
    }

    private fun extractInviteCode(intent: Intent?) {
        val code = intent?.data?.getQueryParameter("code")?.trim()?.uppercase()
        if (!code.isNullOrBlank()) {
            deepLinkInviteCode = code
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AuthenticatedHelloApp(
    currentUser: FirebaseUser,
    prefs: PreferencesManager,
    authRepo: AuthRepository,
    currentLanguage: AppLanguage,
    currentTheme: ThemeMode,
    pendingInviteCode: String?,
    onConsumeInviteCode: () -> Unit
) {
    val context = LocalContext.current
    val activityContext = context
    val scope = rememberCoroutineScope()
    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current
    val databaseId = remember { context.getString(R.string.firestore_database_id) }

    val db = remember(databaseId) { FirebaseFirestore.getInstance(databaseId) }
    val profileRepo = remember(db) { ProfileRepository(db, prefs) }
    val friendsRepo = remember(db) { FriendsRepository(db) }
    val chatRepo = remember(db) { ChatRepository(db, prefs) }
    val socialAndCallRepo = remember(db) { SocialAndCallRepository(db) }

    val factory = remember(currentUser.uid, databaseId) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return HelloAppViewModel(
                    currentUserId = currentUser.uid,
                    db = db,
                    prefs = prefs,
                    profileRepo = profileRepo,
                    friendsRepo = friendsRepo,
                    chatRepo = chatRepo,
                    socialAndCallRepo = socialAndCallRepo
                ) as T
            }
        }
    }

    val viewModel: HelloAppViewModel = viewModel(key = currentUser.uid, factory = factory)
    val myProfileState by viewModel.myProfileState.collectAsStateWithLifecycle()
    val privateAccount by viewModel.privateAccount.collectAsStateWithLifecycle()
    val friendships by viewModel.friendships.collectAsStateWithLifecycle()
    val friendRequests by viewModel.friendRequests.collectAsStateWithLifecycle()
    val chatsState by viewModel.chatsState.collectAsStateWithLifecycle()
    val peerProfiles by viewModel.peerProfiles.collectAsStateWithLifecycle()
    val stories by viewModel.stories.collectAsStateWithLifecycle()
    val myPersonSpace by viewModel.myPersonSpace.collectAsStateWithLifecycle()
    val myPersonMemories by viewModel.myPersonMemories.collectAsStateWithLifecycle()
    val myPersonNotes by viewModel.myPersonNotes.collectAsStateWithLifecycle()
    val calls by viewModel.calls.collectAsStateWithLifecycle()
    val incomingRingingCall by viewModel.incomingRingingCall.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    // Lifecycle online/offline presence updates
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, currentUser.uid) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> viewModel.setOnlinePresence(true)
                Lifecycle.Event.ON_STOP -> viewModel.setOnlinePresence(false)
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Invite code deep link lookup
    var deepLinkTargetProfile by remember { mutableStateOf<PublicProfile?>(null) }
    LaunchedEffect(pendingInviteCode, myProfileState) {
        if (!pendingInviteCode.isNullOrBlank() && myProfileState is UiState.Success && (myProfileState as UiState.Success).data != null) {
            friendsRepo.findUserByInviteCode(pendingInviteCode)
                .onSuccess { found ->
                    if (found != null && found.userId != currentUser.uid) {
                        deepLinkTargetProfile = found
                    } else {
                        viewModel.showBanner("Invite code $pendingInviteCode resolved.")
                    }
                }
                .onFailure {
                    viewModel.showBanner(it.localizedMessage ?: "Invalid invite link.")
                }
            onConsumeInviteCode()
        }
    }

    when (val profileState = myProfileState) {
        is UiState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text("Loading Hello App...", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        is UiState.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = profileState.message,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    OutlinedButton(onClick = { scope.launch { authRepo.signOut(activityContext) } }) {
                        Text(strings.signOut)
                    }
                }
            }
        }

        is UiState.Success -> {
            val myProfile = profileState.data
            if (myProfile == null) {
                ProfileSetupScreen(
                    initialName = currentUser.displayName.orEmpty(),
                    initialEmail = currentUser.email.orEmpty(),
                    initialPhone = currentUser.phoneNumber.orEmpty(),
                    currentLanguage = currentLanguage,
                    currentTheme = currentTheme,
                    onCheckUsername = { profileRepo.isUsernameAvailable(it) },
                    onSaveProfile = { name, username, bio, photoUri, countryCode, phone ->
                        viewModel.saveProfile(
                            displayName = name,
                            username = username,
                            bio = bio,
                            photoUri = photoUri,
                            existingPhotoUrl = currentUser.photoUrl?.toString().orEmpty(),
                            countryCode = countryCode,
                            localPhone = phone,
                            language = currentLanguage,
                            themeMode = currentTheme
                        )
                    },
                    onSignOut = { scope.launch { authRepo.signOut(activityContext) } }
                )
                return
            }

            val navController = rememberNavController()
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination
            val snackbarHostState = remember { SnackbarHostState() }

            var showNewActionSheet by remember { mutableStateOf(false) }
            var showCreateStoryDialog by remember { mutableStateOf(false) }
            var showNewGroupDialog by remember { mutableStateOf(false) }
            var showNotificationsDialog by remember { mutableStateOf(false) }
            var activeCallRequest by remember { mutableStateOf<ActiveCallRequest?>(null) }

            LaunchedEffect(statusBanner) {
                val msg = statusBanner
                if (!msg.isNullOrBlank()) {
                    snackbarHostState.showSnackbar(msg)
                    viewModel.clearBanner()
                }
            }

            val blockedUids = privateAccount?.blockedUids ?: emptyList()
            val chatsList = (chatsState as? UiState.Success)?.data ?: emptyList()
            val unreadTotal = remember(chatsList, currentUser.uid, blockedUids) {
                chatsList.sumOf { chat ->
                    val peerUid = chat.memberUids.firstOrNull { it != currentUser.uid }
                    if (chat.chatType == "DIRECT" && peerUid in blockedUids) 0
                    else (chat.unreadCounts[currentUser.uid] ?: 0L).toInt()
                }
            }
            val missedCallCount = remember(calls, currentUser.uid) {
                calls.count { it.callerId != currentUser.uid && it.status == CallStatus.MISSED.name }
            }
            val incomingPendingRequests = remember(friendRequests, currentUser.uid) {
                friendRequests.filter { it.toUid == currentUser.uid && it.status == "PENDING" }
            }

            val selectedTab: MainTab? = when {
                currentDestination?.hasRoute<HomeRoute>() == true -> MainTab.HOME
                currentDestination?.hasRoute<ChatsRoute>() == true -> MainTab.CHATS
                currentDestination?.hasRoute<CallsRoute>() == true -> MainTab.CALLS
                currentDestination?.hasRoute<ProfileRoute>() == true -> MainTab.PROFILE
                else -> null
            }

            fun navigateTab(tab: MainTab) {
                val route: Any = when (tab) {
                    MainTab.HOME -> HomeRoute
                    MainTab.CHATS -> ChatsRoute
                    MainTab.CALLS -> CallsRoute
                    MainTab.PROFILE -> ProfileRoute
                }
                navController.navigate(route) {
                    popUpTo(navController.graph.findStartDestination().id) {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }
            }

            fun startCall(calleeIds: List<String>, isVideo: Boolean, isGroup: Boolean, peerLabel: String) {
                if (calleeIds.isEmpty()) {
                    viewModel.showBanner("Select a connected friend to place a call.")
                    return
                }
                activeCallRequest = ActiveCallRequest(
                    callId = viewModel.newCallId(),
                    isOutgoing = true,
                    isVideo = isVideo,
                    isGroup = isGroup,
                    calleeIds = calleeIds,
                    peerDisplayName = peerLabel
                )
            }

            Box(modifier = Modifier.fillMaxSize()) {
                Scaffold(
                    contentWindowInsets = WindowInsets.statusBars,
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    bottomBar = {
                        if (selectedTab != null) {
                            HelloBottomNavBar(
                                selectedTab = selectedTab,
                                unreadBadgeCount = unreadTotal,
                                missedCallCount = missedCallCount,
                                onSelectTab = ::navigateTab,
                                onNewActionClick = { showNewActionSheet = true }
                            )
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = HomeRoute,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        composable<HomeRoute> {
                            HomeScreen(
                                currentUserId = currentUser.uid,
                                myProfile = myProfile,
                                chatsState = chatsState,
                                peerProfiles = peerProfiles,
                                stories = stories,
                                pendingRequests = incomingPendingRequests,
                                blockedUids = blockedUids,
                                onOpenChat = { chatId -> navController.navigate(ChatRoomRoute(chatId)) },
                                onQuickAudioCall = { peerUid, peerName ->
                                    startCall(listOf(peerUid), isVideo = false, isGroup = false, peerLabel = peerName)
                                },
                                onCreateStory = { showCreateStoryDialog = true },
                                onViewAuthorStories = { authorId -> navController.navigate(StoryViewerRoute(authorId)) },
                                onOpenMyPerson = { navController.navigate(MyPersonRoute) },
                                onOpenStoriesHub = { navController.navigate(StoriesHubRoute) },
                                onOpenFriends = { navController.navigate(FriendsRoute) },
                                onOpenNotifications = { showNotificationsDialog = true }
                            )
                        }

                        composable<ChatsRoute> {
                            ChatsScreen(
                                currentUserId = currentUser.uid,
                                chatsState = chatsState,
                                friendships = friendships,
                                peerProfiles = peerProfiles,
                                blockedUids = blockedUids,
                                onOpenChat = { chatId -> navController.navigate(ChatRoomRoute(chatId)) },
                                onQuickAudioCall = { peerUid, peerName ->
                                    startCall(listOf(peerUid), isVideo = false, isGroup = false, peerLabel = peerName)
                                },
                                onCreateGroup = { title, members ->
                                    viewModel.createGroupChat(title, members) { chatId ->
                                        navController.navigate(ChatRoomRoute(chatId))
                                    }
                                },
                                onOpenFriends = { navController.navigate(FriendsRoute) }
                            )
                        }

                        composable<CallsRoute> {
                            CallsScreen(
                                currentUserId = currentUser.uid,
                                calls = calls,
                                friendships = friendships,
                                peerProfiles = peerProfiles,
                                onStartCall = { calleeIds, isVideo, isGroup, label ->
                                    startCall(calleeIds, isVideo, isGroup, label)
                                }
                            )
                        }

                        composable<ProfileRoute> {
                            ProfileSettingsScreen(
                                myProfile = myProfile,
                                privateAccount = privateAccount,
                                peerProfiles = peerProfiles,
                                currentLanguage = currentLanguage,
                                currentTheme = currentTheme,
                                onEditProfile = { name, username, bio, photoUri ->
                                    viewModel.saveProfile(
                                        displayName = name,
                                        username = username,
                                        bio = bio,
                                        photoUri = photoUri,
                                        existingPhotoUrl = myProfile.photoUrl,
                                        countryCode = privateAccount?.countryCode ?: "+1",
                                        localPhone = privateAccount?.phoneNumber.orEmpty(),
                                        language = currentLanguage,
                                        themeMode = currentTheme
                                    )
                                },
                                onUpdateSettings = { showOnline, showReceipts, storyPrivacy, lang, theme, notif ->
                                    viewModel.updateSettings(showOnline, showReceipts, storyPrivacy, lang, theme, notif)
                                },
                                onUnblockUser = { viewModel.unblockUser(it) },
                                onOpenFriends = { navController.navigate(FriendsRoute) },
                                onOpenMyPerson = { navController.navigate(MyPersonRoute) },
                                onSignOut = {
                                    viewModel.setOnlinePresence(false)
                                    scope.launch { authRepo.signOut(activityContext) }
                                },
                                onDeleteAccount = {
                                    scope.launch {
                                        viewModel.deleteAccountData()
                                        authRepo.deleteCurrentAuthUser()
                                        authRepo.signOut(activityContext)
                                    }
                                }
                            )
                        }

                        composable<ChatRoomRoute> { entry ->
                            val route = entry.toRoute<ChatRoomRoute>()
                            val chat = chatsList.firstOrNull { it.id == route.chatId }
                            if (chat == null) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            } else {
                                val roomFactory = remember(chat.id, currentUser.uid) {
                                    object : ViewModelProvider.Factory {
                                        @Suppress("UNCHECKED_CAST")
                                        override fun <T : ViewModel> create(modelClass: Class<T>): T {
                                            return ChatRoomViewModel(
                                                chatId = chat.id,
                                                currentUserId = currentUser.uid,
                                                chatRepo = chatRepo,
                                                profileRepo = profileRepo,
                                                prefs = prefs
                                            ) as T
                                        }
                                    }
                                }
                                val roomVm: ChatRoomViewModel = viewModel(
                                    key = "${currentUser.uid}_${chat.id}",
                                    factory = roomFactory
                                )
                                val chatTitle = resolveChatTitle(chat, currentUser.uid, peerProfiles)
                                ChatRoomScreen(
                                    chat = chat,
                                    allChats = chatsList,
                                    myProfile = myProfile,
                                    peerProfiles = peerProfiles,
                                    showReadReceipts = privateAccount?.showReadReceipts ?: true,
                                    viewModel = roomVm,
                                    onBack = { navController.popBackStack() },
                                    onStartAudioCall = { calleeIds ->
                                        startCall(calleeIds, isVideo = false, isGroup = chat.chatType == "GROUP", peerLabel = chatTitle)
                                    },
                                    onStartVideoCall = { calleeIds ->
                                        startCall(calleeIds, isVideo = true, isGroup = chat.chatType == "GROUP", peerLabel = chatTitle)
                                    }
                                )
                            }
                        }

                        composable<FriendsRoute> {
                            FriendsScreen(
                                currentUserId = currentUser.uid,
                                myProfile = myProfile,
                                friendships = friendships,
                                friendRequests = friendRequests,
                                peerProfiles = peerProfiles,
                                blockedUids = blockedUids,
                                onSearchByUsername = { viewModel.searchByUsername(it) },
                                onSearchByPhone = { cc, ph -> viewModel.searchByPhone(cc, ph) },
                                onSearchByInviteCode = { viewModel.searchByInviteCode(it) },
                                onDiscoverContacts = { viewModel.discoverContacts(it) },
                                onSendRequest = { viewModel.sendFriendRequest(it) },
                                onRespondRequest = { req, accept -> viewModel.respondToRequest(req, accept) },
                                onCancelRequest = { viewModel.cancelRequest(it) },
                                onToggleFavorite = { viewModel.toggleFavorite(it) },
                                onOpenChat = { peerUid ->
                                    viewModel.openOrCreateDirectChat(peerUid) { chatId ->
                                        navController.navigate(ChatRoomRoute(chatId))
                                    }
                                },
                                onStartAudioCall = { peerUid ->
                                    val name = peerProfiles[peerUid]?.displayName ?: "Friend"
                                    startCall(listOf(peerUid), isVideo = false, isGroup = false, peerLabel = name)
                                },
                                onSelectMyPerson = { partnerUid ->
                                    viewModel.selectMyPerson(partnerUid)
                                },
                                onBlockUser = { viewModel.blockUser(it) },
                                onReportUser = { targetUid, reason, details ->
                                    viewModel.reportUser(targetUid, reason, details)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<StoriesHubRoute> {
                            StoriesHubScreen(
                                currentUserId = currentUser.uid,
                                stories = stories,
                                peerProfiles = peerProfiles,
                                onViewAuthorStories = { authorId -> navController.navigate(StoryViewerRoute(authorId)) },
                                onCreateTextStory = { text, hex, priv -> viewModel.postTextStory(text, hex, priv) },
                                onCreateMediaStory = { uri, isVideo, caption, priv ->
                                    viewModel.postMediaStory(uri, isVideo, caption, priv)
                                },
                                onDeleteStory = { viewModel.deleteStory(it) },
                                onBack = { navController.popBackStack() }
                            )
                        }

                        composable<StoryViewerRoute> { entry ->
                            val route = entry.toRoute<StoryViewerRoute>()
                            val authorStories = remember(stories, route.authorId) {
                                stories.filter { it.authorId == route.authorId }
                            }
                            StoryViewerScreen(
                                stories = authorStories,
                                currentUserId = currentUser.uid,
                                onMarkViewed = { viewModel.markStoryViewed(it) },
                                onDeleteStory = { viewModel.deleteStory(it) },
                                onClose = { navController.popBackStack() }
                            )
                        }

                        composable<MyPersonRoute> {
                            MyPersonScreen(
                                currentUserId = currentUser.uid,
                                space = myPersonSpace,
                                memories = myPersonMemories,
                                notes = myPersonNotes,
                                friendships = friendships,
                                peerProfiles = peerProfiles,
                                onSelectMyPerson = { viewModel.selectMyPerson(it) },
                                onSendHug = { viewModel.sendVirtualHug() },
                                onUpdateMood = { viewModel.updateMyMood(it) },
                                onUpdateDates = { anniv, bday -> viewModel.updateMyPersonDates(anniv, bday) },
                                onAddMemory = { title, desc, label, uri -> viewModel.addMemory(title, desc, label, uri) },
                                onAddNote = { content, tag -> viewModel.addSpecialNote(content, tag) },
                                onTogglePinNote = { viewModel.togglePinNote(it) },
                                onMessagePartner = { partnerUid ->
                                    viewModel.openOrCreateDirectChat(partnerUid) { chatId ->
                                        navController.navigate(ChatRoomRoute(chatId))
                                    }
                                },
                                onCallPartner = { partnerUid, isVideo ->
                                    val name = peerProfiles[partnerUid]?.displayName ?: "My Person"
                                    startCall(listOf(partnerUid), isVideo = isVideo, isGroup = false, peerLabel = name)
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }

                // Incoming Ringing Call Overlay
                val ringing = incomingRingingCall
                if (ringing != null && activeCallRequest == null) {
                    IncomingCallOverlay(
                        call = ringing,
                        onAccept = { isVideo ->
                            activeCallRequest = ActiveCallRequest(
                                callId = ringing.id,
                                isOutgoing = false,
                                isVideo = isVideo,
                                isGroup = ringing.callType.contains("GROUP"),
                                calleeIds = ringing.participantUids.filter { it != currentUser.uid },
                                peerDisplayName = ringing.callerName.ifBlank { "Caller" }
                            )
                        },
                        onDecline = { viewModel.declineIncomingCall(ringing.id) }
                    )
                }

                // Active WebRTC Call Screen Overlay
                val currentCall = activeCallRequest
                if (currentCall != null) {
                    ActiveCallScreen(
                        request = currentCall,
                        currentUserId = currentUser.uid,
                        myProfile = myProfile,
                        socialAndCallRepo = socialAndCallRepo,
                        onCallEnded = { activeCallRequest = null }
                    )
                }
            }

            // New (+) Quick Action Sheet
            if (showNewActionSheet) {
                ModalBottomSheet(onDismissRequest = { showNewActionSheet = false }) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 24.dp)
                    ) {
                        Text(
                            text = "Start Something New",
                            style = MaterialTheme.typography.titleLarge,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                        )
                        ListItem(
                            headlineContent = { Text("Find Friends / QR / Contacts") },
                            supportingContent = { Text("Connect via username, international phone, QR, or invite link") },
                            leadingContent = { Icon(Icons.Filled.PersonAdd, null, tint = MaterialTheme.colorScheme.primary) },
                            modifier = Modifier
                                .clickable {
                                    showNewActionSheet = false
                                    navController.navigate(FriendsRoute)
                                }
                                .testTag("new_sheet_find_friends")
                        )
                        ListItem(
                            headlineContent = { Text("Create Encrypted Group") },
                            supportingContent = { Text("Multi-member E2EE chat room") },
                            leadingContent = { Icon(Icons.Filled.GroupAdd, null, tint = MaterialTheme.colorScheme.secondary) },
                            modifier = Modifier.clickable {
                                showNewActionSheet = false
                                showNewGroupDialog = true
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Share 24h Story") },
                            supportingContent = { Text("Photo, video, or text status with privacy control") },
                            leadingContent = { Icon(Icons.Filled.AddCircle, null, tint = helloColors.myPersonAccent) },
                            modifier = Modifier.clickable {
                                showNewActionSheet = false
                                showCreateStoryDialog = true
                            }
                        )
                        ListItem(
                            headlineContent = { Text("Start Audio or Video Call") },
                            supportingContent = { Text("1:1 or group WebRTC call") },
                            leadingContent = { Icon(Icons.Filled.Call, null, tint = helloColors.onlineDot) },
                            modifier = Modifier.clickable {
                                showNewActionSheet = false
                                navigateTab(MainTab.CALLS)
                            }
                        )
                    }
                }
            }

            if (showCreateStoryDialog) {
                StoryCreatorDialog(
                    onDismiss = { showCreateStoryDialog = false },
                    onPostText = { text, hex, priv ->
                        showCreateStoryDialog = false
                        viewModel.postTextStory(text, hex, priv)
                    },
                    onPostMedia = { uri, isVideo, caption, priv ->
                        showCreateStoryDialog = false
                        viewModel.postMediaStory(uri, isVideo, caption, priv)
                    }
                )
            }

            if (showNewGroupDialog) {
                val friendProfiles = friendships.mapNotNull { f ->
                    val peerUid = f.memberUids.firstOrNull { it != currentUser.uid }
                    peerUid?.let { peerProfiles[it] }
                }
                NewGroupDialog(
                    friends = friendProfiles,
                    onDismiss = { showNewGroupDialog = false },
                    onCreate = { title, selected ->
                        showNewGroupDialog = false
                        viewModel.createGroupChat(title, selected) { chatId ->
                            navController.navigate(ChatRoomRoute(chatId))
                        }
                    }
                )
            }

            if (showNotificationsDialog) {
                val recentMissed = calls.filter {
                    it.callerId != currentUser.uid && it.status == CallStatus.MISSED.name
                }.take(5)
                AlertDialog(
                    onDismissRequest = { showNotificationsDialog = false },
                    title = { Text(strings.notificationSettings) },
                    text = {
                        if (incomingPendingRequests.isEmpty() && recentMissed.isEmpty()) {
                            Text("All caught up! No pending friend requests or missed calls.")
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (incomingPendingRequests.isNotEmpty()) {
                                    Text("Friend Requests", style = MaterialTheme.typography.titleSmall)
                                    incomingPendingRequests.forEach { req ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            HelloAvatar(name = req.fromName, photoUrl = req.fromPhotoUrl, size = 36.dp)
                                            Spacer(Modifier.width(8.dp))
                                            Text(req.fromName, modifier = Modifier.weight(1f))
                                            IconButton(onClick = { viewModel.respondToRequest(req, true) }) {
                                                Icon(Icons.Filled.Check, "Accept", tint = helloColors.onlineDot)
                                            }
                                            IconButton(onClick = { viewModel.respondToRequest(req, false) }) {
                                                Icon(Icons.Filled.Close, "Decline", tint = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    }
                                }
                                if (recentMissed.isNotEmpty()) {
                                    HorizontalDivider()
                                    Text("Missed Calls", style = MaterialTheme.typography.titleSmall)
                                    recentMissed.forEach { missed ->
                                        Text(
                                            text = "Missed ${missed.callType.lowercase()} call from ${missed.callerName}",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showNotificationsDialog = false }) { Text("Close") }
                    }
                )
            }

            if (deepLinkTargetProfile != null) {
                val target = deepLinkTargetProfile!!
                AlertDialog(
                    onDismissRequest = { deepLinkTargetProfile = null },
                    title = { Text("Hello App Invite") },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HelloAvatar(name = target.displayName, photoUrl = target.photoUrl, size = 50.dp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(target.displayName, style = MaterialTheme.typography.titleMedium)
                                Text("@${target.username}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            viewModel.sendFriendRequest(target)
                            deepLinkTargetProfile = null
                        }) {
                            Text("Send Friend Request")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { deepLinkTargetProfile = null }) { Text("Cancel") }
                    }
                )
            }
        }
    }
}
