package com.example.ui.screens

import android.app.Activity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.AppLanguage
import com.example.data.AuthRepository
import com.example.data.GoogleSignInOutcome
import com.example.data.ProfileRepository
import com.example.data.ThemeMode
import com.example.localization.LocalStrings
import com.example.ui.components.HelloHLogo
import com.example.ui.theme.HelloBlue
import com.example.ui.theme.HelloViolet
import com.example.ui.theme.LocalHelloColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.OnlineGreen
import kotlinx.coroutines.launch

data class CountryDialCode(val flag: String, val name: String, val dialCode: String)

val SUPPORTED_COUNTRY_CODES = listOf(
    CountryDialCode("BD", "Bangladesh", "+880"),
    CountryDialCode("US", "United States", "+1"),
    CountryDialCode("GB", "United Kingdom", "+44"),
    CountryDialCode("IN", "India", "+91"),
    CountryDialCode("AE", "UAE", "+971"),
    CountryDialCode("SG", "Singapore", "+65"),
    CountryDialCode("MY", "Malaysia", "+60"),
    CountryDialCode("SA", "Saudi Arabia", "+966"),
    CountryDialCode("CA", "Canada", "+1"),
    CountryDialCode("AU", "Australia", "+61")
)

@Composable
fun WelcomeLoginScreen(
    authRepo: AuthRepository,
    currentLanguage: AppLanguage,
    onLanguageChange: (AppLanguage) -> Unit,
    onAuthSuccess: () -> Unit
) {
    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isLoading by remember { mutableStateOf(false) }
    var authError by remember { mutableStateOf<String?>(null) }
    var showPhoneAuth by remember { mutableStateOf(false) }
    var showRecoveryDialog by remember { mutableStateOf(false) }

    var selectedCountry by remember { mutableStateOf(SUPPORTED_COUNTRY_CODES.first()) }
    var countryDropdownExpanded by remember { mutableStateOf(false) }
    var phoneInput by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var otpInput by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Language Toggle Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "ECDH P-256 + AES-GCM",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable {
                            onLanguageChange(if (currentLanguage == AppLanguage.EN) AppLanguage.BN else AppLanguage.EN)
                        }
                        .testTag("welcome_language_toggle")
                ) {
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "বাংলা" else "English",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Hero Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 500.dp)
                    .height(165.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_welcome_hero),
                    contentDescription = "Hello App Welcome Art",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color(0xCC101218))
                            )
                        )
                )
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HelloHLogo(size = 54.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(
                            text = strings.appName,
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = strings.tagline,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFD6DCFA)
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (authError != null) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = authError.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }

                // Primary Google Sign-In via Credential Manager
                Button(
                    onClick = {
                        authError = null
                        isLoading = true
                        scope.launch {
                            when (val outcome = authRepo.signInWithGoogle(context)) {
                                GoogleSignInOutcome.Success -> {
                                    isLoading = false
                                    onAuthSuccess()
                                }
                                GoogleSignInOutcome.Cancelled -> {
                                    isLoading = false
                                    authError = "Sign-in was cancelled. Tap to choose a Google account."
                                }
                                is GoogleSignInOutcome.Error -> {
                                    isLoading = false
                                    authError = outcome.message
                                }
                            }
                        }
                    },
                    enabled = !isLoading,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    contentPadding = ButtonDefaults.ContentPadding,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.horizontalGradient(listOf(HelloViolet, HelloBlue)))
                        .testTag("google_sign_in_button")
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(
                            text = strings.signInGoogle,
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White
                        )
                    }
                }

                // Phone Number + Country Code OTP Toggle
                OutlinedButton(
                    onClick = { showPhoneAuth = !showPhoneAuth },
                    enabled = !isLoading,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("phone_sign_in_toggle")
                ) {
                    Icon(Icons.Filled.Phone, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(strings.signInPhone, style = MaterialTheme.typography.labelLarge)
                }

                AnimatedVisibility(visible = showPhoneAuth) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, helloColors.subtleDivider),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier
                                            .height(56.dp)
                                            .clickable { countryDropdownExpanded = true }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${selectedCountry.flag} ${selectedCountry.dialCode}",
                                                style = MaterialTheme.typography.labelLarge
                                            )
                                        }
                                    }
                                    DropdownMenu(
                                        expanded = countryDropdownExpanded,
                                        onDismissRequest = { countryDropdownExpanded = false }
                                    ) {
                                        SUPPORTED_COUNTRY_CODES.forEach { item ->
                                            DropdownMenuItem(
                                                text = { Text("${item.flag} ${item.name} (${item.dialCode})") },
                                                onClick = {
                                                    selectedCountry = item
                                                    countryDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = phoneInput,
                                    onValueChange = { phoneInput = it },
                                    label = { Text("Phone Number") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("phone_number_input")
                                )
                            }

                            if (verificationId == null) {
                                Button(
                                    onClick = {
                                        val e164 = ProfileRepository.buildE164(selectedCountry.dialCode, phoneInput)
                                        if (e164.length < 8) {
                                            authError = "Please enter a valid international phone number."
                                            return@Button
                                        }
                                        val act = context as? Activity ?: return@Button
                                        authError = null
                                        isLoading = true
                                        authRepo.startPhoneVerification(
                                            activity = act,
                                            e164PhoneNumber = e164,
                                            onCodeSent = { vId ->
                                                isLoading = false
                                                verificationId = vId
                                            },
                                            onAutoVerified = {
                                                isLoading = false
                                                onAuthSuccess()
                                            },
                                            onError = { msg ->
                                                isLoading = false
                                                authError = msg
                                            }
                                        )
                                    },
                                    enabled = !isLoading,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("send_otp_button")
                                ) {
                                    Icon(Icons.Filled.Sms, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Send OTP Code")
                                }
                            } else {
                                OutlinedTextField(
                                    value = otpInput,
                                    onValueChange = { otpInput = it },
                                    label = { Text("6-Digit OTP Code") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("otp_code_input")
                                )
                                Button(
                                    onClick = {
                                        val vId = verificationId ?: return@Button
                                        isLoading = true
                                        authError = null
                                        scope.launch {
                                            authRepo.verifyPhoneOtp(vId, otpInput)
                                                .onSuccess {
                                                    isLoading = false
                                                    onAuthSuccess()
                                                }
                                                .onFailure {
                                                    isLoading = false
                                                    authError = it.localizedMessage ?: "Invalid OTP code."
                                                }
                                        }
                                    },
                                    enabled = !isLoading && otpInput.length >= 6,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("verify_otp_button")
                                ) {
                                    Text("Verify OTP & Sign In")
                                }
                            }
                        }
                    }
                }

                // Apple Sign-In (Android OAuth Provider)
                OutlinedButton(
                    onClick = {
                        val act = context as? Activity ?: return@OutlinedButton
                        authError = null
                        isLoading = true
                        scope.launch {
                            authRepo.signInWithApple(act)
                                .onSuccess {
                                    isLoading = false
                                    onAuthSuccess()
                                }
                                .onFailure { err ->
                                    isLoading = false
                                    authError = err.localizedMessage
                                }
                        }
                    },
                    enabled = !isLoading,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("apple_sign_in_button")
                ) {
                    Icon(Icons.Filled.AccountCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(strings.signInApple, style = MaterialTheme.typography.labelLarge)
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = helloColors.subtleDivider
                )

                TextButton(
                    onClick = { showRecoveryDialog = true },
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .testTag("account_recovery_button")
                ) {
                    Icon(Icons.Filled.HelpOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.accountRecovery)
                }
            }
        }
    }

    if (showRecoveryDialog) {
        AlertDialog(
            onDismissRequest = { showRecoveryDialog = false },
            title = { Text(strings.accountRecovery) },
            text = {
                Text(
                    "Your Hello App account is tied to your verified Google, Phone, or Apple identity.\n\n" +
                        "• Sign in again with the same Google account or verified phone number to restore all chats, friends, stories, and My Person memories.\n" +
                        "• Note: End-to-End Encryption private keys live locally on your device. Switching devices rotates your public key and updates your Safety Number."
                )
            },
            confirmButton = {
                TextButton(onClick = { showRecoveryDialog = false }) { Text("Got it") }
            }
        )
    }
}

@Composable
fun ProfileSetupScreen(
    initialName: String,
    initialEmail: String,
    initialPhone: String,
    currentLanguage: AppLanguage,
    currentTheme: ThemeMode,
    onCheckUsername: suspend (String) -> Result<Boolean>,
    onSaveProfile: (
        displayName: String,
        username: String,
        bio: String,
        photoUri: Uri?,
        countryCode: String,
        localPhone: String
    ) -> Unit,
    onSignOut: () -> Unit
) {
    val strings = LocalStrings.current
    val scope = rememberCoroutineScope()
    var displayName by remember { mutableStateOf(initialName) }
    var username by remember {
        mutableStateOf(
            initialName.lowercase().replace(Regex("[^a-z0-9_]"), "_").take(20).trim('_')
        )
    }
    var bio by remember { mutableStateOf("Hey there! I'm on Hello App.") }
    var selectedCountry by remember { mutableStateOf(SUPPORTED_COUNTRY_CODES.first()) }
    var localPhone by remember { mutableStateOf(initialPhone) }
    var selectedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var usernameStatus by remember { mutableStateOf<String?>(null) }
    var usernameAvailable by remember { mutableStateOf<Boolean?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) selectedPhotoUri = uri
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                HelloHLogo(size = 38.dp)
                TextButton(onClick = onSignOut) {
                    Text(strings.signOut)
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                text = strings.completeProfile,
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )
            if (initialEmail.isNotBlank()) {
                Text(
                    text = initialEmail,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(20.dp))

            // Avatar Photo Picker
            Box(
                modifier = Modifier
                    .size(104.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .border(2.dp, Brush.linearGradient(listOf(HelloViolet, HelloBlue)), CircleShape)
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
                    .testTag("profile_setup_photo_picker"),
                contentAlignment = Alignment.Center
            ) {
                if (selectedPhotoUri != null) {
                    AsyncImage(
                        model = selectedPhotoUri,
                        contentDescription = "Selected avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.CameraAlt,
                        contentDescription = "Choose profile photo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Tap to pick profile photo",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(20.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text(strings.displayName) },
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setup_display_name_input")
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = {
                        username = it.lowercase().replace(" ", "_")
                        usernameAvailable = null
                        usernameStatus = null
                    },
                    label = { Text(strings.username) },
                    leadingIcon = { Icon(Icons.Filled.AlternateEmail, contentDescription = null) },
                    trailingIcon = {
                        TextButton(onClick = {
                            scope.launch {
                                onCheckUsername(username)
                                    .onSuccess { avail ->
                                        usernameAvailable = avail
                                        usernameStatus = if (avail) "Available!" else "Already taken"
                                    }
                                    .onFailure { err ->
                                        usernameAvailable = false
                                        usernameStatus = err.localizedMessage
                                    }
                            }
                        }) {
                            Text("Check")
                        }
                    },
                    supportingText = usernameStatus?.let { msg ->
                        {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (usernameAvailable == true) {
                                    Icon(Icons.Filled.CheckCircle, null, tint = OnlineGreen, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(4.dp))
                                }
                                Text(
                                    text = msg,
                                    color = if (usernameAvailable == true) OnlineGreen else MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setup_username_input")
                )

                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text(strings.bio) },
                    maxLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("setup_bio_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = selectedCountry.dialCode,
                        onValueChange = { code ->
                            selectedCountry = CountryDialCode("", "Custom", code)
                        },
                        label = { Text("Code") },
                        singleLine = true,
                        modifier = Modifier.width(96.dp)
                    )
                    OutlinedTextField(
                        value = localPhone,
                        onValueChange = { localPhone = it },
                        label = { Text(strings.phoneOptional) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("setup_phone_input")
                    )
                }

                Spacer(Modifier.height(8.dp))

                Button(
                    onClick = {
                        isSaving = true
                        onSaveProfile(
                            displayName,
                            username,
                            bio,
                            selectedPhotoUri,
                            selectedCountry.dialCode,
                            localPhone
                        )
                    },
                    enabled = !isSaving && displayName.isNotBlank() && username.length >= 3,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.horizontalGradient(listOf(HelloViolet, HelloBlue)))
                        .testTag("setup_save_button")
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Text(strings.saveAndContinue, color = Color.White, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}
