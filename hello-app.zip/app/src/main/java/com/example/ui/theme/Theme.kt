package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.data.ThemeMode

@Immutable
data class HelloExtendedColors(
    val onlineDot: Color,
    val awayDot: Color,
    val callEnd: Color,
    val myPersonAccent: Color,
    val sentBubbleStart: Color,
    val sentBubbleEnd: Color,
    val receivedBubble: Color,
    val cardElevated: Color,
    val subtleDivider: Color,
    val isDark: Boolean
)

val LocalHelloColors = staticCompositionLocalOf {
    HelloExtendedColors(
        onlineDot = OnlineGreen,
        awayDot = AwayAmber,
        callEnd = CallRed,
        myPersonAccent = MyPersonRose,
        sentBubbleStart = HelloViolet,
        sentBubbleEnd = HelloBlue,
        receivedBubble = CharcoalElevated,
        cardElevated = CharcoalCard,
        subtleDivider = CharcoalOutline,
        isDark = true
    )
}

private val HelloDarkColorScheme = darkColorScheme(
    primary = HelloViolet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2B2250),
    onPrimaryContainer = Color(0xFFE4DBFF),
    secondary = HelloBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF1C2E4E),
    onSecondaryContainer = Color(0xFFD6E6FF),
    tertiary = MyPersonRose,
    onTertiary = Color.White,
    background = CharcoalBg,
    onBackground = CharcoalTextPrimary,
    surface = CharcoalSurface,
    onSurface = CharcoalTextPrimary,
    surfaceVariant = CharcoalElevated,
    onSurfaceVariant = CharcoalTextSecondary,
    outline = CharcoalOutline,
    error = CallRed,
    onError = Color.White
)

private val HelloLightColorScheme = lightColorScheme(
    primary = HelloVioletDark,
    onPrimary = Color.White,
    primaryContainer = HelloVioletSoft,
    onPrimaryContainer = Color(0xFF2B146B),
    secondary = HelloBlue,
    onSecondary = Color.White,
    secondaryContainer = HelloBlueSoft,
    onSecondaryContainer = Color(0xFF102A5E),
    tertiary = MyPersonRose,
    onTertiary = Color.White,
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightElevated,
    onSurfaceVariant = LightTextSecondary,
    outline = LightOutline,
    error = CallRed,
    onError = Color.White
)

@Composable
fun HelloAppTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (useDark) HelloDarkColorScheme else HelloLightColorScheme
    val extendedColors = if (useDark) {
        HelloExtendedColors(
            onlineDot = OnlineGreen,
            awayDot = AwayAmber,
            callEnd = CallRed,
            myPersonAccent = MyPersonRose,
            sentBubbleStart = HelloViolet,
            sentBubbleEnd = HelloBlue,
            receivedBubble = CharcoalElevated,
            cardElevated = CharcoalCard,
            subtleDivider = CharcoalOutline,
            isDark = true
        )
    } else {
        HelloExtendedColors(
            onlineDot = OnlineGreen,
            awayDot = AwayAmber,
            callEnd = CallRed,
            myPersonAccent = MyPersonRose,
            sentBubbleStart = HelloVioletDark,
            sentBubbleEnd = HelloBlue,
            receivedBubble = LightElevated,
            cardElevated = LightCard,
            subtleDivider = LightOutline,
            isDark = false
        )
    }

    CompositionLocalProvider(LocalHelloColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = HelloTypography,
            content = content
        )
    }
}
