package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.HelloBlue
import com.example.ui.theme.HelloViolet

/**
 * Original stylized Hello App "H" emblem featuring two clean pillars
 * bridged by a flowing purple-to-blue connection ribbon.
 */
@Composable
fun HelloHLogo(
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    showContainer: Boolean = true
) {
    val containerModifier = if (showContainer) {
        modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0xFF1E1B3A), Color(0xFF151828))
                )
            )
    } else {
        modifier.size(size)
    }

    Box(modifier = containerModifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(size * 0.64f)) {
            val w = this.size.width
            val h = this.size.height
            val stroke = w * 0.20f

            val pillarBrush = Brush.verticalGradient(
                colors = listOf(Color(0xFFE9E6FF), Color(0xFFA7B5E8))
            )
            val bridgeBrush = Brush.linearGradient(
                colors = listOf(HelloViolet, HelloBlue),
                start = Offset(0f, h * 0.7f),
                end = Offset(w, h * 0.3f)
            )

            // Left pillar (top segment)
            drawRoundRect(
                brush = pillarBrush,
                topLeft = Offset(w * 0.08f, h * 0.05f),
                size = androidx.compose.ui.geometry.Size(stroke, h * 0.56f),
                cornerRadius = CornerRadius(stroke / 2f, stroke / 2f)
            )
            // Right pillar (bottom segment)
            drawRoundRect(
                brush = pillarBrush,
                topLeft = Offset(w - w * 0.08f - stroke, h * 0.39f),
                size = androidx.compose.ui.geometry.Size(stroke, h * 0.56f),
                cornerRadius = CornerRadius(stroke / 2f, stroke / 2f)
            )

            // Flowing S-curve H bridge connecting bottom-left to top-right
            val bridgePath = Path().apply {
                moveTo(w * 0.08f + stroke / 2f, h * 0.86f)
                cubicTo(
                    w * 0.08f + stroke / 2f, h * 0.48f,
                    w - w * 0.08f - stroke / 2f, h * 0.52f,
                    w - w * 0.08f - stroke / 2f, h * 0.14f
                )
            }
            drawPath(
                path = bridgePath,
                brush = bridgeBrush,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
fun HelloBrandWordmark(
    title: String,
    subtitle: String? = null,
    logoSize: Dp = 36.dp
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        HelloHLogo(size = logoSize)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
