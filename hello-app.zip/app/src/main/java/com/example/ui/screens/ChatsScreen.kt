package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.Chat
import com.example.data.Friendship
import com.example.data.PublicProfile
import com.example.data.UiState
import com.example.localization.LocalStrings
import com.example.ui.components.HelloAvatar

private enum class ChatFilter(val label: String) {
    ALL("All"),
    UNREAD("Unread"),
    GROUPS("Groups"),
    FAVORITES("Favorites")
}

@Composable
fun ChatsScreen(
    currentUserId: String,
    chatsState: UiState<List<Chat>>,
    friendships: List<Friendship>,
    peerProfiles: Map<String, PublicProfile>,
    blockedUids: List<String>,
    onOpenChat: (String) -> Unit,
    onQuickAudioCall: (peerUid: String, peerName: String) -> Unit,
    onCreateGroup: (title: String, members: List<PublicProfile>) -> Unit,
    onOpenFriends: () -> Unit
) {
    val strings = LocalStrings.current
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(ChatFilter.ALL) }
    var showNewGroupDialog by remember { mutableStateOf(false) }

    val favoriteUids = remember(friendships, currentUserId) {
        friendships.filter { currentUserId in it.favoriteBy }
            .flatMap { it.memberUids }
            .filter { it != currentUserId }
            .toSet()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.navChats,
                style = MaterialTheme.typography.headlineMedium
            )
            Row {
                IconButton(
                    onClick = onOpenFriends,
                    modifier = Modifier.testTag("chats_add_friend_btn")
                ) {
                    Icon(Icons.Filled.PersonAdd, contentDescription = "Add Friend")
                }
                IconButton(
                    onClick = { showNewGroupDialog = true },
                    modifier = Modifier.testTag("chats_new_group_btn")
                ) {
                    Icon(Icons.Filled.GroupAdd, contentDescription = "New Group")
                }
            }
        }

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text(strings.searchChatsPlaceholder) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("chats_search_input")
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ChatFilter.entries) { item ->
                FilterChip(
                    selected = filter == item,
                    onClick = { filter = item },
                    label = { Text(item.label) }
                )
            }
        }

        when (chatsState) {
            is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(chatsState.message, color = MaterialTheme.colorScheme.error)
            }
            is UiState.Success -> {
                val filtered = remember(chatsState.data, search, filter, favoriteUids, blockedUids, peerProfiles) {
                    chatsState.data.filter { chat ->
                        val peerUid = chat.memberUids.firstOrNull { it != currentUserId }
                        if (chat.chatType == "DIRECT" && peerUid in blockedUids) return@filter false
                        val matchesFilter = when (filter) {
                            ChatFilter.ALL -> true
                            ChatFilter.UNREAD -> (chat.unreadCounts[currentUserId] ?: 0L) > 0L
                            ChatFilter.GROUPS -> chat.chatType == "GROUP"
                            ChatFilter.FAVORITES -> peerUid != null && peerUid in favoriteUids
                        }
                        val title = resolveChatTitle(chat, currentUserId, peerProfiles)
                        val matchesQuery = search.isBlank() ||
                            title.contains(search, ignoreCase = true) ||
                            chat.lastMessagePreview.contains(search, ignoreCase = true)
                        matchesFilter && matchesQuery
                    }
                }

                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No matching conversations.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(filtered, key = { it.id }) { chat ->
                            HomeChatRow(
                                chat = chat,
                                currentUserId = currentUserId,
                                peerProfiles = peerProfiles,
                                onClick = { onOpenChat(chat.id) },
                                onQuickAudioCall = {
                                    val peerUid = chat.memberUids.firstOrNull { it != currentUserId }
                                    if (peerUid != null) {
                                        onQuickAudioCall(peerUid, resolveChatTitle(chat, currentUserId, peerProfiles))
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNewGroupDialog) {
        val friendProfiles = friendships.mapNotNull { f ->
            val peerUid = f.memberUids.firstOrNull { it != currentUserId }
            peerUid?.let { peerProfiles[it] }
        }
        NewGroupDialog(
            friends = friendProfiles,
            onDismiss = { showNewGroupDialog = false },
            onCreate = { title, selected ->
                showNewGroupDialog = false
                onCreateGroup(title, selected)
            }
        )
    }
}

@Composable
fun NewGroupDialog(
    friends: List<PublicProfile>,
    onDismiss: () -> Unit,
    onCreate: (String, List<PublicProfile>) -> Unit
) {
    var groupTitle by remember { mutableStateOf("") }
    val selectedUids = remember { mutableStateListOf<String>() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Encrypted Group") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = groupTitle,
                    onValueChange = { groupTitle = it },
                    label = { Text("Group Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (friends.isEmpty()) {
                    Text(
                        "Add at least one friend first to create a group.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text("Select members:", style = MaterialTheme.typography.labelMedium)
                    Column(modifier = Modifier.height(200.dp)) {
                        LazyColumn {
                            items(friends, key = { it.userId }) { friend ->
                                val checked = friend.userId in selectedUids
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (checked) selectedUids.remove(friend.userId)
                                            else selectedUids.add(friend.userId)
                                        }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(checked = checked, onCheckedChange = null)
                                    Spacer(Modifier.width(8.dp))
                                    HelloAvatar(name = friend.displayName, photoUrl = friend.photoUrl, size = 34.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text(friend.displayName, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = groupTitle.isNotBlank() && selectedUids.isNotEmpty(),
                onClick = {
                    val chosen = friends.filter { it.userId in selectedUids }
                    onCreate(groupTitle, chosen)
                }
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
