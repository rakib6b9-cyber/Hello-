package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Forward
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.Chat
import com.example.data.ChatMessage
import com.example.data.MessageType
import com.example.data.PublicProfile
import com.example.data.UiState
import com.example.localization.LocalStrings
import com.example.media.VoicePlayerHelper
import com.example.media.VoiceRecorderHelper
import com.example.ui.components.HelloAvatar
import com.example.ui.components.TimeFormatters
import com.example.ui.theme.LocalHelloColors
import com.example.ui.theme.MonoFontFamily
import com.example.viewmodel.ChatRoomViewModel

private val QUICK_EMOJIS = listOf("❤️", "👍", "😂", "😮", "🙏", "🎉", "🔥", "💜")

@Composable
fun ChatRoomScreen(
    chat: Chat,
    allChats: List<Chat>,
    myProfile: PublicProfile?,
    peerProfiles: Map<String, PublicProfile>,
    showReadReceipts: Boolean,
    viewModel: ChatRoomViewModel,
    onBack: () -> Unit,
    onStartAudioCall: (List<String>) -> Unit,
    onStartVideoCall: (List<String>) -> Unit
) {
    BackHandler { onBack() }

    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current
    val context = LocalContext.current
    val currentUserId = viewModel.currentUserId

    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val safetyNumber by viewModel.safetyNumber.collectAsStateWithLifecycle()
    val actionError by viewModel.actionError.collectAsStateWithLifecycle()
    val isSendingMedia by viewModel.isSendingMedia.collectAsStateWithLifecycle()

    val peerUid = chat.memberUids.firstOrNull { it != currentUserId }
    val peerProfile = peerUid?.let { peerProfiles[it] }
    val creatorProfile = peerProfiles[chat.createdBy] ?: myProfile
    val title = resolveChatTitle(chat, currentUserId, peerProfiles)
    val isTyping = chat.typingUids.any { it != currentUserId }

    val voiceRecorder = remember { VoiceRecorderHelper(context) }
    val voicePlayer = remember { VoicePlayerHelper() }
    var playingUrl by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        onDispose { voicePlayer.stop() }
    }

    LaunchedEffect(chat.id, peerProfile?.e2eePublicKey, creatorProfile?.e2eePublicKey) {
        viewModel.ensureEncryptionKey(chat, peerProfile, creatorProfile)
    }

    var draft by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showEmojiBar by remember { mutableStateOf(false) }
    var showAttachMenu by remember { mutableStateOf(false) }
    var showSafetyDialog by remember { mutableStateOf(false) }
    var replyingTo by remember { mutableStateOf<ChatMessage?>(null) }
    var editingMessage by remember { mutableStateOf<ChatMessage?>(null) }
    var actionTargetMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var forwardingMsg by remember { mutableStateOf<ChatMessage?>(null) }
    var isRecordingVoice by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.sendMedia(chat, myProfile?.displayName ?: "Me", uri, MessageType.IMAGE, "Photo")
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.sendMedia(chat, myProfile?.displayName ?: "Me", uri, MessageType.VIDEO, "Video")
        }
    }

    val documentPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "Document"
            viewModel.sendMedia(chat, myProfile?.displayName ?: "Me", uri, MessageType.DOCUMENT, fileName)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            try {
                voiceRecorder.startRecording()
                isRecordingVoice = true
            } catch (_: Exception) {
                isRecordingVoice = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .imePadding()
    ) {
        // Chat Top Bar
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("chat_back_btn")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                HelloAvatar(
                    name = title,
                    photoUrl = if (chat.chatType == "GROUP") chat.photoUrl else peerProfile?.photoUrl.orEmpty(),
                    size = 42.dp,
                    isOnline = chat.chatType == "DIRECT" && peerProfile?.onlineStatus == "ONLINE"
                )
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = when {
                            isTyping -> strings.typing
                            chat.chatType == "GROUP" -> "${chat.memberUids.size} members"
                            peerProfile != null -> TimeFormatters.formatLastSeen(peerProfile.onlineStatus, peerProfile.lastSeen)
                            else -> "Encrypted"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isTyping) helloColors.onlineDot else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = { showSafetyDialog = true },
                    modifier = Modifier.testTag("chat_e2ee_info_btn")
                ) {
                    Icon(Icons.Filled.Lock, contentDescription = "Encryption info", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(
                    onClick = { showSearch = !showSearch },
                    modifier = Modifier.testTag("chat_search_btn")
                ) {
                    Icon(Icons.Filled.Search, contentDescription = "Search messages")
                }
                IconButton(
                    onClick = { onStartAudioCall(chat.memberUids.filter { it != currentUserId }) },
                    modifier = Modifier.testTag("chat_audio_call_btn")
                ) {
                    Icon(Icons.Filled.Call, contentDescription = "Audio call")
                }
                IconButton(
                    onClick = { onStartVideoCall(chat.memberUids.filter { it != currentUserId }) },
                    modifier = Modifier.testTag("chat_video_call_btn")
                ) {
                    Icon(Icons.Filled.Videocam, contentDescription = "Video call")
                }
            }
        }

        AnimatedVisibility(visible = showSearch) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search in conversation...") },
                trailingIcon = {
                    IconButton(onClick = { searchQuery = ""; showSearch = false }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close search")
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        if (isSendingMedia) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }

        if (actionError != null) {
            Surface(
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(actionError.orEmpty(), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                    TextButton(onClick = { viewModel.clearError() }) { Text("Dismiss") }
                }
            }
        }

        // Messages Area
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (val state = messagesState) {
                is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                }
                is UiState.Success -> {
                    val allMsgs = state.data
                    LaunchedEffect(allMsgs.size) {
                        viewModel.markRead(chat, allMsgs, showReadReceipts)
                        if (allMsgs.isNotEmpty()) {
                            listState.animateScrollToItem(allMsgs.lastIndex)
                        }
                    }

                    val displayed = remember(allMsgs, searchQuery) {
                        if (searchQuery.isBlank()) allMsgs
                        else allMsgs.filter { viewModel.decryptText(it).contains(searchQuery, ignoreCase = true) }
                    }

                    if (displayed.isEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                Icons.Filled.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                            Text(strings.e2eeVerified, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Say Hello! Messages here are encrypted on-device before leaving your phone.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(displayed, key = { it.id }) { msg ->
                                val isMine = msg.senderId == currentUserId
                                val decrypted = viewModel.decryptText(msg)
                                MessageBubble(
                                    message = msg,
                                    decryptedText = decrypted,
                                    isMine = isMine,
                                    isGroup = chat.chatType == "GROUP",
                                    isPlayingVoice = playingUrl == msg.mediaUrl && msg.mediaUrl.isNotBlank(),
                                    onLongClick = { actionTargetMsg = msg },
                                    onPlayVoice = {
                                        if (msg.mediaUrl.isNotBlank()) {
                                            playingUrl = if (playingUrl == msg.mediaUrl) null else msg.mediaUrl
                                            voicePlayer.playOrStop(
                                                url = msg.mediaUrl,
                                                onCompleted = { playingUrl = null },
                                                onError = { playingUrl = null }
                                            )
                                        }
                                    },
                                    onOpenAttachment = {
                                        if (msg.mediaUrl.isNotBlank()) {
                                            try {
                                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(msg.mediaUrl)))
                                            } catch (_: Exception) {
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Reply / Edit Banner
        AnimatedVisibility(visible = replyingTo != null || editingMessage != null) {
            Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (editingMessage != null) Icons.Filled.Edit else Icons.AutoMirrored.Filled.Reply,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = editingMessage?.let { "Editing: ${viewModel.decryptText(it)}" }
                            ?: replyingTo?.let { "Replying to ${it.senderName}: ${viewModel.decryptText(it)}" }
                            .orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { replyingTo = null; editingMessage = null }) {
                        Icon(Icons.Filled.Close, contentDescription = "Cancel", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Quick Emoji Strip
        AnimatedVisibility(visible = showEmojiBar) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.background(MaterialTheme.colorScheme.surface)
            ) {
                items(QUICK_EMOJIS) { emoji ->
                    Text(
                        text = emoji,
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier
                            .clip(CircleShape)
                            .clickable { draft += emoji }
                            .padding(6.dp)
                    )
                }
            }
        }

        // Message Composer Bar
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
            if (isRecordingVoice) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = helloColors.callEnd)
                        Spacer(Modifier.width(8.dp))
                        Text("Recording voice message...", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = {
                            voiceRecorder.stopAndReturn()
                            isRecordingVoice = false
                        }) {
                            Text("Cancel")
                        }
                        IconButton(
                            onClick = {
                                val recorded = voiceRecorder.stopAndReturn()
                                isRecordingVoice = false
                                if (recorded != null) {
                                    viewModel.sendMedia(
                                        chat = chat,
                                        senderName = myProfile?.displayName ?: "Me",
                                        uri = recorded.first,
                                        messageType = MessageType.VOICE,
                                        displayName = "Voice message",
                                        durationSec = recorded.second
                                    )
                                }
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Filled.Stop, contentDescription = "Send voice", tint = Color.White)
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { showEmojiBar = !showEmojiBar }) {
                        Icon(Icons.Filled.EmojiEmotions, contentDescription = "Emoji")
                    }
                    Box {
                        IconButton(onClick = { showAttachMenu = true }) {
                            Icon(Icons.Filled.AttachFile, contentDescription = "Attach media or document")
                        }
                        DropdownMenu(expanded = showAttachMenu, onDismissRequest = { showAttachMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Photo (Photo Picker)") },
                                leadingIcon = { Icon(Icons.Filled.Image, null) },
                                onClick = {
                                    showAttachMenu = false
                                    imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Video (Photo Picker)") },
                                leadingIcon = { Icon(Icons.Filled.Videocam, null) },
                                onClick = {
                                    showAttachMenu = false
                                    videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Document / File") },
                                leadingIcon = { Icon(Icons.Filled.Description, null) },
                                onClick = {
                                    showAttachMenu = false
                                    documentPicker.launch(arrayOf("*/*"))
                                }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = draft,
                        onValueChange = {
                            draft = it
                            viewModel.onDraftChanged(chat, it)
                        },
                        placeholder = { Text(strings.messagePlaceholder) },
                        maxLines = 4,
                        shape = RoundedCornerShape(22.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_message_input")
                    )
                    Spacer(Modifier.width(6.dp))
                    if (draft.isBlank()) {
                        IconButton(
                            onClick = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .testTag("chat_voice_record_btn")
                        ) {
                            Icon(Icons.Filled.Mic, contentDescription = "Record voice message", tint = MaterialTheme.colorScheme.primary)
                        }
                    } else {
                        IconButton(
                            onClick = {
                                val textToSend = draft
                                val editing = editingMessage
                                val reply = replyingTo
                                draft = ""
                                editingMessage = null
                                replyingTo = null
                                if (editing != null) {
                                    viewModel.editMessage(editing, textToSend)
                                } else {
                                    viewModel.sendText(chat, myProfile?.displayName ?: "Me", textToSend, reply)
                                }
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                                .testTag("chat_send_btn")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                        }
                    }
                }
            }
        }
    }

    // Message Context Actions Dialog
    if (actionTargetMsg != null) {
        val target = actionTargetMsg!!
        val isMine = target.senderId == currentUserId
        AlertDialog(
            onDismissRequest = { actionTargetMsg = null },
            title = { Text("Message Options") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        QUICK_EMOJIS.take(5).forEach { emoji ->
                            Text(
                                text = emoji,
                                style = MaterialTheme.typography.headlineSmall,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable {
                                        viewModel.toggleReaction(target, emoji)
                                        actionTargetMsg = null
                                    }
                                    .padding(6.dp)
                            )
                        }
                    }
                    TextButton(onClick = {
                        replyingTo = target
                        actionTargetMsg = null
                    }) {
                        Icon(Icons.AutoMirrored.Filled.Reply, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Reply")
                    }
                    TextButton(onClick = {
                        forwardingMsg = target
                        actionTargetMsg = null
                    }) {
                        Icon(Icons.Filled.Forward, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Forward")
                    }
                    if (isMine && !target.deleted && target.messageType == MessageType.TEXT.name) {
                        TextButton(onClick = {
                            editingMessage = target
                            draft = viewModel.decryptText(target)
                            actionTargetMsg = null
                        }) {
                            Icon(Icons.Filled.Edit, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Edit")
                        }
                    }
                    if (isMine && !target.deleted) {
                        TextButton(onClick = {
                            viewModel.deleteMessage(target.id)
                            actionTargetMsg = null
                        }) {
                            Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(8.dp))
                            Text("Delete", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { actionTargetMsg = null }) { Text("Close") }
            }
        )
    }

    // Forward Message Dialog
    if (forwardingMsg != null) {
        val msg = forwardingMsg!!
        val targets = allChats.filter { it.id != chat.id }
        AlertDialog(
            onDismissRequest = { forwardingMsg = null },
            title = { Text("Forward to Chat") },
            text = {
                if (targets.isEmpty()) {
                    Text("No other conversations available.")
                } else {
                    LazyColumn(modifier = Modifier.height(220.dp)) {
                        items(targets, key = { it.id }) { targetChat ->
                            val label = resolveChatTitle(targetChat, currentUserId, peerProfiles)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.forwardMessage(targetChat, myProfile?.displayName ?: "Me", msg)
                                        forwardingMsg = null
                                    }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(label, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { forwardingMsg = null }) { Text("Cancel") }
            }
        )
    }

    // E2EE Safety Number Verification Dialog
    if (showSafetyDialog) {
        AlertDialog(
            onDismissRequest = { showSafetyDialog = false },
            title = { Text("End-to-End Encryption") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Messages in this conversation are encrypted with ECDH (NIST P-256) + HKDF-SHA256 + AES-256-GCM before being written to Cloud Firestore."
                    )
                    if (!safetyNumber.isNullOrBlank()) {
                        Text("60-Digit Safety Number:", style = MaterialTheme.typography.labelMedium)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = safetyNumber.orEmpty(),
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSafetyDialog = false }) { Text("Verified") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    message: ChatMessage,
    decryptedText: String,
    isMine: Boolean,
    isGroup: Boolean,
    isPlayingVoice: Boolean,
    onLongClick: () -> Unit,
    onPlayVoice: () -> Unit,
    onOpenAttachment: () -> Unit
) {
    val helloColors = LocalHelloColors.current
    val bubbleShape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = if (isMine) 18.dp else 4.dp,
        bottomEnd = if (isMine) 4.dp else 18.dp
    )

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 295.dp)
                .clip(bubbleShape)
                .then(
                    if (isMine) {
                        Modifier.background(Brush.linearGradient(listOf(helloColors.sentBubbleStart, helloColors.sentBubbleEnd)))
                    } else {
                        Modifier.background(helloColors.receivedBubble)
                    }
                )
                .combinedClickable(
                    onClick = {
                        when (message.messageType) {
                            MessageType.VOICE.name -> onPlayVoice()
                            MessageType.DOCUMENT.name, MessageType.VIDEO.name -> onOpenAttachment()
                            else -> {}
                        }
                    },
                    onLongClick = onLongClick
                )
                .padding(horizontal = 14.dp, vertical = 9.dp)
        ) {
            val contentColor = if (isMine) Color.White else MaterialTheme.colorScheme.onSurface
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (isGroup && !isMine) {
                    Text(
                        text = message.senderName,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                if (message.forwarded) {
                    Text(
                        text = "Forwarded",
                        style = MaterialTheme.typography.labelSmall.copy(fontStyle = FontStyle.Italic),
                        color = contentColor.copy(alpha = 0.75f)
                    )
                }
                if (message.replyToPreview.isNotBlank()) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = message.replyToPreview,
                            style = MaterialTheme.typography.labelSmall,
                            color = contentColor.copy(alpha = 0.9f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                when (message.messageType) {
                    MessageType.IMAGE.name -> {
                        if (!message.deleted && message.mediaUrl.isNotBlank()) {
                            AsyncImage(
                                model = message.mediaUrl,
                                contentDescription = "Shared photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                        } else {
                            Text(decryptedText, color = contentColor, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    MessageType.VOICE.name -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isPlayingVoice) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                contentDescription = "Play voice message",
                                tint = contentColor
                            )
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Filled.GraphicEq, contentDescription = null, tint = contentColor)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = TimeFormatters.formatDuration(message.mediaDurationSec),
                                color = contentColor,
                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily)
                            )
                        }
                    }
                    MessageType.DOCUMENT.name, MessageType.VIDEO.name -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (message.messageType == MessageType.VIDEO.name) Icons.Filled.Videocam else Icons.Filled.Description,
                                contentDescription = null,
                                tint = contentColor
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = message.mediaName.ifBlank { decryptedText },
                                color = contentColor,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                    else -> {
                        Text(
                            text = decryptedText,
                            color = if (message.deleted) contentColor.copy(alpha = 0.65f) else contentColor,
                            style = if (message.deleted) {
                                MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic)
                            } else {
                                MaterialTheme.typography.bodyMedium
                            }
                        )
                    }
                }

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (message.edited && !message.deleted) {
                        Text("edited", style = MaterialTheme.typography.labelSmall, color = contentColor.copy(alpha = 0.7f))
                    }
                    Text(
                        text = TimeFormatters.formatMessageClock(message.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = contentColor.copy(alpha = 0.75f)
                    )
                    if (isMine) {
                        val isRead = message.readByUids.size > 1
                        val isDelivered = message.deliveredToUids.size > 1
                        Icon(
                            imageVector = if (isDelivered || isRead) Icons.Filled.DoneAll else Icons.Filled.Done,
                            contentDescription = if (isRead) "Read" else "Sent",
                            tint = if (isRead) Color(0xFF8BE9FD) else contentColor.copy(alpha = 0.8f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }

        if (message.reactions.isNotEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.padding(top = 2.dp)
            ) {
                Text(
                    text = message.reactions.values.distinct().joinToString(" "),
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
    }
}
