package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.PublicProfile
import com.example.data.Story
import com.example.data.StoryPrivacy
import com.example.localization.LocalStrings
import com.example.ui.components.HelloAvatar
import com.example.ui.theme.HelloBlue
import com.example.ui.theme.HelloViolet
import com.example.ui.theme.MyPersonRose
import java.util.concurrent.TimeUnit

@Composable
fun StoriesHubScreen(
    currentUserId: String,
    stories: List<Story>,
    peerProfiles: Map<String, PublicProfile>,
    onViewAuthorStories: (String) -> Unit,
    onCreateTextStory: (String, String, StoryPrivacy) -> Unit,
    onCreateMediaStory: (Uri, Boolean, String, StoryPrivacy) -> Unit,
    onDeleteStory: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val strings = LocalStrings.current
    var filterMyPersonOnly by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val displayed = remember(stories, filterMyPersonOnly) {
        if (filterMyPersonOnly) stories.filter { it.privacy == StoryPrivacy.MY_PERSON.name }
        else stories
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text("Stories (24h)", style = MaterialTheme.typography.titleLarge)
                }
                Button(onClick = { showCreateDialog = true }, shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Filled.Add, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Add Story")
                }
            }
        }

        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !filterMyPersonOnly,
                onClick = { filterMyPersonOnly = false },
                label = { Text("All Stories (${stories.size})") }
            )
            FilterChip(
                selected = filterMyPersonOnly,
                onClick = { filterMyPersonOnly = true },
                label = { Text(strings.myPerson) },
                leadingIcon = { Icon(Icons.Filled.Favorite, null, modifier = Modifier.size(16.dp)) }
            )
        }

        if (displayed.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "No active stories right now. Share a photo, video, or text note that expires automatically in 24 hours.",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(displayed, key = { it.id }) { story ->
                    val hoursLeft = story.expiresAt?.toDate()?.time?.let { exp ->
                        TimeUnit.MILLISECONDS.toHours((exp - System.currentTimeMillis()).coerceAtLeast(0L))
                    } ?: 24L
                    val profile = peerProfiles[story.authorId]
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onViewAuthorStories(story.authorId) }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HelloAvatar(
                                name = profile?.displayName ?: story.authorName,
                                photoUrl = profile?.photoUrl ?: story.authorPhotoUrl,
                                size = 52.dp,
                                hasStoryRing = true,
                                isMyPersonRing = story.privacy == StoryPrivacy.MY_PERSON.name
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(story.authorName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${story.storyType} • ${StoryPrivacy.fromRaw(story.privacy).label} • ${hoursLeft}h left",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (story.authorId == currentUserId) {
                                IconButton(onClick = { onDeleteStory(story.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete story", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        StoryCreatorDialog(
            onDismiss = { showCreateDialog = false },
            onPostText = { text, hex, priv ->
                showCreateDialog = false
                onCreateTextStory(text, hex, priv)
            },
            onPostMedia = { uri, isVideo, caption, priv ->
                showCreateDialog = false
                onCreateMediaStory(uri, isVideo, caption, priv)
            }
        )
    }
}

@Composable
fun StoryViewerScreen(
    stories: List<Story>,
    currentUserId: String,
    onMarkViewed: (Story) -> Unit,
    onDeleteStory: (String) -> Unit,
    onClose: () -> Unit
) {
    BackHandler { onClose() }

    if (stories.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    var index by remember { mutableIntStateOf(0) }
    val safeIndex = index.coerceIn(0, stories.lastIndex)
    val current = stories[safeIndex]

    LaunchedEffect(current.id) {
        onMarkViewed(current)
    }

    val bgColor = try {
        Color(android.graphics.Color.parseColor(current.backgroundColorHex.ifBlank { "#1E1B3A" }))
    } catch (_: Exception) {
        Color(0xFF1E1B3A)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("story_viewer_screen")
    ) {
        if (current.mediaUrl.isNotBlank() && current.storyType == "IMAGE") {
            AsyncImage(
                model = current.mediaUrl,
                contentDescription = "Story image",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Tap left/right navigation zones
        Row(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clickable { if (safeIndex > 0) index-- else onClose() }
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clickable { if (safeIndex < stories.lastIndex) index++ else onClose() }
            )
        }

        // Top bar + progress segments
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0x99000000), Color.Transparent)))
                .padding(16.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                stories.forEachIndexed { i, _ ->
                    LinearProgressIndicator(
                        progress = { if (i <= safeIndex) 1f else 0f },
                        modifier = Modifier
                            .weight(1f)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = Color.White,
                        trackColor = Color.White.copy(alpha = 0.3f)
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    HelloAvatar(name = current.authorName, photoUrl = current.authorPhotoUrl, size = 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(current.authorName, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = StoryPrivacy.fromRaw(current.privacy).label,
                            color = Color.White.copy(alpha = 0.8f),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                Row {
                    if (current.authorId == currentUserId) {
                        IconButton(onClick = {
                            onDeleteStory(current.id)
                            if (stories.size <= 1) onClose()
                        }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Color.White)
                        }
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
            }
        }

        if (current.textContent.isNotBlank()) {
            Text(
                text = current.textContent,
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(if (current.mediaUrl.isBlank()) Alignment.Center else Alignment.BottomCenter)
                    .padding(horizontal = 28.dp, vertical = 72.dp)
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Visibility, null, tint = Color.White.copy(0.8f), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("${current.viewedByUids.size} views", color = Color.White.copy(0.9f), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun StoryCreatorDialog(
    onDismiss: () -> Unit,
    onPostText: (String, String, StoryPrivacy) -> Unit,
    onPostMedia: (Uri, Boolean, String, StoryPrivacy) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var selectedHex by remember { mutableStateOf("#7C4DFF") }
    var privacy by remember { mutableStateOf(StoryPrivacy.ALL_FRIENDS) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onPostMedia(uri, false, text, privacy)
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) onPostMedia(uri, true, text, privacy)
    }

    val colors = listOf("#7C4DFF", "#3B82F6", "#EC4899", "#1E1B3A", "#10B981")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create 24h Story") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Write a story or caption...") },
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Background Color:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    colors.forEach { hex ->
                        val c = Color(android.graphics.Color.parseColor(hex))
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(c)
                                .clickable { selectedHex = hex }
                        )
                    }
                }
                Text("Who can view:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StoryPrivacy.entries.forEach { p ->
                        FilterChip(
                            selected = privacy == p,
                            onClick = { privacy = p },
                            label = { Text(p.label, maxLines = 1) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Image, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Photo")
                    }
                    OutlinedButton(
                        onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Videocam, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Video")
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = text.isNotBlank(),
                onClick = { onPostText(text.trim(), selectedHex, privacy) }
            ) {
                Icon(Icons.Filled.TextFields, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Post Text")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
