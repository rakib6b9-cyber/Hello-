package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.Chat
import com.example.data.FriendRequest
import com.example.data.PublicProfile
import com.example.data.Story
import com.example.data.UiState
import com.example.localization.LocalStrings
import com.example.ui.components.HelloAvatar
import com.example.ui.components.HelloBrandWordmark
import com.example.ui.components.TimeFormatters
import com.example.ui.theme.HelloBlue
import com.example.ui.theme.HelloViolet
import com.example.ui.theme.LocalHelloColors
import com.example.ui.theme.MyPersonRose

/**
 * IMO-inspired Home screen layout with Hello App purple-blue identity on clean dark charcoal / light surface:
 * - Header: Hello App logo + title, Search & Notification icons
 * - Horizontal Story Circles: My Story, My Person, Friends, More
 * - Vertical Conversation List: Avatar, online dot, name, last message, time, unread badge, quick audio call button
 */
@Composable
fun HomeScreen(
    currentUserId: String,
    myProfile: PublicProfile?,
    chatsState: UiState<List<Chat>>,
    peerProfiles: Map<String, PublicProfile>,
    stories: List<Story>,
    pendingRequests: List<FriendRequest>,
    blockedUids: List<String>,
    onOpenChat: (String) -> Unit,
    onQuickAudioCall: (peerUid: String, peerName: String) -> Unit,
    onCreateStory: () -> Unit,
    onViewAuthorStories: (authorId: String) -> Unit,
    onOpenMyPerson: () -> Unit,
    onOpenStoriesHub: () -> Unit,
    onOpenFriends: () -> Unit,
    onOpenNotifications: () -> Unit
) {
    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }

    val myStories = remember(stories, currentUserId) { stories.filter { it.authorId == currentUserId } }
    val friendStoriesByAuthor = remember(stories, currentUserId, blockedUids) {
        stories.filter { it.authorId != currentUserId && it.authorId !in blockedUids }
            .groupBy { it.authorId }
    }
    val myPersonProfile = myProfile?.myPersonId?.takeIf { it.isNotBlank() }?.let { peerProfiles[it] }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Brand Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HelloBrandWordmark(
                title = strings.appName,
                subtitle = strings.tagline,
                logoSize = 38.dp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { showSearch = !showSearch },
                    modifier = Modifier.testTag("home_search_button")
                ) {
                    Icon(
                        imageVector = if (showSearch) Icons.Filled.Close else Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Box {
                    IconButton(
                        onClick = onOpenNotifications,
                        modifier = Modifier.testTag("home_notifications_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Notifications,
                            contentDescription = "Notifications",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    if (pendingRequests.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 6.dp, end = 6.dp)
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = pendingRequests.size.coerceAtMost(9).toString(),
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }

        AnimatedVisibility(visible = showSearch) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(strings.searchChatsPlaceholder) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .testTag("home_search_input")
            )
        }

        // Horizontal Story Circles Strip (My Story, My Person, Friends, More)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. My Story
            item(key = "story_my") {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(68.dp)
                        .clickable {
                            if (myStories.isNotEmpty()) onViewAuthorStories(currentUserId) else onCreateStory()
                        }
                        .testTag("story_circle_my")
                ) {
                    Box {
                        HelloAvatar(
                            name = myProfile?.displayName ?: "Me",
                            photoUrl = myProfile?.photoUrl.orEmpty(),
                            size = 56.dp,
                            hasStoryRing = myStories.isNotEmpty()
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                                .clickable(onClick = onCreateStory),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = "Add story",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = strings.myStory,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // 2. My Person Story / Sanctuary Circle
            item(key = "story_myperson") {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(68.dp)
                        .clickable(onClick = onOpenMyPerson)
                        .testTag("story_circle_myperson")
                ) {
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(MyPersonRose, HelloViolet))
                            )
                            .padding(2.5.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surface),
                        contentAlignment = Alignment.Center
                    ) {
                        if (myPersonProfile != null) {
                            HelloAvatar(
                                name = myPersonProfile.displayName,
                                photoUrl = myPersonProfile.photoUrl,
                                size = 54.dp,
                                isOnline = myPersonProfile.onlineStatus == "ONLINE"
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Favorite,
                                contentDescription = strings.myPerson,
                                tint = MyPersonRose,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = myPersonProfile?.displayName?.split(" ")?.firstOrNull() ?: strings.myPerson,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MyPersonRose,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // 3. Friends' Active Stories
            items(friendStoriesByAuthor.keys.toList(), key = { "story_$it" }) { authorId ->
                val list = friendStoriesByAuthor[authorId].orEmpty()
                val first = list.firstOrNull() ?: return@items
                val profile = peerProfiles[authorId]
                val hasUnviewed = list.any { currentUserId !in it.viewedByUids }
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(68.dp)
                        .clickable { onViewAuthorStories(authorId) }
                        .testTag("story_circle_friend_$authorId")
                ) {
                    HelloAvatar(
                        name = profile?.displayName ?: first.authorName,
                        photoUrl = profile?.photoUrl ?: first.authorPhotoUrl,
                        size = 56.dp,
                        isOnline = profile?.onlineStatus == "ONLINE",
                        hasStoryRing = hasUnviewed,
                        isMyPersonRing = first.privacy == "MY_PERSON"
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = (profile?.displayName ?: first.authorName).split(" ").first(),
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // 4. More Circle
            item(key = "story_more") {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(68.dp)
                        .clickable(onClick = onOpenStoriesHub)
                        .testTag("story_circle_more")
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Apps,
                            contentDescription = strings.more,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = strings.more,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                }
            }
        }

        HorizontalDivider(color = helloColors.subtleDivider, thickness = 0.6.dp)

        // Vertical IMO-inspired Chat List
        when (chatsState) {
            is UiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = chatsState.message,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }
            }
            is UiState.Success -> {
                val filteredChats = remember(chatsState.data, searchQuery, peerProfiles, blockedUids) {
                    chatsState.data.filter { chat ->
                        val peerUid = chat.memberUids.firstOrNull { it != currentUserId }
                        val blocked = chat.chatType == "DIRECT" && peerUid != null && peerUid in blockedUids
                        if (blocked) return@filter false
                        if (searchQuery.isBlank()) true
                        else {
                            val title = resolveChatTitle(chat, currentUserId, peerProfiles)
                            title.contains(searchQuery, ignoreCase = true) ||
                                chat.lastMessagePreview.contains(searchQuery, ignoreCase = true)
                        }
                    }
                }

                if (filteredChats.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(HelloViolet.copy(alpha = 0.2f), HelloBlue.copy(alpha = 0.2f))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PersonAdd,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            text = strings.noChatsTitle,
                            style = MaterialTheme.typography.titleLarge,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = strings.noChatsSubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(20.dp))
                        Button(
                            onClick = onOpenFriends,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.testTag("empty_find_friends_btn")
                        ) {
                            Text(strings.startConversation)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 6.dp)
                    ) {
                        items(filteredChats, key = { it.id }) { chat ->
                            HomeChatRow(
                                chat = chat,
                                currentUserId = currentUserId,
                                peerProfiles = peerProfiles,
                                onClick = { onOpenChat(chat.id) },
                                onQuickAudioCall = {
                                    val peerUid = chat.memberUids.firstOrNull { it != currentUserId }
                                    if (peerUid != null) {
                                        val name = resolveChatTitle(chat, currentUserId, peerProfiles)
                                        onQuickAudioCall(peerUid, name)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeChatRow(
    chat: Chat,
    currentUserId: String,
    peerProfiles: Map<String, PublicProfile>,
    onClick: () -> Unit,
    onQuickAudioCall: () -> Unit
) {
    val helloColors = LocalHelloColors.current
    val peerUid = chat.memberUids.firstOrNull { it != currentUserId }
    val peer = peerUid?.let { peerProfiles[it] }
    val title = resolveChatTitle(chat, currentUserId, peerProfiles)
    val photoUrl = if (chat.chatType == "GROUP") chat.photoUrl else peer?.photoUrl.orEmpty()
    val isOnline = chat.chatType == "DIRECT" && peer?.onlineStatus == "ONLINE"
    val unread = (chat.unreadCounts[currentUserId] ?: 0L).toInt()
    val isTyping = chat.typingUids.any { it != currentUserId }
    val timeLabel = TimeFormatters.formatChatTime(chat.lastMessageAt ?: chat.updatedAt)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag("chat_row_${chat.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HelloAvatar(
            name = title,
            photoUrl = photoUrl,
            size = 54.dp,
            isOnline = isOnline
        )
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.width(5.dp))
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Encrypted",
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                        modifier = Modifier.size(12.dp)
                    )
                }
                Text(
                    text = timeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (unread > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isTyping) "typing..." else chat.lastMessagePreview.ifBlank { "Tap to start encrypted chat" },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isTyping) helloColors.onlineDot else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(horizontal = 7.dp, vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (unread > 99) "99+" else unread.toString(),
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
        Spacer(Modifier.width(6.dp))
        IconButton(
            onClick = onQuickAudioCall,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .size(40.dp)
                .testTag("quick_call_${chat.id}")
        ) {
            Icon(
                imageVector = Icons.Filled.Call,
                contentDescription = "Quick audio call $title",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(19.dp)
            )
        }
    }
}

fun resolveChatTitle(
    chat: Chat,
    currentUserId: String,
    peerProfiles: Map<String, PublicProfile>
): String {
    if (chat.chatType == "GROUP") return chat.title.ifBlank { "Group Chat" }
    val peerUid = chat.memberUids.firstOrNull { it != currentUserId }
    return peerUid?.let { peerProfiles[it]?.displayName }?.takeIf { it.isNotBlank() } ?: "Hello Friend"
}
