package com.example.ui.components

import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object TimeFormatters {

    fun formatChatTime(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: return ""
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply { time = date }
        return if (
            now.get(Calendar.YEAR) == target.get(Calendar.YEAR) &&
            now.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR)
        ) {
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
        } else {
            SimpleDateFormat("MMM d", Locale.getDefault()).format(date)
        }
    }

    fun formatMessageClock(timestamp: Timestamp?): String {
        val date = timestamp?.toDate() ?: Date()
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
    }

    fun formatLastSeen(onlineStatus: String, lastSeen: Timestamp?): String {
        if (onlineStatus == "ONLINE") return "Online"
        val date = lastSeen?.toDate() ?: return "Offline"
        val diffMin = TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - date.time).coerceAtLeast(0L)
        return when {
            diffMin < 1 -> "Last seen just now"
            diffMin < 60 -> "Last seen ${diffMin}m ago"
            diffMin < 1440 -> "Last seen ${diffMin / 60}h ago"
            else -> "Last seen ${SimpleDateFormat("MMM d", Locale.getDefault()).format(date)}"
        }
    }

    fun formatDuration(seconds: Long): String {
        val mins = seconds / 60
        val secs = seconds % 60
        return String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    fun daysUntilAnnualDate(targetEpochMs: Long): Long {
        if (targetEpochMs <= 0L) return 0L
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply { timeInMillis = targetEpochMs }
        target.set(Calendar.YEAR, now.get(Calendar.YEAR))
        if (target.before(now)) {
            target.add(Calendar.YEAR, 1)
        }
        val diffMs = (target.timeInMillis - now.timeInMillis).coerceAtLeast(0L)
        return TimeUnit.MILLISECONDS.toDays(diffMs)
    }

    fun formatDateLabel(epochMs: Long): String {
        if (epochMs <= 0L) return "Not set"
        return SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(epochMs))
    }
}
