package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.FriendRequest
import com.example.data.Friendship
import com.example.data.PublicProfile
import com.example.localization.LocalStrings
import com.example.media.ContactsDiscoveryHelper
import com.example.media.QrCameraAnalyzer
import com.example.media.QrCodeUtils
import com.example.ui.components.HelloAvatar
import com.example.ui.theme.LocalHelloColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.MyPersonRose
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

@Composable
fun FriendsScreen(
    currentUserId: String,
    myProfile: PublicProfile?,
    friendships: List<Friendship>,
    friendRequests: List<FriendRequest>,
    peerProfiles: Map<String, PublicProfile>,
    blockedUids: List<String>,
    onSearchByUsername: suspend (String) -> Result<PublicProfile?>,
    onSearchByPhone: suspend (String, String) -> Result<PublicProfile?>,
    onSearchByInviteCode: suspend (String) -> Result<PublicProfile?>,
    onDiscoverContacts: suspend (List<com.example.media.DeviceContactEntry>) -> Result<List<PublicProfile>>,
    onSendRequest: (PublicProfile) -> Unit,
    onRespondRequest: (FriendRequest, Boolean) -> Unit,
    onCancelRequest: (String) -> Unit,
    onToggleFavorite: (Friendship) -> Unit,
    onOpenChat: (String) -> Unit,
    onStartAudioCall: (String) -> Unit,
    onSelectMyPerson: (String) -> Unit,
    onBlockUser: (String) -> Unit,
    onReportUser: (String, String, String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Friends, 1: Connect, 2: Requests
    var friendFilter by remember { mutableStateOf("ALL") } // ALL, ONLINE, FAVORITES

    var searchMode by remember { mutableStateOf("USERNAME") } // USERNAME, PHONE
    var queryInput by remember { mutableStateOf("") }
    var countryCode by remember { mutableStateOf("+880") }
    var searchResult by remember { mutableStateOf<PublicProfile?>(null) }
    var searchStatus by remember { mutableStateOf<String?>(null) }
    var isSearching by remember { mutableStateOf(false) }

    var discoveredContacts by remember { mutableStateOf<List<PublicProfile>>(emptyList()) }
    var showQrDialog by remember { mutableStateOf(false) }
    var showQrScanner by remember { mutableStateOf(false) }
    var reportTarget by remember { mutableStateOf<PublicProfile?>(null) }
    var reportReason by remember { mutableStateOf("Spam or Harassment") }
    var reportDetails by remember { mutableStateOf("") }

    val contactsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            isSearching = true
            scope.launch {
                val entries = ContactsDiscoveryHelper.readNormalizedContacts(context, countryCode)
                onDiscoverContacts(entries)
                    .onSuccess { list ->
                        discoveredContacts = list
                        searchStatus = if (list.isEmpty()) "No matching Hello App contacts found yet." else "Found ${list.size} contacts on Hello App."
                    }
                    .onFailure { searchStatus = it.localizedMessage }
                isSearching = false
            }
        } else {
            searchStatus = "Contacts permission denied. You can still connect via username or QR code."
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            showQrScanner = true
        } else {
            searchStatus = "Camera permission is needed to scan a friend's QR code."
        }
    }

    val incomingPending = remember(friendRequests, currentUserId) {
        friendRequests.filter { it.toUid == currentUserId && it.status == "PENDING" }
    }
    val outgoingPending = remember(friendRequests, currentUserId) {
        friendRequests.filter { it.fromUid == currentUserId && it.status == "PENDING" }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("friends_back_btn")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text(strings.friends, style = MaterialTheme.typography.titleLarge)
                }
                Row {
                    IconButton(onClick = { showQrDialog = true }, modifier = Modifier.testTag("friends_my_qr_btn")) {
                        Icon(Icons.Filled.QrCode2, contentDescription = strings.qrInvite)
                    }
                    IconButton(
                        onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                        modifier = Modifier.testTag("friends_scan_qr_btn")
                    ) {
                        Icon(Icons.Filled.QrCodeScanner, contentDescription = strings.scanQr)
                    }
                }
            }
        }

        TabRow(selectedTabIndex = selectedTab) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("${strings.friends} (${friendships.size})") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(strings.findFriends) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("${strings.friendRequests} (${incomingPending.size})") }
            )
        }

        when (selectedTab) {
            0 -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(selected = friendFilter == "ALL", onClick = { friendFilter = "ALL" }, label = { Text("All") })
                    FilterChip(selected = friendFilter == "ONLINE", onClick = { friendFilter = "ONLINE" }, label = { Text(strings.onlineFriends) })
                    FilterChip(selected = friendFilter == "FAVORITES", onClick = { friendFilter = "FAVORITES" }, label = { Text(strings.favorites) })
                }

                val filtered = friendships.mapNotNull { friendship ->
                    val peerUid = friendship.memberUids.firstOrNull { it != currentUserId } ?: return@mapNotNull null
                    if (peerUid in blockedUids) return@mapNotNull null
                    val profile = peerProfiles[peerUid] ?: PublicProfile(userId = peerUid, displayName = "Friend")
                    val keep = when (friendFilter) {
                        "ONLINE" -> profile.onlineStatus == "ONLINE"
                        "FAVORITES" -> currentUserId in friendship.favoriteBy
                        else -> true
                    }
                    if (keep) friendship to profile else null
                }

                if (filtered.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(28.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No friends in this view yet.", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { selectedTab = 1 }) { Text(strings.findFriends) }
                        }
                    }
                } else {
                    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(filtered, key = { it.first.id }) { (friendship, profile) ->
                            val isFav = currentUserId in friendship.favoriteBy
                            Surface(
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    HelloAvatar(
                                        name = profile.displayName,
                                        photoUrl = profile.photoUrl,
                                        size = 48.dp,
                                        isOnline = profile.onlineStatus == "ONLINE"
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(profile.displayName, style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            text = "@${profile.username.ifBlank { "user" }}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { onToggleFavorite(friendship) }) {
                                        Icon(
                                            imageVector = if (isFav) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                            contentDescription = "Favorite",
                                            tint = if (isFav) helloColors.awayDot else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { onSelectMyPerson(profile.userId) }) {
                                        Icon(
                                            imageVector = Icons.Filled.Favorite,
                                            contentDescription = "Set as My Person",
                                            tint = if (myProfile?.myPersonId == profile.userId) MyPersonRose else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { onOpenChat(profile.userId) }) {
                                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Message")
                                    }
                                    IconButton(onClick = { onStartAudioCall(profile.userId) }) {
                                        Icon(Icons.Filled.Call, contentDescription = "Audio call")
                                    }
                                    IconButton(onClick = { reportTarget = profile }) {
                                        Icon(Icons.Filled.Flag, contentDescription = "Block or report")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = searchMode == "USERNAME",
                                onClick = { searchMode = "USERNAME"; searchResult = null; searchStatus = null },
                                label = { Text("By Username") },
                                leadingIcon = { Icon(Icons.Filled.AlternateEmail, null, modifier = Modifier.size(16.dp)) }
                            )
                            FilterChip(
                                selected = searchMode == "PHONE",
                                onClick = { searchMode = "PHONE"; searchResult = null; searchStatus = null },
                                label = { Text("By Phone") },
                                leadingIcon = { Icon(Icons.Filled.Phone, null, modifier = Modifier.size(16.dp)) }
                            )
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (searchMode == "PHONE") {
                                OutlinedTextField(
                                    value = countryCode,
                                    onValueChange = { countryCode = it },
                                    label = { Text("Code") },
                                    singleLine = true,
                                    modifier = Modifier.width(86.dp)
                                )
                            }
                            OutlinedTextField(
                                value = queryInput,
                                onValueChange = { queryInput = it },
                                label = {
                                    Text(if (searchMode == "USERNAME") "Username (e.g. rakib_dev)" else "Phone number")
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = if (searchMode == "PHONE") KeyboardType.Phone else KeyboardType.Text
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("friend_search_input")
                            )
                            Button(
                                onClick = {
                                    isSearching = true
                                    searchStatus = null
                                    scope.launch {
                                        val res = if (searchMode == "USERNAME") {
                                            onSearchByUsername(queryInput)
                                        } else {
                                            onSearchByPhone(countryCode, queryInput)
                                        }
                                        res.onSuccess { found ->
                                            searchResult = found
                                            if (found == null) searchStatus = "No user found matching your search."
                                        }.onFailure {
                                            searchStatus = it.localizedMessage ?: "Search failed"
                                        }
                                        isSearching = false
                                    }
                                },
                                enabled = queryInput.isNotBlank() && !isSearching,
                                modifier = Modifier
                                    .height(54.dp)
                                    .testTag("friend_search_button")
                            ) {
                                Icon(Icons.Filled.Search, contentDescription = "Search")
                            }
                        }
                    }

                    if (isSearching) {
                        item {
                            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(modifier = Modifier.size(28.dp))
                            }
                        }
                    }

                    if (searchStatus != null) {
                        item {
                            Text(
                                text = searchStatus.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (searchResult != null) {
                        val found = searchResult!!
                        item {
                            SearchResultCard(
                                profile = found,
                                isSelf = found.userId == currentUserId,
                                onAdd = { onSendRequest(found) }
                            )
                        }
                    }

                    // Invite Tools: Contacts Discovery, Share Invite Link, QR
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("Quick Connect & Invites", style = MaterialTheme.typography.titleMedium)
                                if (!myProfile?.inviteCode.isNullOrBlank()) {
                                    Text(
                                        text = "Invite Code: ${myProfile?.inviteCode}",
                                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFontFamily),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            val link = "helloapp://invite?code=${myProfile?.inviteCode.orEmpty()}"
                                            val share = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "Connect with me on Hello App (@${myProfile?.username.orEmpty()})! Use code ${myProfile?.inviteCode.orEmpty()} or open: $link"
                                                )
                                            }
                                            context.startActivity(Intent.createChooser(share, "Share Hello App Invite"))
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Filled.Share, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.shareInviteLink, maxLines = 1)
                                    }
                                    OutlinedButton(
                                        onClick = { contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("discover_contacts_button")
                                    ) {
                                        Icon(Icons.Filled.Contacts, null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(strings.discoverContacts, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }

                    items(discoveredContacts, key = { "disc_${it.userId}" }) { contactUser ->
                        SearchResultCard(
                            profile = contactUser,
                            isSelf = contactUser.userId == currentUserId,
                            onAdd = { onSendRequest(contactUser) }
                        )
                    }
                }
            }

            2 -> {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (incomingPending.isEmpty() && outgoingPending.isEmpty()) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
                                Text("No pending friend requests.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    if (incomingPending.isNotEmpty()) {
                        item { Text("Incoming Requests", style = MaterialTheme.typography.titleMedium) }
                        items(incomingPending, key = { it.id }) { req ->
                            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    HelloAvatar(name = req.fromName, photoUrl = req.fromPhotoUrl, size = 46.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(req.fromName, style = MaterialTheme.typography.titleSmall)
                                        Text("@${req.fromUsername}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(
                                        onClick = { onRespondRequest(req, true) },
                                        modifier = Modifier.clip(CircleShape).background(helloColors.onlineDot.copy(alpha = 0.2f))
                                    ) {
                                        Icon(Icons.Filled.Check, contentDescription = "Accept", tint = helloColors.onlineDot)
                                    }
                                    Spacer(Modifier.width(6.dp))
                                    IconButton(
                                        onClick = { onRespondRequest(req, false) },
                                        modifier = Modifier.clip(CircleShape).background(MaterialTheme.colorScheme.error.copy(alpha = 0.16f))
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = "Reject", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }

                    if (outgoingPending.isNotEmpty()) {
                        item { Text("Sent Requests", style = MaterialTheme.typography.titleMedium) }
                        items(outgoingPending, key = { it.id }) { req ->
                            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    HelloAvatar(name = req.toName, photoUrl = req.toPhotoUrl, size = 44.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(req.toName, style = MaterialTheme.typography.titleSmall)
                                        Text("@${req.toUsername}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    TextButton(onClick = { onCancelRequest(req.id) }) {
                                        Text("Cancel", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // My QR Code Dialog
    if (showQrDialog && myProfile != null) {
        val qrBitmap = remember(myProfile.inviteCode) {
            QrCodeUtils.generateQrBitmap("helloapp://invite?code=${myProfile.inviteCode}")
        }
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            title = { Text("@${myProfile.username}") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Image(
                        bitmap = qrBitmap.asImageBitmap(),
                        contentDescription = "My Hello App QR Code",
                        modifier = Modifier
                            .size(210.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = myProfile.inviteCode,
                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFontFamily)
                    )
                    Text(
                        text = "Scan with Hello App to connect instantly",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showQrDialog = false }) { Text("Done") }
            }
        )
    }

    // CameraX QR Scanner Dialog
    if (showQrScanner) {
        QrScannerDialog(
            onQrDetected = { raw ->
                showQrScanner = false
                isSearching = true
                scope.launch {
                    onSearchByInviteCode(raw)
                        .onSuccess { found ->
                            selectedTab = 1
                            searchResult = found
                            searchStatus = if (found == null) "QR invite code not found." else "Scanned @${found.username}!"
                        }
                        .onFailure { searchStatus = it.localizedMessage }
                    isSearching = false
                }
            },
            onDismiss = { showQrScanner = false }
        )
    }

    // Block / Report Dialog
    if (reportTarget != null) {
        val target = reportTarget!!
        AlertDialog(
            onDismissRequest = { reportTarget = null },
            title = { Text("Manage ${target.displayName}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        label = { Text("Report Reason") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = reportDetails,
                        onValueChange = { reportDetails = it },
                        label = { Text("Details (optional)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                onBlockUser(target.userId)
                                reportTarget = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Block, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Block")
                        }
                        Button(
                            onClick = {
                                onReportUser(target.userId, reportReason, reportDetails)
                                reportTarget = null
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Report")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { reportTarget = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun SearchResultCard(
    profile: PublicProfile,
    isSelf: Boolean,
    onAdd: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            HelloAvatar(name = profile.displayName, photoUrl = profile.photoUrl, size = 46.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(profile.displayName, style = MaterialTheme.typography.titleMedium)
                Text("@${profile.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!isSelf) {
                Button(onClick = onAdd, shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Filled.PersonAdd, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add")
                }
            }
        }
    }
}

@Composable
private fun QrScannerDialog(
    onQrDetected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose { cameraExecutor.shutdown() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Scan Hello App QR") },
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx)
                        val providerFuture = ProcessCameraProvider.getInstance(ctx)
                        providerFuture.addListener({
                            val provider = providerFuture.get()
                            val preview = Preview.Builder().build().apply {
                                surfaceProvider = previewView.surfaceProvider
                            }
                            @Suppress("DEPRECATION")
                            val analysis = ImageAnalysis.Builder()
                                .setTargetResolution(Size(640, 480))
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                .build()
                                .apply {
                                    setAnalyzer(cameraExecutor, QrCameraAnalyzer { qrText ->
                                        previewView.post { onQrDetected(qrText) }
                                    })
                                }
                            try {
                                provider.unbindAll()
                                provider.bindToLifecycle(
                                    lifecycleOwner,
                                    CameraSelector.DEFAULT_BACK_CAMERA,
                                    preview,
                                    analysis
                                )
                            } catch (_: Exception) {
                            }
                        }, ContextCompat.getMainExecutor(ctx))
                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
