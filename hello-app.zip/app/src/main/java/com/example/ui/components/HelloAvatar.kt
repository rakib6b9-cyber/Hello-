package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.HelloBlue
import com.example.ui.theme.HelloViolet
import com.example.ui.theme.LocalHelloColors
import com.example.ui.theme.MyPersonRose

@Composable
fun HelloAvatar(
    name: String,
    photoUrl: String,
    modifier: Modifier = Modifier,
    size: Dp = 52.dp,
    isOnline: Boolean = false,
    hasStoryRing: Boolean = false,
    isMyPersonRing: Boolean = false
) {
    val helloColors = LocalHelloColors.current
    val initials = name.trim()
        .split(Regex("\\s+"))
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercaseChar().toString() }
        .ifBlank { "H" }

    val ringModifier = if (hasStoryRing) {
        val ringColors = if (isMyPersonRing) {
            listOf(MyPersonRose, HelloViolet)
        } else {
            listOf(HelloViolet, HelloBlue)
        }
        Modifier
            .size(size + 6.dp)
            .border(width = 2.2.dp, brush = Brush.linearGradient(ringColors), shape = CircleShape)
            .padding(3.dp)
    } else {
        Modifier.size(size)
    }

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Box(
            modifier = ringModifier
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(HelloViolet.copy(alpha = 0.85f), HelloBlue.copy(alpha = 0.85f))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            if (photoUrl.isNotBlank()) {
                AsyncImage(
                    model = photoUrl,
                    contentDescription = "$name avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )
            } else {
                Text(
                    text = initials,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.36f).sp
                )
            }
        }

        if (isOnline) {
            val dotSize = (size * 0.25f).coerceIn(10.dp, 15.dp)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(dotSize)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(2.dp)
                    .clip(CircleShape)
                    .background(helloColors.onlineDot)
            )
        }
    }
}
