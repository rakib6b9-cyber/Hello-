package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallMissed
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.CallSession
import com.example.data.CallStatus
import com.example.data.CallType
import com.example.data.Friendship
import com.example.data.PublicProfile
import com.example.data.SocialAndCallRepository
import com.example.localization.LocalStrings
import com.example.ui.components.HelloAvatar
import com.example.ui.components.TimeFormatters
import com.example.ui.theme.HelloBlue
import com.example.ui.theme.HelloViolet
import com.example.ui.theme.LocalHelloColors
import com.example.ui.theme.MonoFontFamily
import com.example.webrtc.WebRtcCallClient
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.webrtc.PeerConnection
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoTrack

data class ActiveCallRequest(
    val callId: String,
    val isOutgoing: Boolean,
    val isVideo: Boolean,
    val isGroup: Boolean,
    val calleeIds: List<String>,
    val peerDisplayName: String
)

@Composable
fun CallsScreen(
    currentUserId: String,
    calls: List<CallSession>,
    friendships: List<Friendship>,
    peerProfiles: Map<String, PublicProfile>,
    onStartCall: (calleeIds: List<String>, isVideo: Boolean, isGroup: Boolean, label: String) -> Unit
) {
    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current
    var showGroupCallDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(strings.navCalls, style = MaterialTheme.typography.headlineMedium)
            Button(
                onClick = { showGroupCallDialog = true },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.testTag("start_group_call_btn")
            ) {
                Icon(Icons.Filled.Group, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(strings.groupCall)
            }
        }

        if (calls.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(HelloViolet.copy(0.2f), HelloBlue.copy(0.2f)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Call, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.height(14.dp))
                Text(strings.noCallsTitle, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(6.dp))
                Text(
                    strings.noCallsSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(calls, key = { it.id }) { call ->
                    val isOutgoing = call.callerId == currentUserId
                    val isMissed = !isOutgoing && call.status in listOf(CallStatus.MISSED.name, CallStatus.DECLINED.name)
                    val isVideo = call.callType.contains("VIDEO")
                    val isGroup = call.callType.contains("GROUP")
                    val peerUids = call.participantUids.filter { it != currentUserId }
                    val peerName = when {
                        isGroup -> "${peerUids.size + 1}-way Group Call"
                        isOutgoing -> peerUids.firstOrNull()?.let { peerProfiles[it]?.displayName } ?: "Friend"
                        else -> call.callerName.ifBlank { "Friend" }
                    }
                    val peerPhoto = if (isOutgoing) {
                        peerUids.firstOrNull()?.let { peerProfiles[it]?.photoUrl }.orEmpty()
                    } else {
                        call.callerPhotoUrl
                    }

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HelloAvatar(name = peerName, photoUrl = peerPhoto, size = 48.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = peerName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (isMissed) helloColors.callEnd else MaterialTheme.colorScheme.onSurface
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when {
                                            isMissed -> Icons.AutoMirrored.Filled.CallMissed
                                            isOutgoing -> Icons.AutoMirrored.Filled.CallMade
                                            else -> Icons.AutoMirrored.Filled.CallReceived
                                        },
                                        contentDescription = null,
                                        tint = if (isMissed) helloColors.callEnd else helloColors.onlineDot,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = "${TimeFormatters.formatChatTime(call.createdAt)} • ${
                                            if (call.durationSec > 0) TimeFormatters.formatDuration(call.durationSec) else call.status
                                        }",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            IconButton(
                                onClick = { onStartCall(peerUids, false, isGroup, peerName) }
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = "Audio redial", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(
                                onClick = { onStartCall(peerUids, true, isGroup, peerName) }
                            ) {
                                Icon(Icons.Filled.Videocam, contentDescription = "Video redial", tint = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showGroupCallDialog) {
        val friends = friendships.mapNotNull { f ->
            val peerUid = f.memberUids.firstOrNull { it != currentUserId }
            peerUid?.let { peerProfiles[it] }
        }
        val selected = remember { mutableStateListOf<String>() }
        AlertDialog(
            onDismissRequest = { showGroupCallDialog = false },
            title = { Text("Start Group Call") },
            text = {
                if (friends.isEmpty()) {
                    Text("Connect with friends first to start a group call.")
                } else {
                    Column(modifier = Modifier.height(220.dp)) {
                        LazyColumn {
                            items(friends, key = { it.userId }) { friend ->
                                val checked = friend.userId in selected
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (checked) selected.remove(friend.userId) else selected.add(friend.userId)
                                        }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(checked = checked, onCheckedChange = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(friend.displayName)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        enabled = selected.isNotEmpty(),
                        onClick = {
                            showGroupCallDialog = false
                            onStartCall(selected.toList(), false, true, "Group Audio (${selected.size + 1})")
                        }
                    ) { Text("Audio") }
                    Button(
                        enabled = selected.isNotEmpty(),
                        onClick = {
                            showGroupCallDialog = false
                            onStartCall(selected.toList(), true, true, "Group Video (${selected.size + 1})")
                        }
                    ) { Text("Video") }
                }
            },
            dismissButton = {
                TextButton(onClick = { showGroupCallDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun IncomingCallOverlay(
    call: CallSession,
    onAccept: (isVideo: Boolean) -> Unit,
    onDecline: () -> Unit
) {
    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current
    val isVideo = call.callType.contains("VIDEO")

    Surface(
        color = Color(0xF5101218),
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("incoming_call_overlay")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(36.dp))
                Text(
                    text = if (isVideo) "${strings.incomingCall} • ${strings.videoCall}" else "${strings.incomingCall} • ${strings.audioCall}",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.height(24.dp))
                HelloAvatar(name = call.callerName, photoUrl = call.callerPhotoUrl, size = 112.dp, isOnline = true)
                Spacer(Modifier.height(20.dp))
                Text(
                    text = call.callerName,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "WebRTC DTLS-SRTP Encrypted",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                    color = Color(0xFFA0A7BC)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onDecline,
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(helloColors.callEnd)
                            .testTag("incoming_call_decline")
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = "Decline", tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Decline", color = Color.White)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { onAccept(isVideo) },
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(helloColors.onlineDot)
                            .testTag("incoming_call_accept")
                    ) {
                        Icon(
                            imageVector = if (isVideo) Icons.Filled.Videocam else Icons.Filled.Call,
                            contentDescription = "Accept",
                            tint = Color.White,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Accept", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun ActiveCallScreen(
    request: ActiveCallRequest,
    currentUserId: String,
    myProfile: PublicProfile?,
    socialAndCallRepo: SocialAndCallRepository,
    onCallEnded: () -> Unit
) {
    BackHandler { /* require end-call button */ }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val helloColors = LocalHelloColors.current

    var hasPermissions by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
                (!request.isVideo || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val micOk = results[Manifest.permission.RECORD_AUDIO] ?: false
        val camOk = if (request.isVideo) (results[Manifest.permission.CAMERA] ?: false) else true
        hasPermissions = micOk && camOk
    }

    LaunchedEffect(Unit) {
        if (!hasPermissions) {
            val perms = if (request.isVideo) {
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
            } else {
                arrayOf(Manifest.permission.RECORD_AUDIO)
            }
            permissionLauncher.launch(perms)
        }
    }

    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(request.isVideo) }
    var isCameraOn by remember { mutableStateOf(request.isVideo) }
    var connectionLabel by remember { mutableStateOf(if (request.isOutgoing) "Ringing..." else "Connecting...") }
    var elapsedSec by remember { mutableLongStateOf(0L) }
    var isConnected by remember { mutableStateOf(false) }
    var remoteVideoTrack by remember { mutableStateOf<VideoTrack?>(null) }
    var rtcClient by remember { mutableStateOf<WebRtcCallClient?>(null) }

    LaunchedEffect(isConnected) {
        if (isConnected) {
            while (true) {
                delay(1000L)
                elapsedSec++
            }
        }
    }

    if (hasPermissions) {
        DisposableEffect(request.callId) {
            val participants = (listOf(currentUserId) + request.calleeIds).distinct()
            val targetId = request.calleeIds.firstOrNull().orEmpty()
            val client = WebRtcCallClient(
                context = context,
                isVideoCall = request.isVideo,
                onLocalIceCandidate = { cand ->
                    scope.launch {
                        socialAndCallRepo.sendIceCandidate(
                            callId = request.callId,
                            targetId = targetId,
                            participantUids = participants,
                            sdpMid = cand.sdpMid ?: "0",
                            sdpMLineIndex = cand.sdpMLineIndex,
                            candidate = cand.sdp
                        )
                    }
                },
                onRemoteVideoTrack = { track ->
                    remoteVideoTrack = track
                },
                onConnectionStateChanged = { state ->
                    when (state) {
                        PeerConnection.PeerConnectionState.CONNECTED -> {
                            isConnected = true
                            connectionLabel = "Connected"
                        }
                        PeerConnection.PeerConnectionState.FAILED -> {
                            connectionLabel = "Connection failed"
                        }
                        PeerConnection.PeerConnectionState.DISCONNECTED -> {
                            connectionLabel = "Reconnecting..."
                        }
                        else -> {}
                    }
                }
            )
            client.setSpeakerphone(request.isVideo)
            rtcClient = client

            if (request.isOutgoing && myProfile != null) {
                client.createOffer(
                    onOfferCreated = { offer ->
                        scope.launch {
                            val type = when {
                                request.isGroup && request.isVideo -> CallType.GROUP_VIDEO
                                request.isGroup -> CallType.GROUP_AUDIO
                                request.isVideo -> CallType.VIDEO
                                else -> CallType.AUDIO
                            }
                            socialAndCallRepo.createCallSession(
                                callId = request.callId,
                                caller = myProfile,
                                calleeIds = request.calleeIds,
                                callType = type,
                                offerSdp = offer.description
                            )
                        }
                    },
                    onFailure = { err -> connectionLabel = err }
                )
            }

            onDispose {
                client.dispose()
                rtcClient = null
            }
        }

        // Observe Firestore signaling updates (offer/answer & ICE candidates)
        var appliedRemoteAnswer by remember { mutableStateOf(false) }
        var appliedOffer by remember { mutableStateOf(false) }
        val appliedCandidateIds = remember { mutableSetOf<String>() }

        LaunchedEffect(request.callId, rtcClient) {
            val client = rtcClient ?: return@LaunchedEffect
            socialAndCallRepo.observeCallSession(request.callId).collect { session ->
                if (session == null) return@collect
                if (request.isOutgoing && !appliedRemoteAnswer && session.answerSdp.isNotBlank()) {
                    appliedRemoteAnswer = true
                    client.setRemoteAnswer(session.answerSdp)
                    isConnected = true
                    connectionLabel = "Connected"
                } else if (!request.isOutgoing && !appliedOffer && session.offerSdp.isNotBlank()) {
                    appliedOffer = true
                    client.acceptOfferAndCreateAnswer(
                        offerSdp = session.offerSdp,
                        onAnswerCreated = { ans ->
                            scope.launch { socialAndCallRepo.answerCall(request.callId, ans.description) }
                        },
                        onFailure = { err -> connectionLabel = err }
                    )
                }
                if (session.status in listOf(CallStatus.ENDED.name, CallStatus.DECLINED.name, CallStatus.MISSED.name)) {
                    onCallEnded()
                }
            }
        }

        LaunchedEffect(request.callId, rtcClient) {
            val client = rtcClient ?: return@LaunchedEffect
            socialAndCallRepo.observeIceCandidates(request.callId, currentUserId).collect { candidates ->
                candidates.forEach { cand ->
                    if (cand.senderId != currentUserId && appliedCandidateIds.add(cand.id)) {
                        client.addRemoteIceCandidate(cand.sdpMid, cand.sdpMLineIndex.toInt(), cand.candidate)
                    }
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0E1016))
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("active_call_screen")
    ) {
        // Remote Video Surface (when video track active)
        if (request.isVideo && remoteVideoTrack != null && rtcClient != null) {
            val track = remoteVideoTrack!!
            val client = rtcClient!!
            AndroidView(
                factory = { ctx ->
                    SurfaceViewRenderer(ctx).also { client.attachRemoteRenderer(it, track) }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Local Video PiP
        if (request.isVideo && isCameraOn && rtcClient != null) {
            val client = rtcClient!!
            AndroidView(
                factory = { ctx ->
                    SurfaceViewRenderer(ctx).also { client.attachLocalRenderer(it) }
                },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
                    .size(width = 110.dp, height = 154.dp)
                    .clip(RoundedCornerShape(16.dp))
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White.copy(alpha = 0.08f)
                ) {
                    Text(
                        text = if (rtcClient?.hasTurnServerConfigured == true) "STUN + TURN Relay Ready" else "WebRTC STUN P2P",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        color = Color(0xFFB4BDDD),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Spacer(Modifier.height(24.dp))
                if (!request.isVideo || remoteVideoTrack == null) {
                    HelloAvatar(name = request.peerDisplayName, photoUrl = "", size = 104.dp, isOnline = isConnected)
                    Spacer(Modifier.height(16.dp))
                }
                Text(
                    text = request.peerDisplayName,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (isConnected) TimeFormatters.formatDuration(elapsedSec) else connectionLabel,
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                    color = Color(0xFFA7B5E8)
                )
                if (!hasPermissions) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "Microphone${if (request.isVideo) " & Camera" else ""} permission required for calls.",
                        color = Color(0xFFFCA5A5),
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Call Controls Bar
            Surface(
                shape = RoundedCornerShape(28.dp),
                color = Color(0xCC1B1F2C)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CallControlIcon(
                        icon = if (isMuted) Icons.Filled.MicOff else Icons.Filled.Mic,
                        label = if (isMuted) "Unmute" else "Mute",
                        active = isMuted,
                        onClick = {
                            isMuted = !isMuted
                            rtcClient?.setMuted(isMuted)
                        }
                    )
                    CallControlIcon(
                        icon = Icons.Filled.VolumeUp,
                        label = "Speaker",
                        active = isSpeakerOn,
                        onClick = {
                            isSpeakerOn = !isSpeakerOn
                            rtcClient?.setSpeakerphone(isSpeakerOn)
                        }
                    )
                    if (request.isVideo) {
                        CallControlIcon(
                            icon = if (isCameraOn) Icons.Filled.Videocam else Icons.Filled.VideocamOff,
                            label = "Camera",
                            active = !isCameraOn,
                            onClick = {
                                isCameraOn = !isCameraOn
                                rtcClient?.setCameraEnabled(isCameraOn)
                            }
                        )
                        CallControlIcon(
                            icon = Icons.Filled.Cameraswitch,
                            label = "Flip",
                            active = false,
                            onClick = { rtcClient?.switchCamera() }
                        )
                    }
                    IconButton(
                        onClick = {
                            scope.launch {
                                socialAndCallRepo.updateCallStatus(
                                    callId = request.callId,
                                    status = if (isConnected) CallStatus.ENDED else CallStatus.MISSED,
                                    durationSec = elapsedSec
                                )
                                onCallEnded()
                            }
                        },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(helloColors.callEnd)
                            .testTag("active_call_end_btn")
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = "End Call", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun CallControlIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (active) Color.White else Color.White.copy(alpha = 0.14f))
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) Color(0xFF101218) else Color.White
            )
        }
    }
}
