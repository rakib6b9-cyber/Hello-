package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hello App Purple-Blue Premium Identity on Clean Dark Charcoal & Crisp Light
val HelloViolet = Color(0xFF7C4DFF)
val HelloVioletDark = Color(0xFF6534E8)
val HelloVioletSoft = Color(0xFFEDE7FF)
val HelloBlue = Color(0xFF3B82F6)
val HelloBlueSoft = Color(0xFFDBEAFE)
val HelloIndigo = Color(0xFF4F46E5)

// Dark Charcoal Surfaces (clean, non-neon)
val CharcoalBg = Color(0xFF101218)
val CharcoalSurface = Color(0xFF171A23)
val CharcoalElevated = Color(0xFF202431)
val CharcoalCard = Color(0xFF262B3A)
val CharcoalOutline = Color(0xFF2F3547)
val CharcoalTextPrimary = Color(0xFFF3F4F8)
val CharcoalTextSecondary = Color(0xFFA0A7BC)

// Clean Light Surfaces
val LightBg = Color(0xFFF6F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightElevated = Color(0xFFEEF1F8)
val LightCard = Color(0xFFFFFFFF)
val LightOutline = Color(0xFFDDE2EE)
val LightTextPrimary = Color(0xFF121521)
val LightTextSecondary = Color(0xFF5D647B)

// Semantic Accents
val OnlineGreen = Color(0xFF10B981)
val AwayAmber = Color(0xFFF59E0B)
val CallRed = Color(0xFFEF4444)
val MyPersonRose = Color(0xFFEC4899)
