package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.Friendship
import com.example.data.MyPersonMemory
import com.example.data.MyPersonNote
import com.example.data.MyPersonSpace
import com.example.data.PublicProfile
import com.example.localization.LocalStrings
import com.example.ui.components.HelloAvatar
import com.example.ui.components.TimeFormatters
import com.example.ui.theme.HelloBlue
import com.example.ui.theme.HelloViolet
import com.example.ui.theme.MyPersonRose

private val MOOD_OPTIONS = listOf("Grateful", "Missing You", "Happy", "Calm", "Excited", "Need a Hug")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyPersonScreen(
    currentUserId: String,
    space: MyPersonSpace?,
    memories: List<MyPersonMemory>,
    notes: List<MyPersonNote>,
    friendships: List<Friendship>,
    peerProfiles: Map<String, PublicProfile>,
    onSelectMyPerson: (String) -> Unit,
    onSendHug: () -> Unit,
    onUpdateMood: (String) -> Unit,
    onUpdateDates: (anniversaryMs: Long, birthdayMs: Long) -> Unit,
    onAddMemory: (title: String, description: String, dateLabel: String, photoUri: Uri?) -> Unit,
    onAddNote: (content: String, colorTag: String) -> Unit,
    onTogglePinNote: (MyPersonNote) -> Unit,
    onMessagePartner: (String) -> Unit,
    onCallPartner: (String, Boolean) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val strings = LocalStrings.current
    var showPartnerPicker by remember { mutableStateOf(false) }
    var showAddMemory by remember { mutableStateOf(false) }
    var showAddNote by remember { mutableStateOf(false) }
    var pickingDateTarget by remember { mutableStateOf<String?>(null) } // "ANNIVERSARY" or "BIRTHDAY"
    var hugPulse by remember { mutableStateOf(false) }
    val hugScale by animateFloatAsState(
        targetValue = if (hugPulse) 1.15f else 1f,
        animationSpec = spring(),
        finishedListener = { hugPulse = false },
        label = "hugScale"
    )

    val partnerUid = space?.memberUids?.firstOrNull { it != currentUserId }
    val partnerProfile = partnerUid?.let { peerProfiles[it] }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text(strings.myPerson, style = MaterialTheme.typography.titleLarge)
                }
                TextButton(onClick = { showPartnerPicker = true }) {
                    Text(if (space == null) "Choose Friend" else "Switch")
                }
            }
        }

        if (space == null || partnerUid == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .clip(RoundedCornerShape(24.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_myperson_banner),
                        contentDescription = "My Person Sanctuary",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(Modifier.height(20.dp))
                Text("Your Private My Person Space", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Choose one special friend for private shared memories, notes, mood sharing, countdowns, and virtual hugs.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = { showPartnerPicker = true },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("myperson_select_btn")
                ) {
                    Icon(Icons.Filled.Favorite, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Select Special Friend")
                }
            }
        } else {
            val myMood = space.moodByUid[currentUserId] ?: "Connected"
            val partnerMood = space.moodByUid[partnerUid] ?: "Thinking of you"

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Hero Banner + Partner Header + Quick Shortcuts
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(24.dp))
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_myperson_banner),
                            contentDescription = "My Person Header",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.matchParentSize()
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(Color(0x99101218))
                        )
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                HelloAvatar(
                                    name = partnerProfile?.displayName ?: "My Person",
                                    photoUrl = partnerProfile?.photoUrl.orEmpty(),
                                    size = 64.dp,
                                    isOnline = partnerProfile?.onlineStatus == "ONLINE",
                                    hasStoryRing = true,
                                    isMyPersonRing = true
                                )
                                Spacer(Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = partnerProfile?.displayName ?: "Special Friend",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Mood: $partnerMood",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFFBCFE8)
                                    )
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onMessagePartner(partnerUid) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(0.18f)),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Chat, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Message", color = Color.White)
                                }
                                IconButton(
                                    onClick = { onCallPartner(partnerUid, false) },
                                    modifier = Modifier.clip(CircleShape).background(Color.White.copy(0.18f))
                                ) {
                                    Icon(Icons.Filled.Call, contentDescription = "Audio call", tint = Color.White)
                                }
                                IconButton(
                                    onClick = { onCallPartner(partnerUid, true) },
                                    modifier = Modifier.clip(CircleShape).background(Color.White.copy(0.18f))
                                ) {
                                    Icon(Icons.Filled.Videocam, contentDescription = "Video call", tint = Color.White)
                                }
                            }
                        }
                    }
                }

                // Virtual Hugs Card
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Virtual Hugs", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${space.hugCount} hugs shared together",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Button(
                                onClick = {
                                    hugPulse = true
                                    onSendHug()
                                },
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MyPersonRose),
                                modifier = Modifier
                                    .scale(hugScale)
                                    .testTag("send_virtual_hug_btn")
                            ) {
                                Icon(Icons.Filled.Favorite, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(strings.sendVirtualHug, color = Color.White)
                            }
                        }
                    }
                }

                // Anniversary & Birthday Countdowns
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { pickingDateTarget = "ANNIVERSARY" }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Icon(Icons.Filled.CalendarMonth, null, tint = HelloViolet)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "${TimeFormatters.daysUntilAnnualDate(space.anniversaryEpochMs)} days",
                                    style = MaterialTheme.typography.headlineSmall
                                )
                                Text(strings.anniversaryCountdown, style = MaterialTheme.typography.labelMedium)
                                Text(
                                    TimeFormatters.formatDateLabel(space.anniversaryEpochMs),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { pickingDateTarget = "BIRTHDAY" }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Icon(Icons.Filled.Cake, null, tint = HelloBlue)
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "${TimeFormatters.daysUntilAnnualDate(space.partnerBirthdayEpochMs)} days",
                                    style = MaterialTheme.typography.headlineSmall
                                )
                                Text(strings.birthdayCountdown, style = MaterialTheme.typography.labelMedium)
                                Text(
                                    TimeFormatters.formatDateLabel(space.partnerBirthdayEpochMs),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Mood Sharing
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${strings.moodSharing}: $myMood", style = MaterialTheme.typography.titleMedium)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(MOOD_OPTIONS) { mood ->
                                FilterChip(
                                    selected = myMood == mood,
                                    onClick = { onUpdateMood(mood) },
                                    label = { Text(mood) }
                                )
                            }
                        }
                    }
                }

                // Special Notes Section
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.specialNotes, style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { showAddNote = true }) {
                            Icon(Icons.Filled.Add, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add Note")
                        }
                    }
                }

                items(notes, key = { it.id }) { note ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(note.content, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            IconButton(onClick = { onTogglePinNote(note) }) {
                                Icon(
                                    Icons.Filled.PushPin,
                                    contentDescription = "Pin note",
                                    tint = if (note.pinned) MyPersonRose else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Private Shared Memories Section
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(strings.sharedMemories, style = MaterialTheme.typography.titleMedium)
                        TextButton(onClick = { showAddMemory = true }) {
                            Icon(Icons.Filled.Add, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add Memory")
                        }
                    }
                }

                items(memories, key = { it.id }) { mem ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (mem.mediaUrl.isNotBlank()) {
                                AsyncImage(
                                    model = mem.mediaUrl,
                                    contentDescription = mem.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(mem.title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    mem.memoryDateLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (mem.description.isNotBlank()) {
                                Text(mem.description, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPartnerPicker) {
        val friends = friendships.mapNotNull { f ->
            val pUid = f.memberUids.firstOrNull { it != currentUserId }
            pUid?.let { peerProfiles[it] }
        }
        AlertDialog(
            onDismissRequest = { showPartnerPicker = false },
            title = { Text("Select My Person") },
            text = {
                if (friends.isEmpty()) {
                    Text("Connect with a friend first to invite them into your My Person space.")
                } else {
                    LazyColumn(modifier = Modifier.height(220.dp)) {
                        items(friends, key = { it.userId }) { friend ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showPartnerPicker = false
                                        onSelectMyPerson(friend.userId)
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                HelloAvatar(name = friend.displayName, photoUrl = friend.photoUrl, size = 40.dp)
                                Spacer(Modifier.width(10.dp))
                                Text(friend.displayName, style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPartnerPicker = false }) { Text("Close") } }
        )
    }

    if (showAddNote) {
        var noteText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddNote = false },
            title = { Text("New Special Note") },
            text = {
                OutlinedTextField(
                    value = noteText,
                    onValueChange = { noteText = it },
                    label = { Text("Write something thoughtful...") },
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(enabled = noteText.isNotBlank(), onClick = {
                    onAddNote(noteText, "ROSE")
                    showAddNote = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddNote = false }) { Text("Cancel") } }
        )
    }

    if (showAddMemory) {
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var dateLabel by remember { mutableStateOf("Today") }
        var pickedUri by remember { mutableStateOf<Uri?>(null) }
        val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) pickedUri = uri
        }

        AlertDialog(
            onDismissRequest = { showAddMemory = false },
            title = { Text("Save Private Memory") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(value = dateLabel, onValueChange = { dateLabel = it }, label = { Text("Date Label") }, singleLine = true)
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Story / Note") }, maxLines = 3)
                    OutlinedButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Filled.PhotoLibrary, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (pickedUri != null) "Photo Attached" else "Attach Photo")
                    }
                }
            },
            confirmButton = {
                Button(enabled = title.isNotBlank(), onClick = {
                    onAddMemory(title, desc, dateLabel, pickedUri)
                    showAddMemory = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddMemory = false }) { Text("Cancel") } }
        )
    }

    if (pickingDateTarget != null && space != null) {
        val dateState = rememberDatePickerState()
        DatePickerDialog(
            onDismissRequest = { pickingDateTarget = null },
            confirmButton = {
                TextButton(onClick = {
                    val chosen = dateState.selectedDateMillis
                    if (chosen != null) {
                        if (pickingDateTarget == "ANNIVERSARY") {
                            onUpdateDates(chosen, space.partnerBirthdayEpochMs)
                        } else {
                            onUpdateDates(space.anniversaryEpochMs, chosen)
                        }
                    }
                    pickingDateTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { pickingDateTarget = null }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = dateState)
        }
    }
}
