package com.example.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.AppLanguage
import com.example.data.PrivateAccount
import com.example.data.PublicProfile
import com.example.data.StoryPrivacy
import com.example.data.ThemeMode
import com.example.localization.LocalStrings
import com.example.ui.components.HelloAvatar
import com.example.ui.theme.LocalHelloColors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.MyPersonRose

@Composable
fun ProfileSettingsScreen(
    myProfile: PublicProfile?,
    privateAccount: PrivateAccount?,
    peerProfiles: Map<String, PublicProfile>,
    currentLanguage: AppLanguage,
    currentTheme: ThemeMode,
    onEditProfile: (displayName: String, username: String, bio: String, photoUri: Uri?) -> Unit,
    onUpdateSettings: (
        showOnline: Boolean,
        showReceipts: Boolean,
        storyPrivacy: StoryPrivacy,
        language: AppLanguage,
        themeMode: ThemeMode,
        notifications: Boolean
    ) -> Unit,
    onUnblockUser: (String) -> Unit,
    onOpenFriends: () -> Unit,
    onOpenMyPerson: () -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit
) {
    val strings = LocalStrings.current
    val helloColors = LocalHelloColors.current

    var showEditDialog by remember { mutableStateOf(false) }
    var showBlockedDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showBackendStatus by remember { mutableStateOf(false) }

    val showOnline = privateAccount?.showOnlineStatus ?: true
    val showReceipts = privateAccount?.showReadReceipts ?: true
    val storyPrivacy = StoryPrivacy.fromRaw(privateAccount?.storyPrivacy)
    val notificationsEnabled = privateAccount?.notificationsEnabled ?: true
    val blockedUids = privateAccount?.blockedUids ?: emptyList()

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        onUpdateSettings(showOnline, showReceipts, storyPrivacy, currentLanguage, currentTheme, granted)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Profile Identity Card
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HelloAvatar(
                            name = myProfile?.displayName ?: "Hello User",
                            photoUrl = myProfile?.photoUrl.orEmpty(),
                            size = 68.dp,
                            isOnline = myProfile?.onlineStatus == "ONLINE"
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = myProfile?.displayName ?: "Hello User",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "@${myProfile?.username.orEmpty()}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (!myProfile?.bio.isNullOrBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = myProfile?.bio.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { showEditDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f).testTag("edit_profile_btn")
                        ) {
                            Icon(Icons.Filled.Edit, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Edit Profile")
                        }
                        OutlinedButton(
                            onClick = onOpenFriends,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.People, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.friends)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = onOpenMyPerson,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Favorite, null, tint = MyPersonRose, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.myPerson)
                    }
                }
            }
        }

        // Language & Appearance
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Language, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.languageLabel, style = MaterialTheme.typography.titleMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = currentLanguage == lang,
                                onClick = {
                                    onUpdateSettings(showOnline, showReceipts, storyPrivacy, lang, currentTheme, notificationsEnabled)
                                },
                                label = { Text(lang.label) }
                            )
                        }
                    }

                    HorizontalDivider(color = helloColors.subtleDivider)

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.DarkMode, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.themeLabel, style = MaterialTheme.typography.titleMedium)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = currentTheme == mode,
                                onClick = {
                                    onUpdateSettings(showOnline, showReceipts, storyPrivacy, currentLanguage, mode, notificationsEnabled)
                                },
                                label = { Text(mode.label, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        }

        // Privacy & Notifications
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.privacySettings, style = MaterialTheme.typography.titleMedium)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Show Online Status", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = showOnline,
                            onCheckedChange = {
                                onUpdateSettings(it, showReceipts, storyPrivacy, currentLanguage, currentTheme, notificationsEnabled)
                            }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Read Receipts", style = MaterialTheme.typography.bodyMedium)
                        Switch(
                            checked = showReceipts,
                            onCheckedChange = {
                                onUpdateSettings(showOnline, it, storyPrivacy, currentLanguage, currentTheme, notificationsEnabled)
                            }
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Notifications, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.notificationSettings, style = MaterialTheme.typography.bodyMedium)
                        }
                        Switch(
                            checked = notificationsEnabled,
                            onCheckedChange = { enabled ->
                                if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    onUpdateSettings(showOnline, showReceipts, storyPrivacy, currentLanguage, currentTheme, enabled)
                                }
                            }
                        )
                    }

                    HorizontalDivider(color = helloColors.subtleDivider)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showBlockedDialog = true }
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Block, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(strings.blockedUsers, style = MaterialTheme.typography.bodyMedium)
                        }
                        Text("${blockedUids.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Account Management & External Service Status
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(strings.accountManagement, style = MaterialTheme.typography.titleMedium)

                    if (!myProfile?.e2eePublicKey.isNullOrBlank()) {
                        Text(
                            text = "E2EE Key: ${myProfile?.e2eePublicKey?.take(26)}...",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedButton(
                        onClick = { showBackendStatus = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.CloudDone, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Backend & Service Configuration")
                    }

                    OutlinedButton(
                        onClick = onSignOut,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(strings.signOut)
                    }

                    Button(
                        onClick = { showDeleteConfirm = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.DeleteForever, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(strings.deleteAccount)
                    }
                }
            }
        }
    }

    if (showEditDialog && myProfile != null) {
        var name by remember { mutableStateOf(myProfile.displayName) }
        var username by remember { mutableStateOf(myProfile.username) }
        var bio by remember { mutableStateOf(myProfile.bio) }
        var pickedUri by remember { mutableStateOf<Uri?>(null) }
        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) pickedUri = uri
        }
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Edit Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Text(if (pickedUri != null) "New Photo Selected" else "Change Profile Photo")
                    }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text(strings.displayName) })
                    OutlinedTextField(value = username, onValueChange = { username = it.lowercase() }, label = { Text(strings.username) })
                    OutlinedTextField(value = bio, onValueChange = { bio = it }, label = { Text(strings.bio) }, maxLines = 3)
                }
            },
            confirmButton = {
                Button(onClick = {
                    onEditProfile(name, username, bio, pickedUri)
                    showEditDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showEditDialog = false }) { Text("Cancel") } }
        )
    }

    if (showBlockedDialog) {
        AlertDialog(
            onDismissRequest = { showBlockedDialog = false },
            title = { Text(strings.blockedUsers) },
            text = {
                if (blockedUids.isEmpty()) {
                    Text("You haven't blocked anyone.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        blockedUids.forEach { uid ->
                            val name = peerProfiles[uid]?.displayName ?: uid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name)
                                TextButton(onClick = { onUnblockUser(uid) }) { Text("Unblock") }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showBlockedDialog = false }) { Text("Done") } }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Account?") },
            text = { Text("This removes your Hello App profile, username reservation, and private account record permanently.") },
            confirmButton = {
                Button(
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteAccount()
                    }
                ) { Text("Delete Forever") }
            },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") } }
        )
    }

    if (showBackendStatus) {
        AlertDialog(
            onDismissRequest = { showBackendStatus = false },
            title = { Text("Service & Credential Status") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("• Cloud Firestore & Security Rules: Active & Deployed")
                    Text("• Google Sign-In (Credential Manager): Active")
                    Text("• E2EE (ECDH P-256 + HKDF + AES-GCM-256): Active")
                    Text(
                        if (BuildConfig.TURN_SERVER_URL.isNotBlank() && !BuildConfig.TURN_SERVER_URL.startsWith("YOUR_TURN_")) "• WebRTC TURN Relay: Configured"
                        else "• WebRTC ICE: Public Google STUN active; configure TURN_SERVER_URL, TURN_USERNAME, TURN_CREDENTIAL in Secrets for strict NAT relay."
                    )
                    Text("• Firebase Storage, Phone OTP, Apple Sign-In, & Background FCM Push Triggers: Enable in Firebase Console if not yet activated.")
                }
            },
            confirmButton = { TextButton(onClick = { showBackendStatus = false }) { Text("OK") } }
        )
    }
}
