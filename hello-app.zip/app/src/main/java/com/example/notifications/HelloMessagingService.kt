package com.example.notifications

import com.example.data.PreferencesManager
import com.example.data.ProfileRepository
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class HelloMessagingService : FirebaseMessagingService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        serviceScope.launch {
            val prefs = PreferencesManager(applicationContext)
            ProfileRepository(applicationContext, prefs).syncFcmToken(token)
        }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title ?: message.data["title"] ?: "Hello App"
        val body = message.notification?.body ?: message.data["body"] ?: "New activity in your circle"
        val channel = when (message.data["type"]) {
            "call" -> NotificationHelper.CHANNEL_CALLS
            "myperson" -> NotificationHelper.CHANNEL_MY_PERSON
            else -> NotificationHelper.CHANNEL_MESSAGES
        }
        NotificationHelper.showNotification(
            context = applicationContext,
            channelId = channel,
            notificationId = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            title = title,
            body = body
        )
    }
}
