package com.example.webrtc

import android.content.Context
import android.media.AudioManager
import android.util.Log
import com.example.BuildConfig
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.Camera2Enumerator
import org.webrtc.CameraVideoCapturer
import org.webrtc.DataChannel
import org.webrtc.DefaultVideoDecoderFactory
import org.webrtc.DefaultVideoEncoderFactory
import org.webrtc.EglBase
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.SurfaceTextureHelper
import org.webrtc.SurfaceViewRenderer
import org.webrtc.VideoSource
import org.webrtc.VideoTrack

class WebRtcCallClient(
    private val context: Context,
    private val isVideoCall: Boolean,
    private val onLocalIceCandidate: (IceCandidate) -> Unit,
    private val onRemoteVideoTrack: (VideoTrack) -> Unit,
    private val onConnectionStateChanged: (PeerConnection.PeerConnectionState) -> Unit
) {
    val eglBase: EglBase = EglBase.create()

    private val peerConnectionFactory: PeerConnectionFactory
    private var peerConnection: PeerConnection? = null
    private var audioSource: AudioSource? = null
    private var localAudioTrack: AudioTrack? = null
    private var videoSource: VideoSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    val hasTurnServerConfigured: Boolean
        get() = isConfiguredValue(BuildConfig.TURN_SERVER_URL)

    init {
        val initOptions = PeerConnectionFactory.InitializationOptions.builder(context.applicationContext)
            .createInitializationOptions()
        PeerConnectionFactory.initialize(initOptions)

        val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        setupLocalTracks()
        setupPeerConnection()
    }

    private fun buildIceServers(): List<PeerConnection.IceServer> {
        val servers = mutableListOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        val turnUrl = BuildConfig.TURN_SERVER_URL.trim()
        if (isConfiguredValue(turnUrl)) {
            val builder = PeerConnection.IceServer.builder(turnUrl)
            if (isConfiguredValue(BuildConfig.TURN_USERNAME)) {
                builder.setUsername(BuildConfig.TURN_USERNAME.trim())
            }
            if (isConfiguredValue(BuildConfig.TURN_CREDENTIAL)) {
                builder.setPassword(BuildConfig.TURN_CREDENTIAL.trim())
            }
            servers.add(builder.createIceServer())
        }
        return servers
    }

    private fun isConfiguredValue(value: String): Boolean {
        val trimmed = value.trim()
        return trimmed.isNotBlank() && !trimmed.startsWith("YOUR_TURN_")
    }

    private fun setupLocalTracks() {
        val audioConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
        }
        audioSource = peerConnectionFactory.createAudioSource(audioConstraints)
        localAudioTrack = peerConnectionFactory.createAudioTrack("HELLO_AUDIO_0", audioSource)
        localAudioTrack?.setEnabled(true)

        if (isVideoCall) {
            val enumerator = Camera2Enumerator(context)
            val deviceName = enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
                ?: enumerator.deviceNames.firstOrNull()
            if (deviceName != null) {
                videoCapturer = enumerator.createCapturer(deviceName, null)
                surfaceTextureHelper = SurfaceTextureHelper.create("HelloCaptureThread", eglBase.eglBaseContext)
                videoSource = peerConnectionFactory.createVideoSource(videoCapturer?.isScreencast == true)
                videoCapturer?.initialize(surfaceTextureHelper, context.applicationContext, videoSource?.capturerObserver)
                try {
                    videoCapturer?.startCapture(640, 480, 24)
                } catch (e: Exception) {
                    Log.w(TAG, "Camera capture start failed: ${e.message}")
                }
                localVideoTrack = peerConnectionFactory.createVideoTrack("HELLO_VIDEO_0", videoSource)
                localVideoTrack?.setEnabled(true)
            }
        }
    }

    private fun setupPeerConnection() {
        val rtcConfig = PeerConnection.RTCConfiguration(buildIceServers()).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }

        peerConnection = peerConnectionFactory.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate?.let(onLocalIceCandidate)
                }

                override fun onConnectionChange(newState: PeerConnection.PeerConnectionState?) {
                    newState?.let(onConnectionStateChanged)
                }

                override fun onAddTrack(receiver: RtpReceiver?, mediaStreams: Array<out MediaStream>?) {
                    val track = receiver?.track()
                    if (track is VideoTrack) {
                        onRemoteVideoTrack(track)
                    }
                }

                override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
                override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
                override fun onIceConnectionReceivingChange(p0: Boolean) {}
                override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
                override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
                override fun onAddStream(p0: MediaStream?) {}
                override fun onRemoveStream(p0: MediaStream?) {}
                override fun onDataChannel(p0: DataChannel?) {}
                override fun onRenegotiationNeeded() {}
            }
        )

        val streamIds = listOf("HELLO_STREAM")
        localAudioTrack?.let { peerConnection?.addTrack(it, streamIds) }
        localVideoTrack?.let { peerConnection?.addTrack(it, streamIds) }
    }

    fun attachLocalRenderer(renderer: SurfaceViewRenderer) {
        renderer.init(eglBase.eglBaseContext, null)
        renderer.setMirror(true)
        localVideoTrack?.addSink(renderer)
    }

    fun attachRemoteRenderer(renderer: SurfaceViewRenderer, remoteTrack: VideoTrack) {
        renderer.init(eglBase.eglBaseContext, null)
        renderer.setMirror(false)
        remoteTrack.addSink(renderer)
    }

    fun createOffer(onOfferCreated: (SessionDescription) -> Unit, onFailure: (String) -> Unit) {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", isVideoCall.toString()))
        }
        peerConnection?.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc == null) {
                    onFailure("Empty SDP offer.")
                    return
                }
                peerConnection?.setLocalDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() = onOfferCreated(desc)
                    override fun onSetFailure(err: String?) = onFailure(err ?: "Failed to set local offer.")
                }, desc)
            }

            override fun onCreateFailure(err: String?) = onFailure(err ?: "Failed to create offer.")
        }, constraints)
    }

    fun acceptOfferAndCreateAnswer(
        offerSdp: String,
        onAnswerCreated: (SessionDescription) -> Unit,
        onFailure: (String) -> Unit
    ) {
        val remoteOffer = SessionDescription(SessionDescription.Type.OFFER, offerSdp)
        peerConnection?.setRemoteDescription(object : SimpleSdpObserver() {
            override fun onSetSuccess() {
                val constraints = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", isVideoCall.toString()))
                }
                peerConnection?.createAnswer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(desc: SessionDescription?) {
                        if (desc == null) {
                            onFailure("Empty SDP answer.")
                            return
                        }
                        peerConnection?.setLocalDescription(object : SimpleSdpObserver() {
                            override fun onSetSuccess() = onAnswerCreated(desc)
                            override fun onSetFailure(err: String?) = onFailure(err ?: "Failed to set local answer.")
                        }, desc)
                    }

                    override fun onCreateFailure(err: String?) = onFailure(err ?: "Failed to create answer.")
                }, constraints)
            }

            override fun onSetFailure(err: String?) = onFailure(err ?: "Failed to set remote offer.")
        }, remoteOffer)
    }

    fun setRemoteAnswer(answerSdp: String) {
        val remoteAnswer = SessionDescription(SessionDescription.Type.ANSWER, answerSdp)
        peerConnection?.setRemoteDescription(SimpleSdpObserver(), remoteAnswer)
    }

    fun addRemoteIceCandidate(sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
    }

    fun setMuted(muted: Boolean) {
        localAudioTrack?.setEnabled(!muted)
    }

    fun setCameraEnabled(enabled: Boolean) {
        localVideoTrack?.setEnabled(enabled)
    }

    fun switchCamera() {
        videoCapturer?.switchCamera(null)
    }

    fun setSpeakerphone(enabled: Boolean) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION")
        audioManager.isSpeakerphoneOn = enabled
    }

    fun dispose() {
        try {
            videoCapturer?.stopCapture()
        } catch (_: Exception) {
        }
        videoCapturer?.dispose()
        surfaceTextureHelper?.dispose()
        localVideoTrack?.dispose()
        videoSource?.dispose()
        localAudioTrack?.dispose()
        audioSource?.dispose()
        peerConnection?.close()
        peerConnection?.dispose()
        peerConnectionFactory.dispose()
        eglBase.release()
    }

    private open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) {}
        override fun onSetFailure(p0: String?) {}
    }

    private companion object {
        const val TAG = "WebRtcCallClient"
    }
}
