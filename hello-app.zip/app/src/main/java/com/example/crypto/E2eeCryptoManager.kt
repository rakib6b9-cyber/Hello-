package com.example.crypto

import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

data class EncryptedPayload(
    val ciphertextBase64: String,
    val ivBase64: String
)

data class IdentityKeyPairEncoded(
    val publicKeyBase64: String,
    val privateKeyBase64: String
)

/**
 * Real End-to-End Encryption manager implementing:
 * - NIST P-256 (secp256r1) Elliptic Curve Diffie-Hellman (ECDH) key agreement
 * - HKDF-SHA256 key derivation bound to conversation context
 * - AES-256-GCM authenticated encryption with 96-bit random IV and 128-bit auth tag
 */
object E2eeCryptoManager {

    private const val CURVE_NAME = "secp256r1"
    private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_BITS = 128
    private const val GCM_IV_BYTES = 12
    private const val AES_KEY_BYTES = 32
    private val secureRandom = SecureRandom()

    fun generateIdentityKeyPair(): IdentityKeyPairEncoded {
        val generator = KeyPairGenerator.getInstance("EC")
        generator.initialize(ECGenParameterSpec(CURVE_NAME), secureRandom)
        val pair = generator.generateKeyPair()
        return IdentityKeyPairEncoded(
            publicKeyBase64 = encodeBase64(pair.public.encoded),
            privateKeyBase64 = encodeBase64(pair.private.encoded)
        )
    }

    fun deriveDirectChatKey(
        myPrivateKeyBase64: String,
        peerPublicKeyBase64: String,
        chatContextId: String
    ): ByteArray {
        val privKey = decodePrivateKey(myPrivateKeyBase64)
        val pubKey = decodePublicKey(peerPublicKeyBase64)
        val keyAgreement = KeyAgreement.getInstance("ECDH")
        keyAgreement.init(privKey)
        keyAgreement.doPhase(pubKey, true)
        val sharedSecret = keyAgreement.generateSecret()
        return hkdfSha256(
            ikm = sharedSecret,
            salt = "hello-app-e2ee-v1".toByteArray(StandardCharsets.UTF_8),
            info = chatContextId.toByteArray(StandardCharsets.UTF_8),
            length = AES_KEY_BYTES
        )
    }

    fun generateGroupAesKey(): ByteArray {
        val key = ByteArray(AES_KEY_BYTES)
        secureRandom.nextBytes(key)
        return key
    }

    fun wrapGroupKey(
        groupKeyBytes: ByteArray,
        myPrivateKeyBase64: String,
        memberPublicKeyBase64: String,
        chatId: String
    ): String {
        val wrappingKey = deriveDirectChatKey(myPrivateKeyBase64, memberPublicKeyBase64, "wrap:$chatId")
        val payload = encryptBytes(groupKeyBytes, wrappingKey)
        return "${payload.ivBase64}:${payload.ciphertextBase64}"
    }

    fun unwrapGroupKey(
        wrappedPayload: String,
        myPrivateKeyBase64: String,
        senderPublicKeyBase64: String,
        chatId: String
    ): ByteArray? {
        val parts = wrappedPayload.split(":")
        if (parts.size != 2) return null
        val wrappingKey = deriveDirectChatKey(myPrivateKeyBase64, senderPublicKeyBase64, "wrap:$chatId")
        return decryptBytes(parts[1], parts[0], wrappingKey)
    }

    fun encryptText(plaintext: String, aesKeyBytes: ByteArray): EncryptedPayload {
        return encryptBytes(plaintext.toByteArray(StandardCharsets.UTF_8), aesKeyBytes)
    }

    fun decryptText(ciphertextBase64: String, ivBase64: String, aesKeyBytes: ByteArray): String? {
        val plainBytes = decryptBytes(ciphertextBase64, ivBase64, aesKeyBytes) ?: return null
        return String(plainBytes, StandardCharsets.UTF_8)
    }

    fun encryptBytes(plainBytes: ByteArray, aesKeyBytes: ByteArray): EncryptedPayload {
        val iv = ByteArray(GCM_IV_BYTES)
        secureRandom.nextBytes(iv)
        val keySpec: SecretKey = SecretKeySpec(aesKeyBytes, "AES")
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, GCMParameterSpec(GCM_TAG_BITS, iv))
        val ciphertext = cipher.doFinal(plainBytes)
        return EncryptedPayload(
            ciphertextBase64 = encodeBase64(ciphertext),
            ivBase64 = encodeBase64(iv)
        )
    }

    fun decryptBytes(ciphertextBase64: String, ivBase64: String, aesKeyBytes: ByteArray): ByteArray? {
        return try {
            val ciphertext = decodeBase64(ciphertextBase64)
            val iv = decodeBase64(ivBase64)
            val keySpec: SecretKey = SecretKeySpec(aesKeyBytes, "AES")
            val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, GCMParameterSpec(GCM_TAG_BITS, iv))
            cipher.doFinal(ciphertext)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Generates a 60-digit human-verifiable Safety Number from the two users' public keys.
     */
    fun computeSafetyNumber(firstPublicKeyBase64: String, secondPublicKeyBase64: String): String {
        val sorted = listOf(firstPublicKeyBase64, secondPublicKeyBase64).sorted()
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(sorted[0].toByteArray(StandardCharsets.UTF_8))
        digest.update(":".toByteArray(StandardCharsets.UTF_8))
        digest.update(sorted[1].toByteArray(StandardCharsets.UTF_8))
        val hash = digest.digest()
        val digits = StringBuilder()
        var idx = 0
        while (digits.length < 60) {
            val b1 = hash[idx % hash.size].toInt() and 0xFF
            val b2 = hash[(idx + 1) % hash.size].toInt() and 0xFF
            val num = ((b1 shl 8) or b2) % 100000
            digits.append(String.format("%05d", num))
            idx += 2
        }
        return digits.substring(0, 60).chunked(5).joinToString(" ")
    }

    fun hashPhoneE164(normalizedE164: String): String {
        val cleaned = normalizedE164.replace(Regex("[^+0-9]"), "")
        val digest = MessageDigest.getInstance("SHA-256").digest(cleaned.toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    private fun hkdfSha256(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(salt, "HmacSHA256"))
        val prk = mac.doFinal(ikm)

        val result = ByteArray(length)
        var t = ByteArray(0)
        var offset = 0
        var counter = 1
        while (offset < length) {
            mac.init(SecretKeySpec(prk, "HmacSHA256"))
            mac.update(t)
            mac.update(info)
            mac.update(counter.toByte())
            t = mac.doFinal()
            val copyLen = minOf(t.size, length - offset)
            System.arraycopy(t, 0, result, offset, copyLen)
            offset += copyLen
            counter++
        }
        return result
    }

    private fun decodePublicKey(base64: String): PublicKey {
        val bytes = decodeBase64(base64)
        return KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(bytes))
    }

    private fun decodePrivateKey(base64: String): PrivateKey {
        val bytes = decodeBase64(base64)
        return KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(bytes))
    }

    private fun encodeBase64(bytes: ByteArray): String =
        Base64.encodeToString(bytes, Base64.NO_WRAP)

    private fun decodeBase64(encoded: String): ByteArray =
        Base64.decode(encoded, Base64.NO_WRAP)
}
