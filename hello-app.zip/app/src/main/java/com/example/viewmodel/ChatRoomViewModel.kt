package com.example.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.E2eeCryptoManager
import com.example.data.Chat
import com.example.data.ChatMessage
import com.example.data.ChatRepository
import com.example.data.MessageType
import com.example.data.PreferencesManager
import com.example.data.ProfileRepository
import com.example.data.PublicProfile
import com.example.data.UiState
import com.example.data.unwrapFirestoreMessage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatRoomViewModel(
    val chatId: String,
    val currentUserId: String,
    private val chatRepo: ChatRepository,
    private val profileRepo: ProfileRepository,
    private val prefs: PreferencesManager
) : ViewModel() {

    private var cachedAesKey: ByteArray? = null
    private var typingJob: Job? = null

    private val _safetyNumber = MutableStateFlow<String?>(null)
    val safetyNumber: StateFlow<String?> = _safetyNumber.asStateFlow()

    private val _actionError = MutableStateFlow<String?>(null)
    val actionError: StateFlow<String?> = _actionError.asStateFlow()

    private val _isSendingMedia = MutableStateFlow(false)
    val isSendingMedia: StateFlow<Boolean> = _isSendingMedia.asStateFlow()

    val messagesState: StateFlow<UiState<List<ChatMessage>>> = chatRepo.observeMessages(chatId, currentUserId)
        .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
        .catch { error ->
            val msg = unwrapFirestoreMessage(error, "Failed to load messages.")
            Log.w(TAG, "Messages stream error: $msg", error)
            emit(UiState.Error(msg))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    fun ensureEncryptionKey(chat: Chat, peerProfile: PublicProfile?, creatorProfile: PublicProfile?) {
        viewModelScope.launch {
            cachedAesKey = chatRepo.deriveChatAesKey(chat, peerProfile, creatorProfile)
            if (chat.chatType == "DIRECT" && peerProfile?.e2eePublicKey?.isNotBlank() == true) {
                val myPub = prefs.getOrCreateE2eeKeyPair(currentUserId).publicKeyBase64
                _safetyNumber.value = E2eeCryptoManager.computeSafetyNumber(myPub, peerProfile.e2eePublicKey)
            }
        }
    }

    fun decryptText(message: ChatMessage): String =
        chatRepo.decryptMessageText(message, cachedAesKey)

    fun onDraftChanged(chat: Chat, draft: String) {
        typingJob?.cancel()
        if (draft.isBlank()) {
            viewModelScope.launch { chatRepo.setTypingStatus(chat, false) }
            return
        }
        typingJob = viewModelScope.launch {
            chatRepo.setTypingStatus(chat, true)
            delay(2500L)
            chatRepo.setTypingStatus(chat, false)
        }
    }

    fun markRead(chat: Chat, messages: List<ChatMessage>, showReadReceipts: Boolean) {
        viewModelScope.launch {
            chatRepo.markChatReadAndDelivered(chat, messages, showReadReceipts)
        }
    }

    fun sendText(
        chat: Chat,
        senderName: String,
        text: String,
        replyTo: ChatMessage? = null
    ) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            val replyPreview = replyTo?.let { decryptText(it).take(80) }.orEmpty()
            chatRepo.sendMessage(
                chat = chat,
                senderName = senderName,
                plaintext = trimmed,
                messageType = MessageType.TEXT,
                aesKey = cachedAesKey,
                replyToId = replyTo?.id.orEmpty(),
                replyToPreview = replyPreview
            ).onFailure { _actionError.value = it.localizedMessage }
            chatRepo.setTypingStatus(chat, false)
        }
    }

    fun sendMedia(
        chat: Chat,
        senderName: String,
        uri: Uri,
        messageType: MessageType,
        displayName: String,
        durationSec: Long = 0L
    ) {
        viewModelScope.launch {
            _isSendingMedia.value = true
            val ext = when (messageType) {
                MessageType.IMAGE -> "jpg"
                MessageType.VIDEO -> "mp4"
                MessageType.VOICE -> "m4a"
                MessageType.DOCUMENT -> displayName.substringAfterLast(".", "bin")
                else -> "bin"
            }
            val upload = profileRepo.uploadMedia(uri, "chats/${chat.id}", ext)
            upload.onSuccess { url ->
                chatRepo.sendMessage(
                    chat = chat,
                    senderName = senderName,
                    plaintext = displayName,
                    messageType = messageType,
                    aesKey = cachedAesKey,
                    mediaUrl = url,
                    mediaName = displayName,
                    mediaDurationSec = durationSec
                ).onFailure { _actionError.value = it.localizedMessage }
            }.onFailure {
                _actionError.value = it.localizedMessage
            }
            _isSendingMedia.value = false
        }
    }

    fun forwardMessage(targetChat: Chat, senderName: String, original: ChatMessage) {
        val text = decryptText(original)
        viewModelScope.launch {
            val targetPeerKey = cachedAesKey // re-encrypt with target chat key if available
            chatRepo.sendMessage(
                chat = targetChat,
                senderName = senderName,
                plaintext = text,
                messageType = MessageType.fromRaw(original.messageType),
                aesKey = targetPeerKey,
                mediaUrl = original.mediaUrl,
                mediaName = original.mediaName,
                mediaDurationSec = original.mediaDurationSec,
                forwarded = true
            ).onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun editMessage(message: ChatMessage, newText: String) {
        val trimmed = newText.trim()
        if (trimmed.isBlank()) return
        viewModelScope.launch {
            chatRepo.editMessage(chatId, message, trimmed, cachedAesKey)
                .onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            chatRepo.deleteMessage(chatId, messageId)
                .onFailure { _actionError.value = it.localizedMessage }
        }
    }

    fun toggleReaction(message: ChatMessage, emoji: String) {
        viewModelScope.launch {
            chatRepo.toggleMessageReaction(chatId, message, emoji)
        }
    }

    fun clearError() {
        _actionError.value = null
    }

    private companion object {
        const val TAG = "ChatRoomVM"
    }
}
