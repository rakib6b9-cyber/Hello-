package com.example.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.AppLanguage
import com.example.data.CallSession
import com.example.data.CallStatus
import com.example.data.CallType
import com.example.data.Chat
import com.example.data.ChatRepository
import com.example.data.FriendRequest
import com.example.data.FriendsRepository
import com.example.data.Friendship
import com.example.data.MyPersonMemory
import com.example.data.MyPersonNote
import com.example.data.MyPersonSpace
import com.example.data.PreferencesManager
import com.example.data.PrivateAccount
import com.example.data.ProfileRepository
import com.example.data.PublicProfile
import com.example.data.SocialAndCallRepository
import com.example.data.Story
import com.example.data.StoryPrivacy
import com.example.data.ThemeMode
import com.example.data.UiState
import com.example.data.unwrapFirestoreMessage
import com.example.media.DeviceContactEntry
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

class HelloAppViewModel(
    val currentUserId: String,
    private val db: FirebaseFirestore,
    private val prefs: PreferencesManager,
    private val profileRepo: ProfileRepository,
    private val friendsRepo: FriendsRepository,
    private val chatRepo: ChatRepository,
    private val socialAndCallRepo: SocialAndCallRepository
) : ViewModel() {

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _peerProfiles = MutableStateFlow<Map<String, PublicProfile>>(emptyMap())
    val peerProfiles: StateFlow<Map<String, PublicProfile>> = _peerProfiles.asStateFlow()

    private val peerListeners = mutableMapOf<String, ListenerRegistration>()

    val myProfileState: StateFlow<UiState<PublicProfile?>> = profileRepo.observeMyProfile(currentUserId)
        .map<PublicProfile?, UiState<PublicProfile?>> { UiState.Success(it) }
        .catch { error ->
            val msg = unwrapFirestoreMessage(error, "Failed to load profile.")
            Log.w(TAG, "Profile stream error: $msg", error)
            emit(UiState.Error(msg))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val privateAccount: StateFlow<PrivateAccount?> = profileRepo.observePrivateAccount(currentUserId)
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load account settings.")
            emit(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    val friendships: StateFlow<List<Friendship>> = friendsRepo.observeFriendships(currentUserId)
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load friends.")
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val friendRequests: StateFlow<List<FriendRequest>> = friendsRepo.observeFriendRequests(currentUserId)
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load friend requests.")
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val chatsState: StateFlow<UiState<List<Chat>>> = chatRepo.observeChats(currentUserId)
        .map<List<Chat>, UiState<List<Chat>>> { UiState.Success(it) }
        .catch { error ->
            val msg = unwrapFirestoreMessage(error, "Failed to load conversations.")
            Log.w(TAG, "Chats stream error: $msg", error)
            emit(UiState.Error(msg))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val stories: StateFlow<List<Story>> = socialAndCallRepo.observeActiveStories(currentUserId)
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load stories.")
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val myPersonSpace: StateFlow<MyPersonSpace?> = socialAndCallRepo.observeMyPersonSpace(currentUserId)
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load My Person space.")
            emit(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val myPersonMemories: StateFlow<List<MyPersonMemory>> = myPersonSpace
        .flatMapLatest { space ->
            if (space == null) flowOf(emptyList())
            else socialAndCallRepo.observeMemories(space.id, currentUserId)
        }
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load memories.")
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val myPersonNotes: StateFlow<List<MyPersonNote>> = myPersonSpace
        .flatMapLatest { space ->
            if (space == null) flowOf(emptyList())
            else socialAndCallRepo.observeNotes(space.id, currentUserId)
        }
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load notes.")
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val calls: StateFlow<List<CallSession>> = socialAndCallRepo.observeCalls(currentUserId)
        .catch { error ->
            unwrapFirestoreMessage(error, "Failed to load calls.")
            emit(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val incomingRingingCall: StateFlow<CallSession?> = calls.map { list ->
        list.firstOrNull { call ->
            call.status == CallStatus.RINGING.name &&
                call.callerId != currentUserId &&
                currentUserId in call.calleeIds
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)

    init {
        observePeerUidsForRealTimePresence()
        syncFcmTokenSafely()
    }

    private fun observePeerUidsForRealTimePresence() {
        viewModelScope.launch {
            combine(friendships, chatsState, calls) { friends, chatUi, callList ->
                val uids = mutableSetOf<String>()
                friends.forEach { f -> uids.addAll(f.memberUids) }
                if (chatUi is UiState.Success) {
                    chatUi.data.forEach { c -> uids.addAll(c.memberUids) }
                }
                callList.forEach { call -> uids.addAll(call.participantUids) }
                uids.remove(currentUserId)
                uids.toSet()
            }.collect { neededUids ->
                syncPeerListeners(neededUids)
            }
        }
    }

    private fun syncPeerListeners(neededUids: Set<String>) {
        val toRemove = peerListeners.keys - neededUids
        toRemove.forEach { uid ->
            peerListeners.remove(uid)?.remove()
        }
        val toAdd = neededUids - peerListeners.keys
        toAdd.forEach { uid ->
            val reg = db.collection("public_profiles").document(uid)
                .addSnapshotListener { snap, _ ->
                    val profile = snap?.toObject(PublicProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    if (profile != null) {
                        _peerProfiles.value = _peerProfiles.value + (uid to profile)
                    }
                }
            peerListeners[uid] = reg
        }
    }

    private fun syncFcmTokenSafely() {
        viewModelScope.launch {
            try {
                val token = FirebaseMessaging.getInstance().token.await()
                if (token.isNotBlank()) {
                    profileRepo.syncFcmToken(token)
                }
            } catch (_: Exception) {
            }
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun showBanner(message: String) {
        _statusBanner.value = message
    }

    fun setOnlinePresence(online: Boolean) {
        viewModelScope.launch {
            val allowVisible = privateAccount.value?.showOnlineStatus ?: true
            val status = if (online && allowVisible) "ONLINE" else "OFFLINE"
            profileRepo.updatePresence(status)
        }
    }

    fun saveProfile(
        displayName: String,
        username: String,
        bio: String,
        photoUri: Uri?,
        existingPhotoUrl: String,
        countryCode: String,
        localPhone: String,
        language: AppLanguage,
        themeMode: ThemeMode,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            var finalPhotoUrl = existingPhotoUrl
            if (photoUri != null) {
                val uploadRes = profileRepo.uploadMedia(photoUri, "avatars", "jpg")
                uploadRes.onSuccess { finalPhotoUrl = it }
                uploadRes.onFailure { err ->
                    _statusBanner.value = err.localizedMessage
                }
            }
            val result = profileRepo.saveCompleteProfile(
                displayName = displayName,
                rawUsername = username,
                bio = bio,
                photoUrl = finalPhotoUrl,
                countryCode = countryCode,
                phoneLocalNumber = localPhone,
                language = language,
                themeMode = themeMode
            )
            result.onSuccess {
                _statusBanner.value = "Profile saved"
                onSuccess()
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Failed to save profile"
            }
        }
    }

    suspend fun searchByUsername(username: String): Result<PublicProfile?> =
        friendsRepo.findUserByUsername(username)

    suspend fun searchByPhone(countryCode: String, phone: String): Result<PublicProfile?> =
        friendsRepo.findUserByPhone(countryCode, phone)

    suspend fun searchByInviteCode(codeOrUri: String): Result<PublicProfile?> =
        friendsRepo.findUserByInviteCode(codeOrUri)

    suspend fun discoverContacts(contacts: List<DeviceContactEntry>): Result<List<PublicProfile>> =
        friendsRepo.discoverUsersByPhoneHashes(contacts.map { it.phoneHash })

    fun sendFriendRequest(target: PublicProfile) {
        val me = (myProfileState.value as? UiState.Success)?.data ?: return
        viewModelScope.launch {
            friendsRepo.sendFriendRequest(me, target)
                .onSuccess { _statusBanner.value = "Friend request sent to @${target.username}" }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Unable to send request" }
        }
    }

    fun respondToRequest(request: FriendRequest, accept: Boolean) {
        viewModelScope.launch {
            friendsRepo.respondToFriendRequest(request, accept)
                .onSuccess {
                    _statusBanner.value = if (accept) "Connected with ${request.fromName}" else "Request declined"
                }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Action failed" }
        }
    }

    fun cancelRequest(requestId: String) {
        viewModelScope.launch {
            friendsRepo.cancelFriendRequest(requestId)
                .onSuccess { _statusBanner.value = "Request cancelled" }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Failed to cancel request" }
        }
    }

    fun toggleFavorite(friendship: Friendship) {
        viewModelScope.launch {
            friendsRepo.toggleFavorite(friendship)
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun blockUser(targetUid: String) {
        val blocked = privateAccount.value?.blockedUids ?: emptyList()
        viewModelScope.launch {
            friendsRepo.blockUser(targetUid, blocked)
                .onSuccess { _statusBanner.value = "User blocked" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun unblockUser(targetUid: String) {
        val blocked = privateAccount.value?.blockedUids ?: emptyList()
        viewModelScope.launch {
            friendsRepo.unblockUser(targetUid, blocked)
                .onSuccess { _statusBanner.value = "User unblocked" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun reportUser(targetUid: String, reason: String, details: String) {
        viewModelScope.launch {
            friendsRepo.reportUser(targetUid, reason, details)
                .onSuccess { _statusBanner.value = "Report submitted securely" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun openOrCreateDirectChat(peerUid: String, onChatReady: (String) -> Unit) {
        viewModelScope.launch {
            chatRepo.getOrCreateDirectChat(peerUid)
                .onSuccess { onChatReady(it.id) }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Could not open chat" }
        }
    }

    fun createGroupChat(title: String, members: List<PublicProfile>, onCreated: (String) -> Unit) {
        viewModelScope.launch {
            chatRepo.createGroupChat(title, members)
                .onSuccess { onCreated(it.id) }
                .onFailure { _statusBanner.value = it.localizedMessage ?: "Could not create group" }
        }
    }

    fun postTextStory(text: String, bgHex: String, privacy: StoryPrivacy) {
        val author = (myProfileState.value as? UiState.Success)?.data ?: return
        val friendUids = friendships.value.flatMap { it.memberUids }.filter { it != currentUserId }
        viewModelScope.launch {
            socialAndCallRepo.postStory(
                author = author,
                storyType = "TEXT",
                textContent = text,
                mediaUrl = "",
                backgroundColorHex = bgHex,
                privacy = privacy,
                friendUids = friendUids
            ).onSuccess {
                _statusBanner.value = "Story shared (24h expiry)"
            }.onFailure {
                _statusBanner.value = it.localizedMessage ?: "Failed to post story"
            }
        }
    }

    fun postMediaStory(uri: Uri, isVideo: Boolean, caption: String, privacy: StoryPrivacy) {
        val author = (myProfileState.value as? UiState.Success)?.data ?: return
        val friendUids = friendships.value.flatMap { it.memberUids }.filter { it != currentUserId }
        viewModelScope.launch {
            val ext = if (isVideo) "mp4" else "jpg"
            val upload = profileRepo.uploadMedia(uri, "stories", ext)
            upload.onSuccess { url ->
                socialAndCallRepo.postStory(
                    author = author,
                    storyType = if (isVideo) "VIDEO" else "IMAGE",
                    textContent = caption,
                    mediaUrl = url,
                    backgroundColorHex = "#1E1B3A",
                    privacy = privacy,
                    friendUids = friendUids
                ).onSuccess {
                    _statusBanner.value = "Story published!"
                }.onFailure {
                    _statusBanner.value = it.localizedMessage
                }
            }.onFailure {
                _statusBanner.value = it.localizedMessage
            }
        }
    }

    fun markStoryViewed(story: Story) {
        viewModelScope.launch {
            socialAndCallRepo.markStoryViewed(story)
        }
    }

    fun deleteStory(storyId: String) {
        viewModelScope.launch {
            socialAndCallRepo.deleteStory(storyId)
                .onSuccess { _statusBanner.value = "Story deleted" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun selectMyPerson(partnerUid: String) {
        viewModelScope.launch {
            socialAndCallRepo.selectMyPerson(partnerUid)
                .onSuccess { _statusBanner.value = "My Person sanctuary connected" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun sendVirtualHug() {
        val space = myPersonSpace.value ?: return
        viewModelScope.launch {
            socialAndCallRepo.sendVirtualHug(space)
                .onSuccess { _statusBanner.value = "Virtual hug sent!" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun updateMyMood(mood: String) {
        val space = myPersonSpace.value ?: return
        viewModelScope.launch {
            socialAndCallRepo.updateMyMood(space, mood)
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun updateMyPersonDates(anniversaryMs: Long, birthdayMs: Long) {
        val space = myPersonSpace.value ?: return
        viewModelScope.launch {
            socialAndCallRepo.updateMyPersonDates(space.id, anniversaryMs, birthdayMs)
                .onSuccess { _statusBanner.value = "Countdowns updated" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun addMemory(title: String, description: String, dateLabel: String, photoUri: Uri?) {
        val space = myPersonSpace.value ?: return
        viewModelScope.launch {
            var url = ""
            if (photoUri != null) {
                val upload = profileRepo.uploadMedia(photoUri, "memories", "jpg")
                upload.onSuccess { url = it }
                upload.onFailure { _statusBanner.value = it.localizedMessage }
            }
            socialAndCallRepo.addMemory(space, title, description, dateLabel, url)
                .onSuccess { _statusBanner.value = "Memory saved privately" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun addSpecialNote(content: String, colorTag: String) {
        val space = myPersonSpace.value ?: return
        viewModelScope.launch {
            socialAndCallRepo.addSpecialNote(space, content, colorTag)
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun togglePinNote(note: MyPersonNote) {
        val space = myPersonSpace.value ?: return
        viewModelScope.launch {
            socialAndCallRepo.togglePinNote(space.id, note)
        }
    }

    fun declineIncomingCall(callId: String) {
        viewModelScope.launch {
            socialAndCallRepo.updateCallStatus(callId, CallStatus.DECLINED, 0L)
        }
    }

    fun updateSettings(
        showOnlineStatus: Boolean,
        showReadReceipts: Boolean,
        storyPrivacy: StoryPrivacy,
        language: AppLanguage,
        themeMode: ThemeMode,
        notificationsEnabled: Boolean
    ) {
        viewModelScope.launch {
            prefs.setLanguage(language)
            prefs.setThemeMode(themeMode)
            prefs.setNotificationsEnabled(notificationsEnabled)
            profileRepo.updatePrivacyAndPreferences(
                showOnlineStatus = showOnlineStatus,
                showReadReceipts = showReadReceipts,
                storyPrivacy = storyPrivacy,
                language = language,
                themeMode = themeMode,
                notificationsEnabled = notificationsEnabled
            ).onSuccess {
                _statusBanner.value = "Settings saved"
            }.onFailure {
                _statusBanner.value = it.localizedMessage
            }
        }
    }

    fun newCallId(): String = "call_${UUID.randomUUID().toString().replace("-", "").take(16)}"

    suspend fun deleteAccountData(): Result<Unit> {
        val profile = (myProfileState.value as? UiState.Success)?.data
        return profileRepo.deleteAccountData(
            username = profile?.username.orEmpty(),
            inviteCode = profile?.inviteCode.orEmpty(),
            phoneHash = profile?.phoneHash.orEmpty()
        )
    }

    override fun onCleared() {
        super.onCleared()
        peerListeners.values.forEach { it.remove() }
        peerListeners.clear()
    }

    private companion object {
        const val TAG = "HelloAppVM"
        const val STOP_TIMEOUT_MS = 5000L
    }
}
