package com.example.media

import android.content.Context
import android.provider.ContactsContract
import com.example.crypto.E2eeCryptoManager

data class DeviceContactEntry(
    val name: String,
    val phoneE164: String,
    val phoneHash: String
)

object ContactsDiscoveryHelper {

    fun readNormalizedContacts(context: Context, defaultCountryCode: String = "+1"): List<DeviceContactEntry> {
        val result = mutableListOf<DeviceContactEntry>()
        val seenHashes = mutableSetOf<String>()
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null,
            null,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
        ) ?: return emptyList()

        cursor.use { c ->
            val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext() && result.size < 80) {
                val name = if (nameIdx >= 0) c.getString(nameIdx).orEmpty().trim() else ""
                val rawNum = if (numIdx >= 0) c.getString(numIdx).orEmpty().trim() else ""
                val digits = rawNum.replace(Regex("[^0-9+]"), "")
                if (digits.length < 7) continue
                val normalized = if (digits.startsWith("+")) {
                    digits
                } else {
                    val code = "+" + defaultCountryCode.replace(Regex("[^0-9]"), "").ifBlank { "1" }
                    "$code$digits"
                }
                val hash = E2eeCryptoManager.hashPhoneE164(normalized)
                if (seenHashes.add(hash)) {
                    result.add(DeviceContactEntry(name = name.ifBlank { normalized }, phoneE164 = normalized, phoneHash = hash))
                }
            }
        }
        return result
    }
}
