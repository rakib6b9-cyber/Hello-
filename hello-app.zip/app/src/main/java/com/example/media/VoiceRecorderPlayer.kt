package com.example.media

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import java.io.File

class VoiceRecorderHelper(private val context: Context) {
    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var startTimeMs: Long = 0L

    fun startRecording(): File {
        stopRecordingInternal()
        val file = File(context.cacheDir, "voice_${System.currentTimeMillis()}.m4a")
        val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        rec.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(64000)
            setAudioSamplingRate(32000)
            setOutputFile(file.absolutePath)
            prepare()
            start()
        }
        recorder = rec
        outputFile = file
        startTimeMs = System.currentTimeMillis()
        return file
    }

    fun stopAndReturn(): Pair<Uri, Long>? {
        val file = outputFile
        val durationSec = ((System.currentTimeMillis() - startTimeMs) / 1000L).coerceAtLeast(1L)
        stopRecordingInternal()
        return if (file != null && file.exists() && file.length() > 0L) {
            Uri.fromFile(file) to durationSec
        } else {
            null
        }
    }

    fun currentAmplitudeNormalized(): Float {
        return try {
            val amp = recorder?.maxAmplitude ?: 0
            (amp / 32767f).coerceIn(0.1f, 1f)
        } catch (_: Exception) {
            0.15f
        }
    }

    private fun stopRecordingInternal() {
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        try {
            recorder?.release()
        } catch (_: Exception) {
        }
        recorder = null
    }
}

class VoicePlayerHelper {
    private var player: MediaPlayer? = null
    var currentlyPlayingUrl: String? = null
        private set

    fun playOrStop(url: String, onCompleted: () -> Unit, onError: (String) -> Unit) {
        if (currentlyPlayingUrl == url && player?.isPlaying == true) {
            stop()
            onCompleted()
            return
        }
        stop()
        try {
            val mp = MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { it.start() }
                setOnCompletionListener {
                    stop()
                    onCompleted()
                }
                setOnErrorListener { _, _, _ ->
                    stop()
                    onError("Unable to play voice message.")
                    true
                }
                prepareAsync()
            }
            player = mp
            currentlyPlayingUrl = url
        } catch (e: Exception) {
            stop()
            onError(e.localizedMessage ?: "Audio playback failed.")
        }
    }

    fun stop() {
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
        currentlyPlayingUrl = null
    }
}
