package com.example

import com.example.data.AppLanguage
import com.example.data.FriendsRepository
import com.example.data.ProfileRepository
import com.example.localization.stringsFor
import com.example.ui.components.TimeFormatters
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `username normalization strips at sign and lowercases`() {
        assertEquals("tanvir_ahmad", ProfileRepository.normalizeUsername("  @Tanvir_Ahmad "))
        assertTrue(ProfileRepository.USERNAME_REGEX.matches(ProfileRepository.normalizeUsername("@Hello_99")))
    }

    @Test
    fun `international e164 phone builder formats cleanly`() {
        assertEquals("+8801712345678", ProfileRepository.buildE164("+880", "01712-345 678".removePrefix("0")))
        assertEquals("+14155552671", ProfileRepository.buildE164("+1", "(415) 555-2671"))
        assertEquals("", ProfileRepository.buildE164("+880", "   "))
    }

    @Test
    fun `sorted pair id is symmetric regardless of argument order`() {
        val ab = FriendsRepository.sortedPairId("uid_alpha", "uid_beta")
        val ba = FriendsRepository.sortedPairId("uid_beta", "uid_alpha")
        assertEquals(ab, ba)
        assertEquals("uid_alpha_uid_beta", ab)
    }

    @Test
    fun `time formatters produce expected clock and countdown output`() {
        assertEquals("02:05", TimeFormatters.formatDuration(125L))
        assertEquals("00:09", TimeFormatters.formatDuration(9L))
        assertEquals("Not set", TimeFormatters.formatDateLabel(0L))
        val futureDays = TimeFormatters.daysUntilAnnualDate(System.currentTimeMillis() + 5L * 86_400_000L)
        assertTrue(futureDays in 4L..6L)
    }

    @Test
    fun `english and bengali localizations match brand identity`() {
        val en = stringsFor(AppLanguage.EN)
        val bn = stringsFor(AppLanguage.BN)
        assertEquals("Hello App", en.appName)
        assertEquals("Stay Connected, Stay Close.", en.tagline)
        assertEquals("হ্যালো অ্যাপ", bn.appName)
        assertEquals("যুক্ত থাকুন, কাছে থাকুন।", bn.tagline)
    }
}
