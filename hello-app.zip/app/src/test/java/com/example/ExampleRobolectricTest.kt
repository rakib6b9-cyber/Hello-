package com.example

import android.content.Context
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.E2eeCryptoManager
import com.example.data.AppLanguage
import com.example.data.AuthRepository
import com.example.data.Chat
import com.example.data.MyPersonSpace
import com.example.data.PublicProfile
import com.example.data.Story
import com.example.data.ThemeMode
import com.example.data.UiState
import com.example.localization.LocalStrings
import com.example.localization.stringsFor
import com.example.media.QrCodeUtils
import com.example.ui.components.HelloBottomNavBar
import com.example.ui.components.MainTab
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyPersonScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.screens.WelcomeLoginScreen
import com.example.ui.theme.HelloAppTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    @Before
    fun initFirebase() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(context)
        }
    }

    @Test
    fun `app name matches Hello App identity`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Hello App", context.getString(R.string.app_name))
    }

    @Test
    fun `ecdh p256 and aes gcm encrypts decrypts and verifies safety number`() {
        val alice = E2eeCryptoManager.generateIdentityKeyPair()
        val bob = E2eeCryptoManager.generateIdentityKeyPair()
        val eve = E2eeCryptoManager.generateIdentityKeyPair()

        val aliceShared = E2eeCryptoManager.deriveDirectChatKey(alice.privateKeyBase64, bob.publicKeyBase64, "chat_ab")
        val bobShared = E2eeCryptoManager.deriveDirectChatKey(bob.privateKeyBase64, alice.publicKeyBase64, "chat_ab")
        val eveKey = E2eeCryptoManager.deriveDirectChatKey(eve.privateKeyBase64, alice.publicKeyBase64, "chat_ab")

        val secretMessage = "Stay Connected, Stay Close — Hello App E2EE!"
        val encrypted = E2eeCryptoManager.encryptText(secretMessage, aliceShared)

        assertEquals(secretMessage, E2eeCryptoManager.decryptText(encrypted.ciphertextBase64, encrypted.ivBase64, bobShared))
        assertNull(E2eeCryptoManager.decryptText(encrypted.ciphertextBase64, encrypted.ivBase64, eveKey))

        val sn1 = E2eeCryptoManager.computeSafetyNumber(alice.publicKeyBase64, bob.publicKeyBase64)
        val sn2 = E2eeCryptoManager.computeSafetyNumber(bob.publicKeyBase64, alice.publicKeyBase64)
        assertEquals(sn1, sn2)
        assertEquals(12, sn1.split(" ").size)
    }

    @Test
    fun `group key wrapping and phone sha256 hashing work deterministically`() {
        val admin = E2eeCryptoManager.generateIdentityKeyPair()
        val member = E2eeCryptoManager.generateIdentityKeyPair()
        val groupKey = E2eeCryptoManager.generateGroupAesKey()

        val wrapped = E2eeCryptoManager.wrapGroupKey(groupKey, admin.privateKeyBase64, member.publicKeyBase64, "grp_1")
        val unwrapped = E2eeCryptoManager.unwrapGroupKey(wrapped, member.privateKeyBase64, admin.publicKeyBase64, "grp_1")
        assertNotNull(unwrapped)
        assertEquals(groupKey.toList(), unwrapped!!.toList())

        val h1 = E2eeCryptoManager.hashPhoneE164("+8801712345678")
        val h2 = E2eeCryptoManager.hashPhoneE164("+880-171-234-5678")
        assertEquals(64, h1.length)
        assertEquals(h1, h2)
    }

    @Test
    fun `qr bitmap generator produces crisp bitmap for invite uri`() {
        val bmp = QrCodeUtils.generateQrBitmap("helloapp://invite?code=HELLO-ABC-123", 128)
        assertEquals(128, bmp.width)
        assertEquals(128, bmp.height)
    }

    @Test
    fun `welcome login renders google phone apple recovery and language toggle`() {
        var toggledLang: AppLanguage? = null
        composeRule.setContent {
            HelloAppTheme(ThemeMode.DARK) {
                CompositionLocalProvider(LocalStrings provides stringsFor(AppLanguage.EN)) {
                    WelcomeLoginScreen(
                        authRepo = AuthRepository(),
                        currentLanguage = AppLanguage.EN,
                        onLanguageChange = { toggledLang = it },
                        onAuthSuccess = {}
                    )
                }
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Hello App").assertIsDisplayed()
        composeRule.onNodeWithText("Stay Connected, Stay Close.").assertIsDisplayed()
        composeRule.onNodeWithTag("google_sign_in_button").assertIsDisplayed()
        composeRule.onNodeWithTag("phone_sign_in_toggle").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("phone_number_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("apple_sign_in_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("account_recovery_button").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("welcome_language_toggle").performScrollTo().performClick()
        assertEquals(AppLanguage.BN, toggledLang)
    }

    @Test
    fun `bottom nav bar has Home Chats New Calls Profile and omits Moments`() {
        var selected: MainTab = MainTab.HOME
        var newTapped = false
        composeRule.setContent {
            HelloAppTheme(ThemeMode.DARK) {
                CompositionLocalProvider(LocalStrings provides stringsFor(AppLanguage.EN)) {
                    HelloBottomNavBar(
                        selectedTab = selected,
                        unreadBadgeCount = 3,
                        missedCallCount = 1,
                        onSelectTab = { selected = it },
                        onNewActionClick = { newTapped = true }
                    )
                }
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("nav_home").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_chats").assertIsDisplayed().performClick()
        assertEquals(MainTab.CHATS, selected)
        composeRule.onNodeWithTag("nav_calls").assertIsDisplayed().performClick()
        assertEquals(MainTab.CALLS, selected)
        composeRule.onNodeWithTag("nav_profile").assertIsDisplayed().performClick()
        assertEquals(MainTab.PROFILE, selected)
        composeRule.onNodeWithTag("nav_new_button").assertIsDisplayed().performClick()
        assertTrue(newTapped)
        composeRule.onNodeWithText("Moments").assertDoesNotExist()
    }

    @Test
    fun `home screen renders story circles conversation list and quick audio call button`() {
        var openedChat = ""
        var calledPeer = ""
        val chat = Chat(
            id = "u1_u2",
            chatType = "DIRECT",
            memberUids = listOf("u1", "u2"),
            lastMessagePreview = "Are we calling tonight?",
            unreadCounts = mapOf("u1" to 2L),
            lastMessageAt = Timestamp.now()
        )
        val peer = PublicProfile(
            userId = "u2",
            username = "anika_s",
            displayName = "Anika Sultana",
            onlineStatus = "ONLINE"
        )
        val story = Story(
            id = "s1",
            authorId = "u2",
            authorName = "Anika Sultana",
            allowedUids = listOf("u1", "u2")
        )

        composeRule.setContent {
            HelloAppTheme(ThemeMode.LIGHT) {
                CompositionLocalProvider(LocalStrings provides stringsFor(AppLanguage.EN)) {
                    HomeScreen(
                        currentUserId = "u1",
                        myProfile = PublicProfile(userId = "u1", displayName = "Me", username = "me_user"),
                        chatsState = UiState.Success(listOf(chat)),
                        peerProfiles = mapOf("u2" to peer),
                        stories = listOf(story),
                        pendingRequests = emptyList(),
                        blockedUids = emptyList(),
                        onOpenChat = { openedChat = it },
                        onQuickAudioCall = { uid, _ -> calledPeer = uid },
                        onCreateStory = {},
                        onViewAuthorStories = {},
                        onOpenMyPerson = {},
                        onOpenStoriesHub = {},
                        onOpenFriends = {},
                        onOpenNotifications = {}
                    )
                }
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("story_circle_my").assertIsDisplayed()
        composeRule.onNodeWithTag("story_circle_myperson").assertIsDisplayed()
        composeRule.onNodeWithTag("story_circle_more").assertIsDisplayed()
        composeRule.onNodeWithText("Anika Sultana").assertIsDisplayed()
        composeRule.onNodeWithTag("quick_call_u1_u2").performClick()
        assertEquals("u2", calledPeer)
        composeRule.onNodeWithTag("chat_row_u1_u2").performClick()
        assertEquals("u1_u2", openedChat)
    }

    @Test
    fun `profile setup validates inputs and triggers save callback`() {
        var savedName = ""
        var savedUser = ""
        composeRule.setContent {
            HelloAppTheme(ThemeMode.DARK) {
                CompositionLocalProvider(LocalStrings provides stringsFor(AppLanguage.EN)) {
                    ProfileSetupScreen(
                        initialName = "",
                        initialEmail = "user@hello.app",
                        initialPhone = "",
                        currentLanguage = AppLanguage.EN,
                        currentTheme = ThemeMode.DARK,
                        onCheckUsername = { Result.success(true) },
                        onSaveProfile = { name, user, _, _, _, _ ->
                            savedName = name
                            savedUser = user
                        },
                        onSignOut = {}
                    )
                }
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("setup_display_name_input").performScrollTo().performTextInput("Arif Rahman")
        composeRule.onNodeWithTag("setup_username_input").performScrollTo().performTextInput("arif_99")
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("setup_save_button").performScrollTo().performClick()
        composeRule.waitForIdle()
        assertEquals("Arif Rahman", savedName)
        assertEquals("arif_99", savedUser)
    }

    @Test
    fun `my person sanctuary sends virtual hug and displays countdowns`() {
        var hugSent = false
        val space = MyPersonSpace(
            id = "u1_u2",
            memberUids = listOf("u1", "u2"),
            anniversaryEpochMs = System.currentTimeMillis() + 10L * 86_400_000L,
            partnerBirthdayEpochMs = System.currentTimeMillis() + 20L * 86_400_000L,
            moodByUid = mapOf("u1" to "Happy", "u2" to "Grateful"),
            hugCount = 7L
        )
        composeRule.setContent {
            HelloAppTheme(ThemeMode.DARK) {
                CompositionLocalProvider(LocalStrings provides stringsFor(AppLanguage.EN)) {
                    MyPersonScreen(
                        currentUserId = "u1",
                        space = space,
                        memories = emptyList(),
                        notes = emptyList(),
                        friendships = emptyList(),
                        peerProfiles = mapOf("u2" to PublicProfile(userId = "u2", displayName = "Nadia")),
                        onSelectMyPerson = {},
                        onSendHug = { hugSent = true },
                        onUpdateMood = {},
                        onUpdateDates = { _, _ -> },
                        onAddMemory = { _, _, _, _ -> },
                        onAddNote = { _, _ -> },
                        onTogglePinNote = {},
                        onMessagePartner = {},
                        onCallPartner = { _, _ -> },
                        onBack = {}
                    )
                }
            }
        }
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Nadia").assertIsDisplayed()
        composeRule.onNodeWithText("7 hugs shared together").assertIsDisplayed()
        composeRule.onNodeWithTag("send_virtual_hug_btn").performClick()
        assertTrue(hugSent)
    }
}
